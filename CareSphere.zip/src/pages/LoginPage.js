import React, { useState } from 'react';
import { motion } from 'framer-motion';
import './LoginPage.css';

/* ============================================
   LOGIN PAGE TEMPLATE
   Customize: Logo, colors, text
   ============================================ */

const LoginPage = ({ onLogin }) => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    setTimeout(() => {
      const success = onLogin(email, password);
      if (!success) {
        setError('Invalid email or password');
      }
      setLoading(false);
    }, 1000);
  };

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: { staggerChildren: 0.1, delayChildren: 0.2 },
    },
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: { opacity: 1, y: 0, transition: { duration: 0.6, ease: 'easeOut' } },
  };

  return (
    <div className="login-container">
      {/* LEFT SIDE - BRAND */}
      <motion.div
        className="login-left"
        initial={{ opacity: 0, x: -50 }}
        animate={{ opacity: 1, x: 0 }}
        transition={{ duration: 0.8 }}
      >
        <div className="brand-section">
          {/* === CUSTOMIZE: Logo === */}
          <div className="logo-placeholder">
            <div className="logo-circle">
              <span>🛍️</span>
            </div>
          </div>

          {/* === CUSTOMIZE: Brand Name === */}
          <h1 className="brand-title">CareSphere</h1>
          <p className="brand-subtitle">Care For Every Life</p>

          {/* === CUSTOMIZE: Features List === */}
          <div className="features-list">
            <div className="feature-item">
              <span className="feature-icon">✨</span>
              <div>
                <h4>Disease Triage</h4>
                <p>Symptom Checker and guidance</p>
              </div>
            </div>

            <div className="feature-item">
              <span className="feature-icon">✨</span>
              <div>
                <h4>Doctor Finder</h4>
                <p>Find the Nearest Doctor</p>
              </div>
            </div>

            <div className="feature-item">
              <span className="feature-icon">✨</span>
              <div>
                <h4>Medicine Finder</h4>
                <p>Search,Find,Heal</p>
              </div>
            </div>

            <div className="feature-item">
              <span className="feature-icon">✨</span>
              <div>
                <h4>Digital Prescription</h4>
                <p>Protect your prescription</p>
              </div>
            </div>
          </div>
        </div>
      </motion.div>

      {/* RIGHT SIDE - FORM */}
      <motion.div
        className="login-right"
        initial={{ opacity: 0, x: 50 }}
        animate={{ opacity: 1, x: 0 }}
        transition={{ duration: 0.8 }}
      >
        <motion.div
          className="login-form-wrapper"
          variants={containerVariants}
          initial="hidden"
          animate="visible"
        >
          {/* === CUSTOMIZE: Title === */}
          <motion.h2 variants={itemVariants}>Welcome Back</motion.h2>
          <motion.p variants={itemVariants} className="form-subtitle">
            Sign in to your account
          </motion.p>

          <form onSubmit={handleSubmit} className="login-form">
            {error && (
              <motion.div variants={itemVariants} className="error-message">
                ⚠️ {error}
              </motion.div>
            )}

            <motion.div variants={itemVariants} className="form-group">
              <label htmlFor="email">Email Address</label>
              <input
                id="email"
                type="email"
                placeholder="you@example.com"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                disabled={loading}
              />
            </motion.div>

            <motion.div variants={itemVariants} className="form-group">
              <label htmlFor="password">Password</label>
              <input
                id="password"
                type="password"
                placeholder="••••••••"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                disabled={loading}
              />
            </motion.div>

            <motion.button
              variants={itemVariants}
              type="submit"
              className="btn-login"
              disabled={loading}
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
            >
              {loading ? (
                <>
                  <span className="spinner"></span>
                  Signing in...
                </>
              ) : (
                'Sign In'
              )}
            </motion.button>
          </form>

          {/* === CUSTOMIZE: Demo Credentials === */}
          <motion.div variants={itemVariants} className="demo-section">
            <p className="demo-label">Demo:</p>
            <code className="demo-code">
              Email: demo@example.com<br/>
              Password: demo123
            </code>
          </motion.div>
        </motion.div>
      </motion.div>

      {/* BACKGROUND ELEMENTS */}
      <div className="background-elements">
        <div className="floating-shape shape-1"></div>
        <div className="floating-shape shape-2"></div>
        <div className="floating-shape shape-3"></div>
      </div>
    </div>
  );
};

export default LoginPage;
