import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import './Dashboard.css';
import Sidebar from '../components/Sidebar';
import Tab1 from '../components/tabs/Tab1';
import Tab2 from '../components/tabs/Tab2';
import Tab3 from '../components/tabs/Tab3';
import Tab4 from '../components/tabs/Tab4';
import Tab5 from '../components/tabs/Tab5';
import Tab6 from '../components/tabs/Tab6';
import Tab7 from '../components/tabs/Tab7';
import Tab8 from '../components/tabs/Tab8';

const Dashboard = ({ userEmail, onLogout }) => {
  const [activeTab, setActiveTab] = useState('tab1');
  const [sidebarOpen, setSidebarOpen] = useState(true);

  const tabMapping = {
    'tab1': { name: 'Disease Triage', component: Tab1 },
    'tab2': { name: 'Doctor Finder', component: Tab2 },
    'tab3': { name: 'Medicine Finder', component: Tab3 },
    'tab4': { name: 'Fitness Score', component: Tab4 },
    'tab5': { name: 'Digital Prescription', component: Tab5 },
    'tab6': { name: 'Doctor Consultancy', component: Tab6 },
    'tab7': { name: 'Government Schems', component: Tab7 },
    'tab8': { name: 'Emergency', component: Tab8 },
  };

  const renderContent = () => {
    const tab = tabMapping[activeTab];
    const Component = tab.component;
    return <Component />;
  };

  const contentVariants = {
    hidden: { opacity: 0, x: 20 },
    visible: { opacity: 1, x: 0, transition: { duration: 0.4, ease: 'easeOut' } },
    exit: { opacity: 0, x: -20, transition: { duration: 0.25, ease: 'easeIn' } }
  };

  // Sidebar width: 280px open, 68px collapsed, 0px on mobile closed
  const sidebarWidth = sidebarOpen ? 280 : 68;

  return (
    <div className="dashboard">
      <Sidebar
        activeTab={activeTab}
        onTabChange={setActiveTab}
        sidebarOpen={sidebarOpen}
        onToggleSidebar={() => setSidebarOpen(!sidebarOpen)}
        userEmail={userEmail}
        onLogout={onLogout}
        tabMapping={tabMapping}
      />

      {/* Main content shifts right to account for fixed sidebar */}
      <motion.div
        className="dashboard-main"
        animate={{ marginLeft: sidebarWidth }}
        transition={{ duration: 0.28, ease: 'easeInOut' }}
      >
        <header className="dashboard-header">
          <div className="header-left">
            <h1 className="page-title">{tabMapping[activeTab].name}</h1>
          </div>
          <div className="header-right">
            <div className="user-info">
              <span className="user-email">{userEmail}</span>
            </div>
          </div>
        </header>

        <div className="dashboard-content">
          <AnimatePresence mode="wait">
            <motion.div
              key={activeTab}
              variants={contentVariants}
              initial="hidden"
              animate="visible"
              exit="exit"
              className="content-wrapper"
            >
              {renderContent()}
            </motion.div>
          </AnimatePresence>
        </div>
      </motion.div>
    </div>
  );
};

export default Dashboard;