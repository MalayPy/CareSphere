import React, { useState } from 'react';
import { motion } from 'framer-motion';
import './ModernClosetAI.css';

/* ============================================
   MODERN CLOSETAI - TEMPUS INSPIRED DESIGN
   
   Features:
   - Professional dark theme
   - Smooth animations
   - Modern UI/UX
   - Responsive design
   - Multiple sections
   ============================================ */

const ModernClosetAI = () => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  // Animation variants
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: { staggerChildren: 0.1, delayChildren: 0.2 }
    }
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: { opacity: 1, y: 0, transition: { duration: 0.6 } }
  };

  const cardVariants = {
    hidden: { opacity: 0, scale: 0.95 },
    visible: { opacity: 1, scale: 1, transition: { duration: 0.5 } },
    hover: { y: -8, transition: { duration: 0.3 } }
  };

  return (
    <div className="modern-closetai">
      {/* ========== HEADER ========== */}
      <header className="header">
        <div className="header-container">
          <motion.div className="logo" initial={{ opacity: 0 }} animate={{ opacity: 1 }}>
            <span className="logo-icon">🛍️</span>
            <span>ClosetAI</span>
          </motion.div>

          <nav className={`nav ${mobileMenuOpen ? 'active' : ''}`}>
            <a href="#features">Features</a>
            <a href="#solutions">How It Works</a>
            <a href="#benefits">Benefits</a>
            <a href="#news">News</a>
            <button className="btn-primary">Sign In</button>
          </nav>

          <button 
            className="mobile-menu-btn"
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
          >
            ☰
          </button>
        </div>
      </header>

      {/* ========== HERO SECTION ========== */}
      <motion.section 
        className="hero"
        variants={containerVariants}
        initial="hidden"
        animate="visible"
      >
        <div className="hero-background">
          <div className="gradient-1"></div>
          <div className="gradient-2"></div>
          <div className="gradient-3"></div>
        </div>

        <motion.div className="hero-content" variants={containerVariants}>
          <motion.h1 variants={itemVariants}>
            AI-Powered Fashion Discovery
          </motion.h1>
          <motion.p variants={itemVariants} className="hero-subtitle">
            Discover your perfect style with cutting-edge AI technology
          </motion.p>
          <motion.div variants={itemVariants} className="hero-buttons">
            <button className="btn-primary btn-large">Explore Now</button>
            <button className="btn-secondary btn-large">Learn More</button>
          </motion.div>
        </motion.div>
      </motion.section>

      {/* ========== CAPABILITIES SECTION ========== */}
      <motion.section 
        className="capabilities"
        initial="hidden"
        whileInView="visible"
        variants={containerVariants}
      >
        <motion.div className="section-header" variants={itemVariants}>
          <h2>With AI-Powered Fashion, You Can</h2>
          <p>Discover intelligent features that transform your wardrobe</p>
        </motion.div>

        <motion.div className="capabilities-grid" variants={containerVariants}>
          {[
            { icon: '📸', title: 'SCAN', description: 'Create a 3D model of your body with precise measurements' },
            { icon: '👗', title: 'VISUALIZE', description: 'Try on clothes virtually before you buy' },
            { icon: '✨', title: 'RECOMMEND', description: 'Get personalized outfit suggestions based on your style' },
            { icon: '🛒', title: 'SHOP', description: 'Find clothes that fit perfectly from multiple retailers' }
          ].map((capability, index) => (
            <motion.div 
              key={index}
              className="capability-item"
              variants={itemVariants}
            >
              <div className="capability-icon">{capability.icon}</div>
              <h3>{capability.title}</h3>
              <p>{capability.description}</p>
            </motion.div>
          ))}
        </motion.div>
      </motion.section>

      {/* ========== TECHNOLOGY SECTION ========== */}
      <motion.section 
        className="technology"
        initial="hidden"
        whileInView="visible"
        variants={containerVariants}
      >
        <motion.div className="section-header" variants={itemVariants}>
          <h2>Our Technology Stack</h2>
          <p>Powered by advanced AI and machine learning</p>
        </motion.div>

        <motion.div className="tech-grid" variants={containerVariants}>
          {[
            { name: 'SCAN', description: 'Advanced 3D body scanning with pose detection' },
            { name: 'ANALYZE', description: 'AI-powered body measurement calculation' },
            { name: 'MATCH', description: 'Smart clothing size and style matching' },
            { name: 'RECOMMEND', description: 'Personalized outfit suggestions' }
          ].map((tech, index) => (
            <motion.div 
              key={index}
              className="tech-card"
              variants={cardVariants}
              whileHover="hover"
            >
              <h3>{tech.name}</h3>
              <p>{tech.description}</p>
            </motion.div>
          ))}
        </motion.div>
      </motion.section>

      {/* ========== SOLUTIONS SECTION ========== */}
      <motion.section 
        className="solutions"
        id="solutions"
        initial="hidden"
        whileInView="visible"
        variants={containerVariants}
      >
        <motion.div className="section-header" variants={itemVariants}>
          <h2>How ClosetAI Works</h2>
          <p>Three powerful solutions for every fashion need</p>
        </motion.div>

        <motion.div className="solutions-grid" variants={containerVariants}>
          {[
            {
              title: 'For Fashion Enthusiasts',
              description: 'Get personalized style recommendations based on your preferences, body type, and fashion taste.',
              color: '#0066ff'
            },
            {
              title: 'For Online Shoppers',
              description: 'Never worry about sizing again. Our AI ensures perfect fit predictions for every item.',
              color: '#ff6b35'
            },
            {
              title: 'For Retailers',
              description: 'Reduce returns and increase customer satisfaction with accurate sizing recommendations.',
              color: '#9b59b6'
            }
          ].map((solution, index) => (
            <motion.div 
              key={index}
              className="solution-card"
              style={{ borderTop: `4px solid ${solution.color}` }}
              variants={itemVariants}
            >
              <h3>{solution.title}</h3>
              <p>{solution.description}</p>
              <a href="#" className="solution-link">Learn More →</a>
            </motion.div>
          ))}
        </motion.div>
      </motion.section>

      {/* ========== FEATURES SECTION ========== */}
      <motion.section 
        className="features"
        id="features"
        initial="hidden"
        whileInView="visible"
        variants={containerVariants}
      >
        <motion.div className="section-header" variants={itemVariants}>
          <h2>Powerful Features</h2>
          <p>Everything you need for the perfect wardrobe</p>
        </motion.div>

        <motion.div className="features-grid" variants={containerVariants}>
          {[
            { emoji: '🎯', title: 'Body Scanning', desc: '3D body analysis with precise measurements' },
            { emoji: '👗', title: 'Virtual Try-On', desc: 'See how clothes look before purchasing' },
            { emoji: '📏', title: 'Size Guide', desc: 'Accurate sizing across all retailers' },
            { emoji: '❤️', title: 'Saved Outfits', desc: 'Keep track of your favorite combinations' },
            { emoji: '🛒', title: 'Smart Shopping', desc: 'Buy from multiple retailers in one place' },
            { emoji: '👤', title: 'Style Profile', desc: 'Personalized recommendations based on you' }
          ].map((feature, index) => (
            <motion.div 
              key={index}
              className="feature-card"
              variants={cardVariants}
              whileHover="hover"
            >
              <div className="feature-emoji">{feature.emoji}</div>
              <h4>{feature.title}</h4>
              <p>{feature.desc}</p>
            </motion.div>
          ))}
        </motion.div>
      </motion.section>

      {/* ========== STATISTICS SECTION ========== */}
      <motion.section 
        className="statistics"
        initial="hidden"
        whileInView="visible"
        variants={containerVariants}
      >
        <motion.h2 variants={itemVariants}>Our Impact</motion.h2>
        
        <motion.div className="stats-grid" variants={containerVariants}>
          {[
            { number: '100K+', label: 'Active Users' },
            { number: '95%', label: 'Accuracy Rate' },
            { number: '50+', label: 'Retail Partners' },
            { number: '1M+', label: 'Outfits Created' }
          ].map((stat, index) => (
            <motion.div 
              key={index}
              className="stat-item"
              variants={itemVariants}
            >
              <div className="stat-number">{stat.number}</div>
              <div className="stat-label">{stat.label}</div>
            </motion.div>
          ))}
        </motion.div>
      </motion.section>

      {/* ========== NEWS SECTION ========== */}
      <motion.section 
        className="news"
        id="news"
        initial="hidden"
        whileInView="visible"
        variants={containerVariants}
      >
        <motion.div className="section-header" variants={itemVariants}>
          <h2>Latest Updates</h2>
          <p>Stay informed about our latest innovations</p>
        </motion.div>

        <motion.div className="news-grid" variants={containerVariants}>
          {[
            {
              date: 'March 2026',
              title: 'Advanced 3D Scanning Released',
              desc: 'New AI-powered body scanning with enhanced accuracy'
            },
            {
              date: 'February 2026',
              title: 'Partnership with Major Retailers',
              desc: 'Expanded integration with leading fashion brands'
            },
            {
              date: 'January 2026',
              title: 'AI Recommendations 2.0',
              desc: 'Smarter outfit suggestions powered by new algorithms'
            }
          ].map((news, index) => (
            <motion.div 
              key={index}
              className="news-card"
              variants={cardVariants}
              whileHover="hover"
            >
              <div className="news-date">{news.date}</div>
              <h4>{news.title}</h4>
              <p>{news.desc}</p>
              <a href="#" className="news-link">Read More →</a>
            </motion.div>
          ))}
        </motion.div>
      </motion.section>

      {/* ========== BENEFITS SECTION ========== */}
      <motion.section 
        className="benefits"
        id="benefits"
        initial="hidden"
        whileInView="visible"
        variants={containerVariants}
      >
        <motion.div className="section-header" variants={itemVariants}>
          <h2>Why Choose ClosetAI?</h2>
          <p>Discover the benefits of AI-powered fashion</p>
        </motion.div>

        <motion.div className="benefits-grid" variants={containerVariants}>
          {[
            'Save time finding the perfect outfit',
            'Reduce return rates with accurate sizing',
            'Personalized style recommendations',
            '3D virtual try-on technology',
            'Multi-retailer shopping integration',
            'Privacy-first body scanning'
          ].map((benefit, index) => (
            <motion.div 
              key={index}
              className="benefit-item"
              variants={itemVariants}
            >
              <span className="check-icon">✓</span>
              <p>{benefit}</p>
            </motion.div>
          ))}
        </motion.div>
      </motion.section>

      {/* ========== CTA SECTION ========== */}
      <motion.section 
        className="cta"
        initial="hidden"
        whileInView="visible"
        variants={containerVariants}
      >
        <motion.h2 variants={itemVariants}>Ready to Transform Your Wardrobe?</motion.h2>
        <motion.p variants={itemVariants}>Join thousands of users discovering their perfect style</motion.p>
        <motion.div variants={itemVariants} className="cta-buttons">
          <button className="btn-primary btn-large">Get Started Free</button>
          <button className="btn-secondary-light btn-large">Schedule Demo</button>
        </motion.div>
      </motion.section>

      {/* ========== FOOTER ========== */}
      <footer className="footer">
        <div className="footer-content">
          <motion.div className="footer-section" variants={itemVariants}>
            <h4>Product</h4>
            <a href="#">Features</a>
            <a href="#">Pricing</a>
            <a href="#">Security</a>
            <a href="#">Roadmap</a>
          </motion.div>

          <motion.div className="footer-section" variants={itemVariants}>
            <h4>Company</h4>
            <a href="#">About Us</a>
            <a href="#">Blog</a>
            <a href="#">Careers</a>
            <a href="#">Press</a>
          </motion.div>

          <motion.div className="footer-section" variants={itemVariants}>
            <h4>Resources</h4>
            <a href="#">Documentation</a>
            <a href="#">Support</a>
            <a href="#">Community</a>
            <a href="#">FAQ</a>
          </motion.div>

          <motion.div className="footer-section" variants={itemVariants}>
            <h4>Legal</h4>
            <a href="#">Privacy Policy</a>
            <a href="#">Terms of Service</a>
            <a href="#">Cookie Policy</a>
            <a href="#">Contact</a>
          </motion.div>
        </div>

        <motion.div className="footer-bottom" variants={itemVariants}>
          <p>&copy; 2026 ClosetAI. All rights reserved. | Powered by AI</p>
        </motion.div>
      </footer>
    </div>
  );
};

export default ModernClosetAI;
