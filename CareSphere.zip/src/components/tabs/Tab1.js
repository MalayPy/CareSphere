import React, { useState, useRef, useEffect, useCallback } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import './Tab1.css';

/* ============================================
   DISEASE TRIAGE CHATBOT
   
   Powered by Google Gemini API with:
   - Text message input
   - Voice input (Web Speech API)
   - Image input (upload + camera capture)
   - Streaming-style responses
   - Medical context awareness
   - Beautiful Claude-inspired chat UI
   ============================================ */

// ⚠️ REPLACE WITH YOUR GEMINI API KEY
const GEMINI_API_KEY = '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';

const SYSTEM_PROMPT = `You are MediBot, an expert AI medical triage assistant. Your role is to:
1. Help users understand their symptoms clearly and compassionately
2. Ask relevant follow-up questions to better understand their condition
3. Provide general health guidance and possible causes for symptoms
4. Suggest when to seek immediate emergency care vs. routine doctor visit
5. If an image is shared, analyze it for visible symptoms (rashes, injuries, etc.)
6. Always remind users that this is not a substitute for professional medical advice

Be warm, professional, concise, and use simple language. Structure responses clearly.
Always end with a clear recommendation: Home care / See a doctor soon / Go to ER immediately.
Use relevant medical emojis to make responses more readable.`;

const DiseaseTriage = () => {
  const [messages, setMessages] = useState([
    {
      id: 1,
      role: 'assistant',
      content: "Hello! I'm **MediBot**, your AI health assistant 🩺\n\nDescribe your symptoms in detail, and I'll help assess your condition and guide you on next steps.\n\n> ⚠️ This tool provides general guidance only — not a medical diagnosis. For emergencies, call **112** immediately.",
      timestamp: new Date(),
    }
  ]);

  const [inputText, setInputText] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [isListening, setIsListening] = useState(false);
  const [uploadedImage, setUploadedImage] = useState(null);
  const [imagePreview, setImagePreview] = useState(null);
  const [imageBase64, setImageBase64] = useState(null);
  const [showImageOptions, setShowImageOptions] = useState(false);
  const [error, setError] = useState(null);

  const messagesEndRef = useRef(null);
  const textareaRef = useRef(null);
  const fileInputRef = useRef(null);
  const cameraInputRef = useRef(null);
  const recognitionRef = useRef(null);

  // ========== AUTO SCROLL ==========
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isLoading]);

  // ========== SPEECH RECOGNITION ==========
  useEffect(() => {
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (SpeechRecognition) {
      recognitionRef.current = new SpeechRecognition();
      recognitionRef.current.continuous = false;
      recognitionRef.current.interimResults = true;
      recognitionRef.current.lang = 'en-IN';

      recognitionRef.current.onresult = (event) => {
        const transcript = Array.from(event.results)
          .map(r => r[0].transcript)
          .join('');
        setInputText(transcript);
      };

      recognitionRef.current.onend = () => setIsListening(false);
      recognitionRef.current.onerror = () => setIsListening(false);
    }
    return () => recognitionRef.current?.abort();
  }, []);

  const toggleVoice = () => {
    if (!recognitionRef.current) {
      setError('Voice input not supported in this browser.');
      return;
    }
    if (isListening) {
      recognitionRef.current.stop();
      setIsListening(false);
    } else {
      setError(null);
      recognitionRef.current.start();
      setIsListening(true);
    }
  };

  // ========== IMAGE HANDLING ==========
  const handleImageFile = (file) => {
    if (!file) return;
    if (!file.type.startsWith('image/')) {
      setError('Please upload an image file.');
      return;
    }
    if (file.size > 10 * 1024 * 1024) {
      setError('Image must be under 10MB.');
      return;
    }

    setUploadedImage(file);
    setShowImageOptions(false);
    setError(null);

    const reader = new FileReader();
    reader.onload = (e) => {
      const result = e.target.result;
      setImagePreview(result);
      const base64 = result.split(',')[1];
      setImageBase64(base64);
    };
    reader.readAsDataURL(file);
  };

  const removeImage = () => {
    setUploadedImage(null);
    setImagePreview(null);
    setImageBase64(null);
    if (fileInputRef.current) fileInputRef.current.value = '';
    if (cameraInputRef.current) cameraInputRef.current.value = '';
  };

  // ========== PARSE MARKDOWN SIMPLE ==========
  const parseMarkdown = (text) => {
    return text
      .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
      .replace(/\*(.*?)\*/g, '<em>$1</em>')
      .replace(/^> (.+)$/gm, '<blockquote>$1</blockquote>')
      .replace(/^### (.+)$/gm, '<h3>$1</h3>')
      .replace(/^## (.+)$/gm, '<h2>$1</h2>')
      .replace(/^- (.+)$/gm, '<li>$1</li>')
      .replace(/(<li>.*<\/li>)/gs, '<ul>$1</ul>')
      .replace(/\n\n/g, '<br/><br/>')
      .replace(/\n/g, '<br/>');
  };

  // ========== GEMINI API CALL ==========
  const sendToGemini = useCallback(async (userText, base64Img, imgMimeType) => {
    const historyForAPI = messages
      .filter(m => m.id !== 1)
      .slice(-8)
      .map(m => ({
        role: m.role === 'assistant' ? 'model' : 'user',
        parts: [{ text: m.content }]
      }));

    const userParts = [];

    if (base64Img) {
      userParts.push({
        inline_data: {
          mime_type: imgMimeType || 'image/jpeg',
          data: base64Img
        }
      });
    }

    if (userText.trim()) {
      userParts.push({ text: userText });
    } else if (base64Img) {
      userParts.push({ text: 'Please analyze this image for any visible symptoms or health concerns.' });
    }

    const body = {
      system_instruction: {
        parts: [{ text: SYSTEM_PROMPT }]
      },
      contents: [
        ...historyForAPI,
        { role: 'user', parts: userParts }
      ],
      generationConfig: {
        temperature: 0.7,
        maxOutputTokens: 1024,
      },
      safetySettings: [
        { category: 'HARM_CATEGORY_HARASSMENT', threshold: 'BLOCK_NONE' },
        { category: 'HARM_CATEGORY_HATE_SPEECH', threshold: 'BLOCK_NONE' },
        { category: 'HARM_CATEGORY_SEXUALLY_EXPLICIT', threshold: 'BLOCK_MEDIUM_AND_ABOVE' },
        { category: 'HARM_CATEGORY_DANGEROUS_CONTENT', threshold: 'BLOCK_NONE' },
      ]
    };

    const response = await fetch(
      `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=${GEMINI_API_KEY}`,
      {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body)
      }
    );

    if (!response.ok) {
      const errData = await response.json().catch(() => ({}));
      throw new Error(errData?.error?.message || `API Error: ${response.status}`);
    }

    const data = await response.json();
    const text = data?.candidates?.[0]?.content?.parts?.[0]?.text;
    if (!text) throw new Error('No response from Gemini.');
    return text;
  }, [messages]);

  // ========== SEND MESSAGE ==========
  const handleSend = async () => {
    const trimmed = inputText.trim();
    if (!trimmed && !imageBase64) return;
    if (isLoading) return;

    setError(null);

    const userMsg = {
      id: Date.now(),
      role: 'user',
      content: trimmed,
      image: imagePreview,
      timestamp: new Date()
    };

    setMessages(prev => [...prev, userMsg]);
    setInputText('');
    const savedBase64 = imageBase64;
    const savedMime = uploadedImage?.type;
    removeImage();
    setIsLoading(true);

    try {
      const reply = await sendToGemini(trimmed, savedBase64, savedMime);
      const botMsg = {
        id: Date.now() + 1,
        role: 'assistant',
        content: reply,
        timestamp: new Date()
      };
      setMessages(prev => [...prev, botMsg]);
    } catch (err) {
      setError(err.message || 'Failed to get a response. Please check your API key.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleKeyDown = (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  const handleTextareaChange = (e) => {
    setInputText(e.target.value);
    const ta = textareaRef.current;
    if (ta) {
      ta.style.height = 'auto';
      ta.style.height = Math.min(ta.scrollHeight, 140) + 'px';
    }
  };

  const clearChat = () => {
    setMessages([{
      id: 1,
      role: 'assistant',
      content: "Hello! I'm **MediBot**, your AI health assistant 🩺\n\nDescribe your symptoms in detail, and I'll help assess your condition and guide you on next steps.\n\n> ⚠️ This tool provides general guidance only — not a medical diagnosis. For emergencies, call **112** immediately.",
      timestamp: new Date(),
    }]);
    setError(null);
  };

  const formatTime = (date) => {
    return new Intl.DateTimeFormat('en-IN', {
      hour: '2-digit', minute: '2-digit', hour12: true
    }).format(date);
  };

  // ========== QUICK PROMPTS ==========
  const quickPrompts = [
    { label: '🤒 Fever & Chills', text: 'I have a high fever with chills and body ache since yesterday.' },
    { label: '🤧 Cold & Cough', text: 'I have a runny nose, sore throat, and persistent dry cough.' },
    { label: '💊 Chest Pain', text: 'I am experiencing chest pain and shortness of breath.' },
    { label: '🤕 Headache', text: 'I have a severe throbbing headache for the past few hours.' },
  ];

  return (
    <div className="triage-root">
      {/* ===== HEADER ===== */}
      <div className="triage-header">
        <div className="triage-header-left">
          <div className="triage-avatar">
            <span className="triage-avatar-icon">🩺</span>
            <span className="triage-online-dot" />
          </div>
          <div className="triage-header-info">
            <h1 className="triage-title">MediBot</h1>
            <span className="triage-subtitle">AI Disease Triage Assistant • Powered by Gemini</span>
          </div>
        </div>
        <div className="triage-header-actions">
          <button className="triage-header-btn" onClick={clearChat} title="Clear conversation">
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <polyline points="1 4 1 10 7 10"/><path d="M3.51 15a9 9 0 1 0 .49-3.1"/>
            </svg>
          </button>
        </div>
      </div>

      {/* ===== MESSAGES AREA ===== */}
      <div className="triage-messages">
        {/* Quick prompts - show only at start */}
        {messages.length === 1 && (
          <motion.div
            className="triage-quick-prompts"
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3 }}
          >
            <p className="triage-quick-label">Quick symptoms to describe:</p>
            <div className="triage-quick-grid">
              {quickPrompts.map((q, i) => (
                <motion.button
                  key={i}
                  className="triage-quick-btn"
                  onClick={() => { setInputText(q.text); textareaRef.current?.focus(); }}
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.4 + i * 0.08 }}
                >
                  {q.label}
                </motion.button>
              ))}
            </div>
          </motion.div>
        )}

        <AnimatePresence initial={false}>
          {messages.map((msg) => (
            <motion.div
              key={msg.id}
              className={`triage-message-row ${msg.role}`}
              initial={{ opacity: 0, y: 12, scale: 0.98 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              transition={{ duration: 0.28, ease: 'easeOut' }}
            >
              {msg.role === 'assistant' && (
                <div className="triage-msg-avatar bot-avatar">🩺</div>
              )}

              <div className={`triage-bubble ${msg.role}`}>
                {msg.image && (
                  <div className="triage-msg-image-wrap">
                    <img src={msg.image} alt="Uploaded symptom" className="triage-msg-image" />
                  </div>
                )}
                {msg.content && (
                  <div
                    className="triage-bubble-text"
                    dangerouslySetInnerHTML={{ __html: parseMarkdown(msg.content) }}
                  />
                )}
                <span className="triage-timestamp">{formatTime(msg.timestamp)}</span>
              </div>

              {msg.role === 'user' && (
                <div className="triage-msg-avatar user-avatar">👤</div>
              )}
            </motion.div>
          ))}
        </AnimatePresence>

        {/* Loading indicator */}
        <AnimatePresence>
          {isLoading && (
            <motion.div
              className="triage-message-row assistant"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0 }}
            >
              <div className="triage-msg-avatar bot-avatar">🩺</div>
              <div className="triage-bubble assistant triage-typing">
                <span /><span /><span />
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Error */}
        <AnimatePresence>
          {error && (
            <motion.div
              className="triage-error"
              initial={{ opacity: 0, y: 6 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0 }}
            >
              <span>⚠️ {error}</span>
              <button onClick={() => setError(null)}>✕</button>
            </motion.div>
          )}
        </AnimatePresence>

        <div ref={messagesEndRef} />
      </div>

      {/* ===== IMAGE PREVIEW ===== */}
      <AnimatePresence>
        {imagePreview && (
          <motion.div
            className="triage-image-preview"
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
          >
            <div className="triage-preview-inner">
              <img src={imagePreview} alt="Preview" className="triage-preview-thumb" />
              <div className="triage-preview-info">
                <span className="triage-preview-name">{uploadedImage?.name || 'Image attached'}</span>
                <span className="triage-preview-size">
                  {uploadedImage ? (uploadedImage.size / 1024).toFixed(0) + ' KB' : ''}
                </span>
              </div>
              <button className="triage-preview-remove" onClick={removeImage}>✕</button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* ===== INPUT AREA ===== */}
      <div className="triage-input-area">
        {/* Image options dropdown */}
        <AnimatePresence>
          {showImageOptions && (
            <motion.div
              className="triage-img-options"
              initial={{ opacity: 0, y: 8, scale: 0.95 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: 8, scale: 0.95 }}
              transition={{ duration: 0.15 }}
            >
              <button
                className="triage-img-option-btn"
                onClick={() => { fileInputRef.current?.click(); }}
              >
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                  <rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="8.5" cy="8.5" r="1.5"/>
                  <polyline points="21 15 16 10 5 21"/>
                </svg>
                Upload from Gallery
              </button>
              <button
                className="triage-img-option-btn"
                onClick={() => { cameraInputRef.current?.click(); }}
              >
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                  <path d="M23 19a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h4l2-3h6l2 3h4a2 2 0 0 1 2 2z"/>
                  <circle cx="12" cy="13" r="4"/>
                </svg>
                Take Photo
              </button>
            </motion.div>
          )}
        </AnimatePresence>

        <div className="triage-input-box">
          {/* Attach image button */}
          <button
            className={`triage-icon-btn ${imagePreview ? 'active' : ''}`}
            onClick={() => setShowImageOptions(v => !v)}
            title="Attach image"
            type="button"
          >
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="8.5" cy="8.5" r="1.5"/>
              <polyline points="21 15 16 10 5 21"/>
            </svg>
          </button>

          {/* Hidden file inputs */}
          <input
            ref={fileInputRef}
            type="file"
            accept="image/*"
            style={{ display: 'none' }}
            onChange={(e) => handleImageFile(e.target.files[0])}
          />
          <input
            ref={cameraInputRef}
            type="file"
            accept="image/*"
            capture="environment"
            style={{ display: 'none' }}
            onChange={(e) => handleImageFile(e.target.files[0])}
          />

          {/* Text area */}
          <textarea
            ref={textareaRef}
            className="triage-textarea"
            placeholder="Describe your symptoms… (e.g. fever, headache, rash)"
            value={inputText}
            onChange={handleTextareaChange}
            onKeyDown={handleKeyDown}
            rows={1}
            disabled={isLoading}
          />

          {/* Voice button */}
          <button
            className={`triage-icon-btn voice-btn ${isListening ? 'listening' : ''}`}
            onClick={toggleVoice}
            title={isListening ? 'Stop listening' : 'Voice input'}
            type="button"
          >
            {isListening ? (
              <svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor">
                <rect x="6" y="6" width="12" height="12" rx="2"/>
              </svg>
            ) : (
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <path d="M12 1a3 3 0 0 0-3 3v8a3 3 0 0 0 6 0V4a3 3 0 0 0-3-3z"/>
                <path d="M19 10v2a7 7 0 0 1-14 0v-2"/><line x1="12" y1="19" x2="12" y2="23"/>
                <line x1="8" y1="23" x2="16" y2="23"/>
              </svg>
            )}
          </button>

          {/* Send button */}
          <motion.button
            className={`triage-send-btn ${(inputText.trim() || imageBase64) && !isLoading ? 'enabled' : ''}`}
            onClick={handleSend}
            disabled={(!inputText.trim() && !imageBase64) || isLoading}
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            type="button"
          >
            {isLoading ? (
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" className="spin">
                <line x1="12" y1="2" x2="12" y2="6"/><line x1="12" y1="18" x2="12" y2="22"/>
                <line x1="4.93" y1="4.93" x2="7.76" y2="7.76"/><line x1="16.24" y1="16.24" x2="19.07" y2="19.07"/>
                <line x1="2" y1="12" x2="6" y2="12"/><line x1="18" y1="12" x2="22" y2="12"/>
                <line x1="4.93" y1="19.07" x2="7.76" y2="16.24"/><line x1="16.24" y1="7.76" x2="19.07" y2="4.93"/>
              </svg>
            ) : (
              <svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor">
                <path d="M2.01 21L23 12 2.01 3 2 10l15 2-15 2z"/>
              </svg>
            )}
          </motion.button>
        </div>

        <p className="triage-disclaimer">
          MediBot provides general guidance only. Not a substitute for professional medical advice. 
          <strong> Emergency? Call 112.</strong>
        </p>
      </div>
    </div>
  );
};

export default DiseaseTriage;