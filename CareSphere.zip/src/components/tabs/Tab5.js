import React, { useState, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import './Tab5.css';

/* ============================================
   DIGITAL PRESCRIPTION MANAGER COMPONENT
   
   Complete prescription management system with:
   - Prescription upload (drag & drop)
   - File preview and details
   - Prescription history and search
   - Medicine reminder system
   - Smart suggestions
   - Download, edit, delete functionality
   - Responsive design
   - Framer Motion animations
   ============================================ */

// Sample prescription data
const SAMPLE_PRESCRIPTIONS = [
  {
    id: 1,
    filename: 'prescription_001.pdf',
    fileType: 'pdf',
    uploadDate: '2024-01-15',
    doctorName: 'Dr. Rajesh Kumar',
    hospitalName: 'Apollo Hospital',
    illnessType: 'Common Cold',
    medicines: [
      { name: 'Crocin 500mg', dosage: '1 tablet', frequency: 'Twice daily', duration: '5 days' },
      { name: 'Strepsils', dosage: '1 lozenge', frequency: 'Every 4 hours', duration: '7 days' }
    ],
    followUpDate: '2024-01-22',
    status: 'Active',
    preview: '📄',
    notes: 'Rest and drink warm fluids'
  },
  {
    id: 2,
    filename: 'prescription_002.jpg',
    fileType: 'jpg',
    uploadDate: '2024-01-10',
    doctorName: 'Dr. Priya Singh',
    hospitalName: 'Max Healthcare',
    illnessType: 'Hypertension',
    medicines: [
      { name: 'Amlodipine 5mg', dosage: '1 tablet', frequency: 'Once daily', duration: '30 days' },
      { name: 'Lisinopril 10mg', dosage: '1 tablet', frequency: 'Once daily', duration: '30 days' }
    ],
    followUpDate: '2024-02-10',
    status: 'Active',
    preview: '🩺',
    notes: 'Monitor blood pressure daily'
  },
  {
    id: 3,
    filename: 'prescription_003.pdf',
    fileType: 'pdf',
    uploadDate: '2023-12-20',
    doctorName: 'Dr. Amit Patel',
    hospitalName: 'Fortis Healthcare',
    illnessType: 'Migraine',
    medicines: [
      { name: 'Aspirin 500mg', dosage: '1 tablet', frequency: 'As needed', duration: '15 days' },
      { name: 'Propranolol 40mg', dosage: '1 tablet', frequency: 'Once daily', duration: '30 days' }
    ],
    followUpDate: '2024-01-20',
    status: 'Completed',
    preview: '💊',
    notes: 'Avoid triggers like bright light and loud noise'
  },
  {
    id: 4,
    filename: 'prescription_004.png',
    fileType: 'png',
    uploadDate: '2023-12-10',
    doctorName: 'Dr. Sneha Sharma',
    hospitalName: 'Manipal Hospital',
    illnessType: 'Diabetes Type 2',
    medicines: [
      { name: 'Metformin 500mg', dosage: '1 tablet', frequency: 'Twice daily', duration: '30 days' },
      { name: 'Glipizide 5mg', dosage: '1 tablet', frequency: 'Once daily', duration: '30 days' }
    ],
    followUpDate: '2024-01-15',
    status: 'Active',
    preview: '🏥',
    notes: 'Check blood sugar levels regularly'
  }
];

const DigitalPrescription = () => {
  // ========== STATE MANAGEMENT ==========
  const [prescriptions, setPrescriptions] = useState(SAMPLE_PRESCRIPTIONS);
  const [dragActive, setDragActive] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [isUploading, setIsUploading] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [filterDoctor, setFilterDoctor] = useState('All');
  const [filterStatus, setFilterStatus] = useState('All');
  const [selectedPrescription, setSelectedPrescription] = useState(null);
  const [showDetailModal, setShowDetailModal] = useState(false);
  const [showEditModal, setShowEditModal] = useState(false);
  const [editFormData, setEditFormData] = useState(null);
  const [showReminderModal, setShowReminderModal] = useState(false);
  const [reminderData, setReminderData] = useState(null);
  const [medicineReminders, setMedicineReminders] = useState([]);
  const fileInputRef = useRef(null);

  // ========== UPLOAD HANDLERS ==========
  const handleDrag = (e) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === 'dragenter' || e.type === 'dragover') {
      setDragActive(true);
    } else if (e.type === 'dragleave') {
      setDragActive(false);
    }
  };

  const handleDrop = (e) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);

    const files = e.dataTransfer.files;
    if (files && files[0]) {
      processFile(files[0]);
    }
  };

  const handleFileInput = (e) => {
    const files = e.target.files;
    if (files && files[0]) {
      processFile(files[0]);
    }
  };

  const processFile = (file) => {
    const validTypes = ['application/pdf', 'image/jpeg', 'image/png'];
    if (!validTypes.includes(file.type)) {
      alert('Please upload PDF, JPG, or PNG files only');
      return;
    }

    setIsUploading(true);
    let progress = 0;

    const interval = setInterval(() => {
      progress += Math.random() * 30;
      if (progress > 100) progress = 100;
      setUploadProgress(progress);

      if (progress === 100) {
        clearInterval(interval);
        setTimeout(() => {
          // Create new prescription object
          const newPrescription = {
            id: prescriptions.length + 1,
            filename: file.name,
            fileType: file.type.split('/')[1],
            uploadDate: new Date().toISOString().split('T')[0],
            doctorName: 'To be filled',
            hospitalName: 'To be filled',
            illnessType: 'To be filled',
            medicines: [],
            followUpDate: '',
            status: 'Active',
            preview: '📄',
            notes: ''
          };

          setPrescriptions([newPrescription, ...prescriptions]);
          setSelectedPrescription(newPrescription);
          setEditFormData(newPrescription);
          setShowEditModal(true);
          setIsUploading(false);
          setUploadProgress(0);
        }, 500);
      }
    }, 300);
  };

  // ========== FILTER & SEARCH ==========
  const filteredPrescriptions = prescriptions.filter(prescription => {
    const matchesSearch = prescription.illnessType.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         prescription.doctorName.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         prescription.hospitalName.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesDoctor = filterDoctor === 'All' || prescription.doctorName === filterDoctor;
    const matchesStatus = filterStatus === 'All' || prescription.status === filterStatus;
    return matchesSearch && matchesDoctor && matchesStatus;
  });

  const uniqueDoctors = ['All', ...new Set(prescriptions.map(p => p.doctorName))];

  // ========== PRESCRIPTION ACTIONS ==========
  const handleViewPrescription = (prescription) => {
    setSelectedPrescription(prescription);
    setShowDetailModal(true);
  };

  const handleDownload = (prescription) => {
    alert(`Downloading ${prescription.filename}...`);
  };

  const handleEditPrescription = (prescription) => {
    setEditFormData({ ...prescription });
    setSelectedPrescription(prescription);
    setShowEditModal(true);
  };

  const handleSaveEdit = () => {
    const updated = prescriptions.map(p => 
      p.id === editFormData.id ? editFormData : p
    );
    setPrescriptions(updated);
    setShowEditModal(false);
    alert('Prescription details updated successfully!');
  };

  const handleDeletePrescription = (id) => {
    if (window.confirm('Are you sure you want to delete this prescription?')) {
      setPrescriptions(prescriptions.filter(p => p.id !== id));
      alert('Prescription deleted successfully!');
    }
  };

  const handleSetReminder = (prescription, medicine) => {
    setReminderData({ prescription, medicine });
    setShowReminderModal(true);
  };

  const handleSaveReminder = (reminderTime, frequency) => {
    const reminder = {
      id: medicineReminders.length + 1,
      prescriptionId: reminderData.prescription.id,
      medicineName: reminderData.medicine.name,
      time: reminderTime,
      frequency: frequency,
      createdDate: new Date().toLocaleDateString()
    };
    setMedicineReminders([...medicineReminders, reminder]);
    setShowReminderModal(false);
    alert(`Reminder set for ${reminderData.medicine.name} at ${reminderTime}`);
  };

  // ========== ANIMATION VARIANTS ==========
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: { staggerChildren: 0.1, delayChildren: 0.2 }
    }
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: { opacity: 1, y: 0, transition: { duration: 0.5 } }
  };

  const cardVariants = {
    hidden: { opacity: 0, scale: 0.95, y: 20 },
    visible: {
      opacity: 1,
      scale: 1,
      y: 0,
      transition: { duration: 0.4 }
    },
    hover: {
      y: -8,
      boxShadow: '0 20px 40px rgba(0,0,0,0.1)',
      transition: { duration: 0.3 }
    }
  };

  return (
    <motion.div
      className="digital-prescription-container"
      variants={containerVariants}
      initial="hidden"
      animate="visible"
    >
      {/* ========== HEADER ========== */}
      <motion.div className="prescription-header" variants={itemVariants}>
        <h2>
          <span className="header-icon">📋</span>
          Digital Prescription Manager
        </h2>
        <p>Upload and manage your medical prescriptions securely in one place</p>
      </motion.div>

      {/* ========== UPLOAD SECTION ========== */}
      <motion.div
        className={`upload-section ${dragActive ? 'drag-active' : ''}`}
        onDragEnter={handleDrag}
        onDragLeave={handleDrag}
        onDragOver={handleDrag}
        onDrop={handleDrop}
        variants={itemVariants}
      >
        <div className="upload-content">
          {isUploading ? (
            <motion.div className="uploading-state" initial={{ opacity: 0 }} animate={{ opacity: 1 }}>
              <motion.div
                className="upload-spinner"
                animate={{ rotate: 360 }}
                transition={{ repeat: Infinity, duration: 1 }}
              >
                ⏳
              </motion.div>
              <p className="upload-text">Uploading prescription...</p>
              <div className="progress-bar">
                <motion.div
                  className="progress-fill"
                  initial={{ width: 0 }}
                  animate={{ width: `${uploadProgress}%` }}
                  transition={{ duration: 0.3 }}
                />
              </div>
              <p className="upload-percent">{Math.round(uploadProgress)}%</p>
            </motion.div>
          ) : (
            <>
              <div className="upload-icon">📁</div>
              <h3>Upload Your Prescription</h3>
              <p>Drag and drop your prescription or click to browse</p>
              <p className="upload-formats">Supported formats: PDF, JPG, PNG (Max 10MB)</p>
              <motion.button
                className="upload-btn"
                onClick={() => fileInputRef.current?.click()}
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
              >
                Choose File
              </motion.button>
              <input
                ref={fileInputRef}
                type="file"
                onChange={handleFileInput}
                accept=".pdf,.jpg,.jpeg,.png"
                style={{ display: 'none' }}
              />
            </>
          )}
        </div>
      </motion.div>

      {/* ========== SEARCH & FILTER SECTION ========== */}
      <motion.div className="search-filter-section" variants={itemVariants}>
        <div className="search-container">
          <input
            type="text"
            placeholder="Search by illness or doctor name..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="search-input"
          />
          <span className="search-icon">🔍</span>
        </div>

        <div className="filter-container">
          <select
            value={filterDoctor}
            onChange={(e) => setFilterDoctor(e.target.value)}
            className="filter-select"
          >
            {uniqueDoctors.map(doctor => (
              <option key={doctor} value={doctor}>{doctor}</option>
            ))}
          </select>

          <select
            value={filterStatus}
            onChange={(e) => setFilterStatus(e.target.value)}
            className="filter-select"
          >
            <option value="All">All Status</option>
            <option value="Active">Active</option>
            <option value="Completed">Completed</option>
          </select>
        </div>
      </motion.div>

      {/* ========== PRESCRIPTIONS LIST ========== */}
      <motion.div className="prescriptions-section" variants={containerVariants}>
        <h3 className="section-title">
          Your Prescriptions ({filteredPrescriptions.length})
        </h3>

        {filteredPrescriptions.length > 0 ? (
          <motion.div className="prescriptions-grid" variants={containerVariants}>
            {filteredPrescriptions.map(prescription => (
              <motion.div
                key={prescription.id}
                className="prescription-card"
                variants={cardVariants}
                whileHover="hover"
              >
                {/* Card Header */}
                <div className="card-header">
                  <div className="prescription-preview">{prescription.preview}</div>
                  <div className="card-header-info">
                    <h4>{prescription.illnessType}</h4>
                    <p className="doctor-name">Dr. {prescription.doctorName}</p>
                    <span className={`status-badge ${prescription.status.toLowerCase()}`}>
                      {prescription.status}
                    </span>
                  </div>
                </div>

                {/* Card Content */}
                <div className="card-content">
                  <div className="info-row">
                    <span className="info-icon">🏥</span>
                    <span className="info-text">{prescription.hospitalName}</span>
                  </div>
                  <div className="info-row">
                    <span className="info-icon">📅</span>
                    <span className="info-text">{new Date(prescription.uploadDate).toLocaleDateString()}</span>
                  </div>
                  <div className="info-row">
                    <span className="info-icon">💊</span>
                    <span className="info-text">
                      {prescription.medicines.length} medicine{prescription.medicines.length !== 1 ? 's' : ''}
                    </span>
                  </div>
                  {prescription.followUpDate && (
                    <div className="info-row">
                      <span className="info-icon">📌</span>
                      <span className="info-text">
                        Follow-up: {new Date(prescription.followUpDate).toLocaleDateString()}
                      </span>
                    </div>
                  )}
                </div>

                {/* Smart Suggestions */}
                <div className="suggestions">
                  <motion.button
                    className="suggestion-btn"
                    whileHover={{ scale: 1.02 }}
                    whileTap={{ scale: 0.98 }}
                    onClick={() => handleSetReminder(prescription, prescription.medicines[0])}
                  >
                    🔔 Medicine Reminder
                  </motion.button>
                  <motion.button
                    className="suggestion-btn"
                    whileHover={{ scale: 1.02 }}
                    whileTap={{ scale: 0.98 }}
                    onClick={() => alert('Redirecting to appointment booking...')}
                  >
                    📅 Book Follow-up
                  </motion.button>
                </div>

                {/* Card Actions */}
                <div className="card-actions">
                  <motion.button
                    className="action-btn view"
                    onClick={() => handleViewPrescription(prescription)}
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                  >
                    👁️ View
                  </motion.button>
                  <motion.button
                    className="action-btn download"
                    onClick={() => handleDownload(prescription)}
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                  >
                    ⬇️ Download
                  </motion.button>
                  <motion.button
                    className="action-btn edit"
                    onClick={() => handleEditPrescription(prescription)}
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                  >
                    ✏️ Edit
                  </motion.button>
                  <motion.button
                    className="action-btn delete"
                    onClick={() => handleDeletePrescription(prescription.id)}
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                  >
                    🗑️ Delete
                  </motion.button>
                </div>
              </motion.div>
            ))}
          </motion.div>
        ) : (
          <motion.div className="no-results" variants={itemVariants}>
            <p className="no-results-icon">📭</p>
            <p>No prescriptions found. Upload your first prescription to get started!</p>
          </motion.div>
        )}
      </motion.div>

      {/* ========== DETAIL MODAL ========== */}
      <AnimatePresence>
        {showDetailModal && selectedPrescription && (
          <motion.div
            className="modal-overlay"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={() => setShowDetailModal(false)}
          >
            <motion.div
              className="modal-content detail-modal"
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              onClick={(e) => e.stopPropagation()}
            >
              <button
                className="modal-close"
                onClick={() => setShowDetailModal(false)}
              >
                ✕
              </button>

              <h3>Prescription Details</h3>
              
              <div className="modal-section">
                <h4>Medical Information</h4>
                <div className="detail-row">
                  <span className="label">Illness Type:</span>
                  <span className="value">{selectedPrescription.illnessType}</span>
                </div>
                <div className="detail-row">
                  <span className="label">Doctor:</span>
                  <span className="value">Dr. {selectedPrescription.doctorName}</span>
                </div>
                <div className="detail-row">
                  <span className="label">Hospital/Clinic:</span>
                  <span className="value">{selectedPrescription.hospitalName}</span>
                </div>
              </div>

              <div className="modal-section">
                <h4>Medicines Prescribed ({selectedPrescription.medicines.length})</h4>
                {selectedPrescription.medicines.map((medicine, idx) => (
                  <div key={idx} className="medicine-item">
                    <p className="medicine-name">💊 {medicine.name}</p>
                    <p className="medicine-detail">Dosage: {medicine.dosage}</p>
                    <p className="medicine-detail">Frequency: {medicine.frequency}</p>
                    <p className="medicine-detail">Duration: {medicine.duration}</p>
                  </div>
                ))}
              </div>

              {selectedPrescription.notes && (
                <div className="modal-section">
                  <h4>Additional Notes</h4>
                  <p>{selectedPrescription.notes}</p>
                </div>
              )}

              <div className="modal-actions">
                <motion.button
                  className="modal-btn primary"
                  onClick={() => handleDownload(selectedPrescription)}
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                >
                  ⬇️ Download
                </motion.button>
                <motion.button
                  className="modal-btn secondary"
                  onClick={() => setShowDetailModal(false)}
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                >
                  Close
                </motion.button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* ========== EDIT MODAL ========== */}
      <AnimatePresence>
        {showEditModal && editFormData && (
          <motion.div
            className="modal-overlay"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={() => setShowEditModal(false)}
          >
            <motion.div
              className="modal-content edit-modal"
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              onClick={(e) => e.stopPropagation()}
            >
              <button
                className="modal-close"
                onClick={() => setShowEditModal(false)}
              >
                ✕
              </button>

              <h3>Edit Prescription Details</h3>

              <div className="form-group">
                <label>Doctor Name:</label>
                <input
                  type="text"
                  value={editFormData.doctorName}
                  onChange={(e) => setEditFormData({ ...editFormData, doctorName: e.target.value })}
                />
              </div>

              <div className="form-group">
                <label>Hospital/Clinic:</label>
                <input
                  type="text"
                  value={editFormData.hospitalName}
                  onChange={(e) => setEditFormData({ ...editFormData, hospitalName: e.target.value })}
                />
              </div>

              <div className="form-group">
                <label>Illness Type:</label>
                <input
                  type="text"
                  value={editFormData.illnessType}
                  onChange={(e) => setEditFormData({ ...editFormData, illnessType: e.target.value })}
                />
              </div>

              <div className="form-group">
                <label>Follow-up Date:</label>
                <input
                  type="date"
                  value={editFormData.followUpDate}
                  onChange={(e) => setEditFormData({ ...editFormData, followUpDate: e.target.value })}
                />
              </div>

              <div className="form-group">
                <label>Notes:</label>
                <textarea
                  value={editFormData.notes}
                  onChange={(e) => setEditFormData({ ...editFormData, notes: e.target.value })}
                  rows="3"
                />
              </div>

              <div className="modal-actions">
                <motion.button
                  className="modal-btn primary"
                  onClick={handleSaveEdit}
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                >
                  💾 Save Changes
                </motion.button>
                <motion.button
                  className="modal-btn secondary"
                  onClick={() => setShowEditModal(false)}
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                >
                  Cancel
                </motion.button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* ========== REMINDER MODAL ========== */}
      <AnimatePresence>
        {showReminderModal && reminderData && (
          <motion.div
            className="modal-overlay"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={() => setShowReminderModal(false)}
          >
            <motion.div
              className="modal-content reminder-modal"
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              onClick={(e) => e.stopPropagation()}
            >
              <button
                className="modal-close"
                onClick={() => setShowReminderModal(false)}
              >
                ✕
              </button>

              <h3>🔔 Set Medicine Reminder</h3>
              <p className="reminder-medicine">Medicine: {reminderData.medicine.name}</p>

              <ReminderForm 
                onSave={handleSaveReminder}
                onCancel={() => setShowReminderModal(false)}
              />
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.div>
  );
};

// ========== REMINDER FORM COMPONENT ==========
const ReminderForm = ({ onSave, onCancel }) => {
  const [reminderTime, setReminderTime] = useState('09:00');
  const [frequency, setFrequency] = useState('daily');

  return (
    <div className="reminder-form">
      <div className="form-group">
        <label>Reminder Time:</label>
        <input
          type="time"
          value={reminderTime}
          onChange={(e) => setReminderTime(e.target.value)}
        />
      </div>

      <div className="form-group">
        <label>Frequency:</label>
        <select value={frequency} onChange={(e) => setFrequency(e.target.value)}>
          <option value="once">Once</option>
          <option value="daily">Daily</option>
          <option value="weekly">Weekly</option>
        </select>
      </div>

      <div className="form-actions">
        <motion.button
          className="form-btn primary"
          onClick={() => onSave(reminderTime, frequency)}
          whileHover={{ scale: 1.02 }}
          whileTap={{ scale: 0.98 }}
        >
          Set Reminder
        </motion.button>
        <motion.button
          className="form-btn secondary"
          onClick={onCancel}
          whileHover={{ scale: 1.02 }}
          whileTap={{ scale: 0.98 }}
        >
          Cancel
        </motion.button>
      </div>
    </div>
  );
};

export default DigitalPrescription;