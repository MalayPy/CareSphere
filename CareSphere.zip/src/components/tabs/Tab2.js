import React, { useState, useMemo } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import './Tab2.css';

/* ============================================
   DOCTOR FINDER COMPONENT
   
   Complete healthcare doctor finder with:
   - Search & filter functionality
   - Doctor cards with details
   - Appointment booking modal
   - Date/time slot selection
   - Payment integration UI
   - Responsive design
   - Framer Motion animations
   ============================================ */

// Sample doctor data
const DOCTOR_DATA = [
  {
    id: 1,
    name: 'Dr. Rajesh Kumar',
    speciality: 'Cardiologist',
    degree: 'MD (Cardiology), MBBS',
    experience: 15,
    rating: 4.8,
    reviews: 245,
    image: '👨‍⚕️',
    location: 'Apollo Hospital, Connaught Place, Delhi',
    distance: 2.5,
    consultationFee: 500,
    available: true,
    about: 'Experienced cardiologist specializing in cardiac care'
  },
  {
    id: 2,
    name: 'Dr. Priya Singh',
    speciality: 'Dermatologist',
    degree: 'MD (Dermatology), MBBS, FAAD',
    experience: 12,
    rating: 4.9,
    reviews: 198,
    image: '👩‍⚕️',
    location: 'Fortis Hospital, Andheri, Mumbai',
    distance: 3.2,
    consultationFee: 450,
    available: true,
    about: 'Specialist in skin diseases and cosmetic treatments'
  },
  {
    id: 3,
    name: 'Dr. Amit Patel',
    speciality: 'General Physician',
    degree: 'MBBS, MD (General Medicine)',
    experience: 18,
    rating: 4.7,
    reviews: 312,
    image: '👨‍⚕️',
    location: 'Max Hospital, Saket, Delhi',
    distance: 1.8,
    consultationFee: 300,
    available: true,
    about: 'General practice doctor with extensive experience'
  },
  {
    id: 4,
    name: 'Dr. Sneha Sharma',
    speciality: 'Pediatrician',
    degree: 'MD (Pediatrics), MBBS, DCH',
    experience: 10,
    rating: 4.6,
    reviews: 156,
    image: '👩‍⚕️',
    location: 'Manipal Hospital, Whitefield, Bangalore',
    distance: 4.1,
    consultationFee: 400,
    available: true,
    about: 'Child health specialist with pediatric expertise'
  },
  {
    id: 5,
    name: 'Dr. Vikas Gupta',
    speciality: 'Orthopedic Surgeon',
    degree: 'MS (Orthopedics), MBBS, AIIMS',
    experience: 16,
    rating: 4.8,
    reviews: 267,
    image: '👨‍⚕️',
    location: 'Deenanath Mangeshkar Hospital, Pune',
    distance: 5.3,
    consultationFee: 600,
    available: true,
    about: 'Expert in orthopedic surgery and joint treatment'
  },
  {
    id: 6,
    name: 'Dr. Neha Desai',
    speciality: 'Gynecologist',
    degree: 'MD (Obstetrics & Gynecology), MBBS',
    experience: 14,
    rating: 4.9,
    reviews: 223,
    image: '👩‍⚕️',
    location: 'Apollo Hospital, Greams Road, Chennai',
    distance: 6.2,
    consultationFee: 550,
    available: true,
    about: 'Specialist in women health and reproductive medicine'
  },
  {
    id: 7,
    name: 'Dr. Rohan Verma',
    speciality: 'Psychiatrist',
    degree: 'MD (Psychiatry), MBBS, NeuroPsych',
    experience: 11,
    rating: 4.7,
    reviews: 189,
    image: '👨‍⚕️',
    location: 'Rajendra Place Medical Center, Delhi',
    distance: 2.9,
    consultationFee: 400,
    available: true,
    about: 'Mental health specialist with counseling expertise'
  },
  {
    id: 8,
    name: 'Dr. Pooja Nair',
    speciality: 'ENT Specialist',
    degree: 'MS (ENT), MBBS, DLO',
    experience: 13,
    rating: 4.8,
    reviews: 201,
    image: '👩‍⚕️',
    location: 'CARE Hospital, Somajiguda, Hyderabad',
    distance: 3.7,
    consultationFee: 450,
    available: true,
    about: 'Ear, nose and throat specialist'
  }
];

// Time slots for appointments
const TIME_SLOTS = [
  '09:00 AM', '09:30 AM', '10:00 AM', '10:30 AM',
  '11:00 AM', '11:30 AM', '02:00 PM', '02:30 PM',
  '03:00 PM', '03:30 PM', '04:00 PM', '04:30 PM',
  '05:00 PM', '05:30 PM', '06:00 PM'
];

// Specialities list
const SPECIALITIES = [
  'All Specialities',
  'Cardiologist',
  'Dermatologist',
  'General Physician',
  'Pediatrician',
  'Orthopedic Surgeon',
  'Gynecologist',
  'Psychiatrist',
  'ENT Specialist'
];

const DoctorFinder = () => {
  // ========== STATE MANAGEMENT ==========
  const [searchLocation, setSearchLocation] = useState('');
  const [selectedSpeciality, setSelectedSpeciality] = useState('All Specialities');
  const [selectedDoctor, setSelectedDoctor] = useState(null);
  const [showBookingModal, setShowBookingModal] = useState(false);
  const [selectedDate, setSelectedDate] = useState('');
  const [selectedTime, setSelectedTime] = useState('');
  const [showPaymentModal, setShowPaymentModal] = useState(false);
  const [selectedPayment, setSelectedPayment] = useState('');

  // ========== FILTERED DOCTORS ==========
  const filteredDoctors = useMemo(() => {
    return DOCTOR_DATA.filter(doctor => {
      const locationMatch = doctor.location.toLowerCase().includes(searchLocation.toLowerCase());
      const specialityMatch = selectedSpeciality === 'All Specialities' || doctor.speciality === selectedSpeciality;
      return locationMatch && specialityMatch;
    });
  }, [searchLocation, selectedSpeciality]);

  // ========== GET NEXT 7 DAYS ==========
  const getNextSevenDays = () => {
    const days = [];
    for (let i = 0; i < 7; i++) {
      const date = new Date();
      date.setDate(date.getDate() + i);
      const formatted = date.toISOString().split('T')[0];
      const display = date.toLocaleDateString('en-US', { 
        weekday: 'short', 
        month: 'short', 
        day: 'numeric' 
      });
      days.push({ date: formatted, display });
    }
    return days;
  };

  const nextSevenDays = getNextSevenDays();

  // ========== HANDLERS ==========
  const handleBookAppointment = (doctor) => {
    setSelectedDoctor(doctor);
    setShowBookingModal(true);
    setSelectedDate('');
    setSelectedTime('');
  };

  const handleConfirmBooking = () => {
    if (!selectedDate || !selectedTime) {
      alert('Please select both date and time');
      return;
    }
    setShowBookingModal(false);
    setShowPaymentModal(true);
  };

  const handlePaymentSubmit = (method) => {
    if (!method) {
      alert('Please select a payment method');
      return;
    }
    alert(`Appointment booked successfully!\n\nDoctor: ${selectedDoctor.name}\nDate: ${selectedDate}\nTime: ${selectedTime}\nPayment: ${method}\nFee: ₹${selectedDoctor.consultationFee}`);
    setShowPaymentModal(false);
    setSelectedPayment('');
  };

  // ========== ANIMATION VARIANTS ==========
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: { staggerChildren: 0.1, delayChildren: 0.2 }
    }
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: { opacity: 1, y: 0, transition: { duration: 0.5 } }
  };

  const cardVariants = {
    hidden: { opacity: 0, scale: 0.95, y: 20 },
    visible: { 
      opacity: 1, 
      scale: 1, 
      y: 0,
      transition: { duration: 0.4 }
    },
    hover: { 
      y: -8, 
      boxShadow: '0 20px 40px rgba(0,0,0,0.1)',
      transition: { duration: 0.3 }
    }
  };

  const modalVariants = {
    hidden: { opacity: 0, scale: 0.9 },
    visible: { 
      opacity: 1, 
      scale: 1,
      transition: { duration: 0.3 }
    },
    exit: { 
      opacity: 0, 
      scale: 0.9,
      transition: { duration: 0.2 }
    }
  };

  return (
    <motion.div 
      className="doctor-finder-container"
      variants={containerVariants}
      initial="hidden"
      animate="visible"
    >
      {/* ========== HEADER ========== */}
      <motion.div className="finder-header" variants={itemVariants}>
        <h2>
          <span className="header-icon">🩺</span>
          Find Your Doctor
        </h2>
        <p>Book appointments with verified healthcare professionals</p>
      </motion.div>

      {/* ========== SEARCH & FILTER SECTION ========== */}
      <motion.div className="search-filter-section" variants={itemVariants}>
        <div className="search-container">
          <input
            type="text"
            placeholder="Search by location (city or area)..."
            value={searchLocation}
            onChange={(e) => setSearchLocation(e.target.value)}
            className="search-input"
          />
          <span className="search-icon">🔍</span>
        </div>

        <div className="filter-container">
          <label>Speciality:</label>
          <select
            value={selectedSpeciality}
            onChange={(e) => setSelectedSpeciality(e.target.value)}
            className="filter-select"
          >
            {SPECIALITIES.map(spec => (
              <option key={spec} value={spec}>{spec}</option>
            ))}
          </select>
        </div>
      </motion.div>

      {/* ========== RESULTS INFO ========== */}
      <motion.div className="results-info" variants={itemVariants}>
        <p>Found <span className="result-count">{filteredDoctors.length}</span> doctors</p>
      </motion.div>

      {/* ========== DOCTORS GRID ========== */}
      <motion.div 
        className="doctors-grid"
        variants={containerVariants}
      >
        {filteredDoctors.length > 0 ? (
          filteredDoctors.map(doctor => (
            <motion.div
              key={doctor.id}
              className="doctor-card"
              variants={cardVariants}
              whileHover="hover"
            >
              {/* Doctor Image */}
              <div className="doctor-image">
                <div className="image-placeholder">{doctor.image}</div>
                <div className="availability-badge">
                  <span className="badge-dot">●</span> Available
                </div>
              </div>

              {/* Doctor Info */}
              <div className="doctor-info">
                <h3>{doctor.name}</h3>
                <p className="speciality">{doctor.speciality}</p>
                
                {/* Degree Section */}
                <p className="degree">
                  <span className="degree-icon">🎓</span>
                  {doctor.degree}
                </p>

                {/* Location Section */}
                <p className="location-info">
                  <span className="location-icon">📍</span>
                  {doctor.location}
                </p>
                
                {/* Rating */}
                <div className="rating-section">
                  <div className="stars">
                    {'⭐'.repeat(Math.floor(doctor.rating))}
                    <span className="rating-number">{doctor.rating}</span>
                  </div>
                  <span className="reviews">({doctor.reviews} reviews)</span>
                </div>

                {/* Details */}
                <div className="details-section">
                  <div className="detail-item">
                    <span className="detail-icon">👤</span>
                    <span className="detail-text">{doctor.experience} years experience</span>
                  </div>
                  <div className="detail-item">
                    <span className="detail-icon">📏</span>
                    <span className="detail-text">{doctor.distance} km away</span>
                  </div>
                  <div className="detail-item">
                    <span className="detail-icon">💰</span>
                    <span className="detail-text">₹{doctor.consultationFee}</span>
                  </div>
                </div>

                <p className="about-text">{doctor.about}</p>

                {/* Book Button */}
                <motion.button
                  className="book-btn"
                  onClick={() => handleBookAppointment(doctor)}
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                >
                  📅 Book Appointment
                </motion.button>
              </div>
            </motion.div>
          ))
        ) : (
          <motion.div className="no-results" variants={itemVariants}>
            <p className="no-results-icon">🔍</p>
            <p>No doctors found matching your criteria. Try adjusting your filters.</p>
          </motion.div>
        )}
      </motion.div>

      {/* ========== BOOKING MODAL ========== */}
      <AnimatePresence>
        {showBookingModal && selectedDoctor && (
          <motion.div
            className="modal-overlay"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={() => setShowBookingModal(false)}
          >
            <motion.div
              className="modal-content booking-modal"
              variants={modalVariants}
              initial="hidden"
              animate="visible"
              exit="exit"
              onClick={(e) => e.stopPropagation()}
            >
              {/* Close Button */}
              <button
                className="close-btn"
                onClick={() => setShowBookingModal(false)}
              >
                ✕
              </button>

              {/* Modal Header */}
              <div className="modal-header">
                <h3>
                  <span className="modal-icon">📅</span>
                  Book Appointment with {selectedDoctor.name}
                </h3>
                <p>{selectedDoctor.speciality}</p>
              </div>

              {/* Date Selection */}
              <div className="modal-section">
                <h4>Select Date</h4>
                <div className="date-selection">
                  {nextSevenDays.map(day => (
                    <motion.button
                      key={day.date}
                      className={`date-btn ${selectedDate === day.date ? 'selected' : ''}`}
                      onClick={() => setSelectedDate(day.date)}
                      whileHover={{ scale: 1.05 }}
                      whileTap={{ scale: 0.95 }}
                    >
                      {day.display}
                    </motion.button>
                  ))}
                </div>
              </div>

              {/* Time Selection */}
              {selectedDate && (
                <motion.div
                  className="modal-section"
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                >
                  <h4>Select Time Slot</h4>
                  <div className="time-selection">
                    {TIME_SLOTS.map(time => (
                      <motion.button
                        key={time}
                        className={`time-btn ${selectedTime === time ? 'selected' : ''}`}
                        onClick={() => setSelectedTime(time)}
                        whileHover={{ scale: 1.05 }}
                        whileTap={{ scale: 0.95 }}
                      >
                        {time}
                      </motion.button>
                    ))}
                  </div>
                </motion.div>
              )}

              {/* Summary */}
              {selectedDate && selectedTime && (
                <motion.div
                  className="booking-summary"
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                >
                  <h4>Appointment Summary</h4>
                  <div className="summary-item">
                    <span>Doctor:</span>
                    <span>{selectedDoctor.name}</span>
                  </div>
                  <div className="summary-item">
                    <span>Qualification:</span>
                    <span>{selectedDoctor.degree}</span>
                  </div>
                  <div className="summary-item">
                    <span>Speciality:</span>
                    <span>{selectedDoctor.speciality}</span>
                  </div>
                  <div className="summary-item">
                    <span>Location:</span>
                    <span>{selectedDoctor.location}</span>
                  </div>
                  <div className="summary-item">
                    <span>Date:</span>
                    <span>{new Date(selectedDate).toLocaleDateString()}</span>
                  </div>
                  <div className="summary-item">
                    <span>Time:</span>
                    <span>{selectedTime}</span>
                  </div>
                  <div className="summary-item total">
                    <span>Consultation Fee:</span>
                    <span>₹{selectedDoctor.consultationFee}</span>
                  </div>
                </motion.div>
              )}

              {/* Modal Buttons */}
              <div className="modal-buttons">
                <motion.button
                  className="btn-secondary"
                  onClick={() => setShowBookingModal(false)}
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                >
                  Cancel
                </motion.button>
                <motion.button
                  className="btn-primary"
                  onClick={handleConfirmBooking}
                  disabled={!selectedDate || !selectedTime}
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                >
                  Continue to Payment
                </motion.button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* ========== PAYMENT MODAL ========== */}
      <AnimatePresence>
        {showPaymentModal && selectedDoctor && (
          <motion.div
            className="modal-overlay"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={() => setShowPaymentModal(false)}
          >
            <motion.div
              className="modal-content payment-modal"
              variants={modalVariants}
              initial="hidden"
              animate="visible"
              exit="exit"
              onClick={(e) => e.stopPropagation()}
            >
              {/* Close Button */}
              <button
                className="close-btn"
                onClick={() => setShowPaymentModal(false)}
              >
                ✕
              </button>

              {/* Modal Header */}
              <div className="modal-header">
                <h3>
                  <span className="modal-icon">💳</span>
                  Complete Payment
                </h3>
                <p>Secure payment for your appointment</p>
              </div>

              {/* Appointment Summary */}
              <div className="payment-summary">
                <div className="summary-item">
                  <span>Doctor:</span>
                  <span>{selectedDoctor.name}</span>
                </div>
                <div className="summary-item">
                  <span>Qualification:</span>
                  <span>{selectedDoctor.degree}</span>
                </div>
                <div className="summary-item">
                  <span>Location:</span>
                  <span>{selectedDoctor.location}</span>
                </div>
                <div className="summary-item">
                  <span>Date & Time:</span>
                  <span>{new Date(selectedDate).toLocaleDateString()} at {selectedTime}</span>
                </div>
                <div className="summary-item total">
                  <span>Amount to Pay:</span>
                  <span className="amount">₹{selectedDoctor.consultationFee}</span>
                </div>
              </div>

              {/* Payment Methods */}
              <div className="modal-section">
                <h4>Select Payment Method</h4>
                <div className="payment-methods">
                  {/* UPI */}
                  <motion.label
                    className={`payment-option ${selectedPayment === 'upi' ? 'selected' : ''}`}
                    whileHover={{ scale: 1.02 }}
                  >
                    <input
                      type="radio"
                      name="payment"
                      value="upi"
                      checked={selectedPayment === 'upi'}
                      onChange={(e) => setSelectedPayment(e.target.value)}
                    />
                    <div className="payment-option-content">
                      <span className="payment-icon">📱</span>
                      <div>
                        <p className="payment-method-name">UPI</p>
                        <p className="payment-method-desc">Google Pay, PhonePe, Paytm</p>
                      </div>
                    </div>
                  </motion.label>

                  {/* Credit/Debit Card */}
                  <motion.label
                    className={`payment-option ${selectedPayment === 'card' ? 'selected' : ''}`}
                    whileHover={{ scale: 1.02 }}
                  >
                    <input
                      type="radio"
                      name="payment"
                      value="card"
                      checked={selectedPayment === 'card'}
                      onChange={(e) => setSelectedPayment(e.target.value)}
                    />
                    <div className="payment-option-content">
                      <span className="payment-icon">💳</span>
                      <div>
                        <p className="payment-method-name">Credit/Debit Card</p>
                        <p className="payment-method-desc">Visa, Mastercard, Amex</p>
                      </div>
                    </div>
                  </motion.label>

                  {/* Net Banking */}
                  <motion.label
                    className={`payment-option ${selectedPayment === 'netbanking' ? 'selected' : ''}`}
                    whileHover={{ scale: 1.02 }}
                  >
                    <input
                      type="radio"
                      name="payment"
                      value="netbanking"
                      checked={selectedPayment === 'netbanking'}
                      onChange={(e) => setSelectedPayment(e.target.value)}
                    />
                    <div className="payment-option-content">
                      <span className="payment-icon">🏦</span>
                      <div>
                        <p className="payment-method-name">Net Banking</p>
                        <p className="payment-method-desc">All major banks</p>
                      </div>
                    </div>
                  </motion.label>
                </div>
              </div>

              {/* Security Notice */}
              <div className="security-notice">
                <span className="security-icon">🔒</span>
                <span>Your payment is secure and encrypted</span>
              </div>

              {/* Modal Buttons */}
              <div className="modal-buttons">
                <motion.button
                  className="btn-secondary"
                  onClick={() => setShowPaymentModal(false)}
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                >
                  Back
                </motion.button>
                <motion.button
                  className="btn-primary"
                  onClick={() => handlePaymentSubmit(selectedPayment)}
                  disabled={!selectedPayment}
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                >
                  Pay ₹{selectedDoctor.consultationFee}
                </motion.button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.div>
  );
};

export default DoctorFinder;