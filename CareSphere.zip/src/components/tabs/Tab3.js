import React, { useState, useMemo } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import './Tab3.css';

/* ============================================
   MEDICINE FINDER COMPONENT
   
   Complete pharmacy medicine finder with:
   - Medicine search functionality
   - Distance filter
   - Pharmacy cards with availability
   - Store status display
   - Location map preview
   - Responsive design
   - Framer Motion animations
   ============================================ */

// Sample pharmacy data
const PHARMACY_DATA = [
  {
    id: 1,
    name: 'MediCare Pharmacy',
    address: '45 MG Road, Connaught Place, Delhi',
    icon: '💊',
    distance: 0.8,
    medicinePrice: 150,
    availability: 'Available',
    storeStatus: 'Open',
    openTime: '08:00 AM',
    closeTime: '10:00 PM',
    rating: 4.8,
    reviews: 342,
    latitude: 28.6328,
    longitude: 77.2197,
    image: '🏪'
  },
  {
    id: 2,
    name: 'Apollo Pharmacy',
    address: '123 Delhi Avenue, Central Delhi',
    icon: '⚕️',
    distance: 1.2,
    medicinePrice: 165,
    availability: 'Available',
    storeStatus: 'Open',
    openTime: '07:30 AM',
    closeTime: '11:00 PM',
    rating: 4.9,
    reviews: 521,
    latitude: 28.6350,
    longitude: 77.2210,
    image: '🏥'
  },
  {
    id: 3,
    name: 'HealthPlus Medical Store',
    address: '789 Jangpura Extension, East Delhi',
    icon: '💉',
    distance: 2.5,
    medicinePrice: 140,
    availability: 'Out of Stock',
    storeStatus: 'Closed',
    openTime: '09:00 AM',
    closeTime: '09:00 PM',
    rating: 4.5,
    reviews: 278,
    latitude: 28.5721,
    longitude: 77.2518,
    image: '🏪'
  },
  {
    id: 4,
    name: 'City Pharmacy Plus',
    address: '321 Karol Bagh, West Delhi',
    icon: '🔬',
    distance: 1.5,
    medicinePrice: 155,
    availability: 'Available',
    storeStatus: 'Open',
    openTime: '08:30 AM',
    closeTime: '10:30 PM',
    rating: 4.7,
    reviews: 389,
    latitude: 28.6500,
    longitude: 77.1850,
    image: '🏪'
  },
  {
    id: 5,
    name: 'Medzone Pharmacy',
    address: '567 Saket District Centre, South Delhi',
    icon: '💊',
    distance: 3.8,
    medicinePrice: 145,
    availability: 'Available',
    storeStatus: 'Closed',
    openTime: '09:00 AM',
    closeTime: '08:00 PM',
    rating: 4.6,
    reviews: 215,
    latitude: 28.5244,
    longitude: 77.1987,
    image: '🏪'
  },
  {
    id: 6,
    name: 'Prime Health Store',
    address: '234 Rajpura, North Delhi',
    icon: '⚕️',
    distance: 2.1,
    medicinePrice: 160,
    availability: 'Available',
    storeStatus: 'Open',
    openTime: '07:00 AM',
    closeTime: '11:30 PM',
    rating: 4.8,
    reviews: 456,
    latitude: 28.7500,
    longitude: 77.2100,
    image: '🏥'
  },
  {
    id: 7,
    name: 'DrugStore Pro',
    address: '456 Lajpat Nagar, Central Delhi',
    icon: '💉',
    distance: 1.8,
    medicinePrice: 152,
    availability: 'Available',
    storeStatus: 'Open',
    openTime: '08:00 AM',
    closeTime: '10:00 PM',
    rating: 4.7,
    reviews: 334,
    latitude: 28.5688,
    longitude: 77.2371,
    image: '🏪'
  },
  {
    id: 8,
    name: 'Wellness Pharmacy',
    address: '678 Nehru Place, South Delhi',
    icon: '🔬',
    distance: 4.2,
    medicinePrice: 148,
    availability: 'Out of Stock',
    storeStatus: 'Open',
    openTime: '09:30 AM',
    closeTime: '09:30 PM',
    rating: 4.4,
    reviews: 189,
    latitude: 28.5515,
    longitude: 77.2499,
    image: '🏪'
  }
];

// Distance filter options
const DISTANCE_FILTERS = [
  { label: 'All Distances', value: null },
  { label: 'Within 1 km', value: 1 },
  { label: 'Within 5 km', value: 5 },
  { label: 'Within 10 km', value: 10 }
];

const MedicineFinder = () => {
  // ========== STATE MANAGEMENT ==========
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedDistance, setSelectedDistance] = useState(null);
  const [hasSearched, setHasSearched] = useState(false);
  const [selectedPharmacy, setSelectedPharmacy] = useState(null);
  const [showMapPreview, setShowMapPreview] = useState(false);

  // ========== SEARCH HANDLER ==========
  const handleSearch = () => {
    if (searchTerm.trim()) {
      setHasSearched(true);
    }
  };

  const handleKeyPress = (e) => {
    if (e.key === 'Enter') {
      handleSearch();
    }
  };

  // ========== FILTERED PHARMACIES ==========
  const filteredPharmacies = useMemo(() => {
    if (!hasSearched) return [];

    return PHARMACY_DATA.filter(pharmacy => {
      const medicineMatch = searchTerm.toLowerCase() === '' || true; // Since we're showing all medicines
      const distanceMatch = selectedDistance === null || pharmacy.distance <= selectedDistance;
      return medicineMatch && distanceMatch;
    });
  }, [searchTerm, selectedDistance, hasSearched]);

  // ========== ANIMATION VARIANTS ==========
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: { staggerChildren: 0.1, delayChildren: 0.2 }
    }
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: { opacity: 1, y: 0, transition: { duration: 0.5 } }
  };

  const cardVariants = {
    hidden: { opacity: 0, scale: 0.95, y: 20 },
    visible: {
      opacity: 1,
      scale: 1,
      y: 0,
      transition: { duration: 0.4 }
    },
    hover: {
      y: -8,
      boxShadow: '0 20px 40px rgba(0,0,0,0.1)',
      transition: { duration: 0.3 }
    }
  };

  const mapModalVariants = {
    hidden: { opacity: 0, scale: 0.9 },
    visible: {
      opacity: 1,
      scale: 1,
      transition: { duration: 0.3 }
    },
    exit: {
      opacity: 0,
      scale: 0.9,
      transition: { duration: 0.2 }
    }
  };

  return (
    <motion.div
      className="medicine-finder-container"
      variants={containerVariants}
      initial="hidden"
      animate="visible"
    >
      {/* ========== HEADER ========== */}
      <motion.div className="finder-header" variants={itemVariants}>
        <h2>
          <span className="header-icon">💊</span>
          Find Your Medicine
        </h2>
        <p>Search nearby pharmacies for available medicines at best prices</p>
      </motion.div>

      {/* ========== SEARCH SECTION ========== */}
      <motion.div className="search-section" variants={itemVariants}>
        <div className="search-container">
          <div className="search-input-wrapper">
            <input
              type="text"
              placeholder="Search medicine name (e.g., Aspirin, Paracetamol)..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              onKeyPress={handleKeyPress}
              className="search-input"
            />
            <span className="search-icon">🔍</span>
          </div>

          <motion.button
            className="search-btn"
            onClick={handleSearch}
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
          >
            Search
          </motion.button>
        </div>

        {/* Distance Filter */}
        <div className="filter-section">
          <label>Filter by Distance:</label>
          <div className="distance-filters">
            {DISTANCE_FILTERS.map(filter => (
              <motion.button
                key={filter.value}
                className={`filter-btn ${selectedDistance === filter.value ? 'active' : ''}`}
                onClick={() => setSelectedDistance(filter.value)}
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
              >
                {filter.label}
              </motion.button>
            ))}
          </div>
        </div>
      </motion.div>

      {/* ========== RESULTS SECTION ========== */}
      {hasSearched && (
        <motion.div
          className="results-section"
          variants={itemVariants}
          initial="hidden"
          animate="visible"
        >
          <div className="results-header">
            <h3>
              {filteredPharmacies.length > 0
                ? `Found ${filteredPharmacies.length} pharmacies with "${searchTerm}"`
                : 'No pharmacies found'}
            </h3>
            {filteredPharmacies.length > 0 && (
              <p className="results-subtitle">sorted by distance</p>
            )}
          </div>

          {/* Pharmacy Cards Grid */}
          {filteredPharmacies.length > 0 ? (
            <motion.div
              className="pharmacies-grid"
              variants={containerVariants}
            >
              {filteredPharmacies.map(pharmacy => (
                <motion.div
                  key={pharmacy.id}
                  className="pharmacy-card"
                  variants={cardVariants}
                  whileHover="hover"
                >
                  {/* Card Header with Image and Status */}
                  <div className="card-header">
                    <div className="pharmacy-image">
                      <span className="image-icon">{pharmacy.image}</span>
                    </div>
                    <div className="status-badges">
                      <span
                        className={`status-badge ${pharmacy.storeStatus === 'Open' ? 'open' : 'closed'}`}
                      >
                        {pharmacy.storeStatus === 'Open' ? '🟢 Open' : '🔴 Closed'}
                      </span>
                      <span
                        className={`availability-badge ${pharmacy.availability === 'Available' ? 'available' : 'unavailable'}`}
                      >
                        {pharmacy.availability === 'Available' ? '✓ In Stock' : '✗ Out of Stock'}
                      </span>
                    </div>
                  </div>

                  {/* Pharmacy Info */}
                  <div className="pharmacy-info">
                    <h3>{pharmacy.name}</h3>

                    {/* Rating */}
                    <div className="rating-row">
                      <div className="stars">
                        {'⭐'.repeat(Math.floor(pharmacy.rating))}
                        <span className="rating-number">{pharmacy.rating}</span>
                      </div>
                      <span className="review-count">({pharmacy.reviews} reviews)</span>
                    </div>

                    {/* Address */}
                    <div className="address-row">
                      <span className="address-icon">📍</span>
                      <span className="address-text">{pharmacy.address}</span>
                    </div>

                    {/* Distance and Price Row */}
                    <div className="details-row">
                      <div className="detail-item">
                        <span className="detail-label">Distance:</span>
                        <span className="detail-value">{pharmacy.distance} km away</span>
                      </div>
                      <div className="detail-item">
                        <span className="detail-label">Price:</span>
                        <span className="price-value">₹{pharmacy.medicinePrice}</span>
                      </div>
                    </div>

                    {/* Store Timings */}
                    <div className="timings-row">
                      <span className="timing-icon">🕒</span>
                      <span className="timing-text">
                        {pharmacy.openTime} - {pharmacy.closeTime}
                      </span>
                    </div>

                    {/* Action Buttons */}
                    <div className="card-actions">
                      <motion.button
                        className="location-btn"
                        onClick={() => {
                          setSelectedPharmacy(pharmacy);
                          setShowMapPreview(true);
                        }}
                        whileHover={{ scale: 1.05 }}
                        whileTap={{ scale: 0.95 }}
                      >
                        📍 View Location
                      </motion.button>
                      <motion.button
                        className="call-btn"
                        whileHover={{ scale: 1.05 }}
                        whileTap={{ scale: 0.95 }}
                      >
                        📞 Call Now
                      </motion.button>
                    </div>
                  </div>
                </motion.div>
              ))}
            </motion.div>
          ) : (
            <motion.div
              className="no-results"
              variants={itemVariants}
            >
              <p className="no-results-icon">🏥</p>
              <p className="no-results-text">
                No pharmacies found within selected distance.
              </p>
              <p className="no-results-hint">
                Try increasing the distance filter or search for a different medicine.
              </p>
            </motion.div>
          )}
        </motion.div>
      )}

      {/* ========== EMPTY STATE ========== */}
      {!hasSearched && (
        <motion.div
          className="empty-state"
          variants={itemVariants}
        >
          <div className="empty-state-icon">💊</div>
          <h3>Search for a Medicine</h3>
          <p>Enter a medicine name to find nearby pharmacies with availability and prices</p>
        </motion.div>
      )}

      {/* ========== MAP PREVIEW MODAL ========== */}
      <AnimatePresence>
        {showMapPreview && selectedPharmacy && (
          <motion.div
            className="modal-overlay"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={() => setShowMapPreview(false)}
          >
            <motion.div
              className="map-modal"
              variants={mapModalVariants}
              initial="hidden"
              animate="visible"
              exit="exit"
              onClick={(e) => e.stopPropagation()}
            >
              {/* Close Button */}
              <button
                className="modal-close"
                onClick={() => setShowMapPreview(false)}
              >
                ✕
              </button>

              {/* Modal Header */}
              <div className="modal-header">
                <h3>
                  <span className="modal-icon">📍</span>
                  Pharmacy Location
                </h3>
              </div>

              {/* Map Preview */}
              <div className="map-container">
                <div className="map-preview">
                  <div className="map-placeholder">
                    <div className="map-icon">🗺️</div>
                    <p>Interactive Map</p>
                    <p className="map-coords">
                      Lat: {selectedPharmacy.latitude.toFixed(4)}, Lng: {selectedPharmacy.longitude.toFixed(4)}
                    </p>
                  </div>
                </div>
              </div>

              {/* Location Details */}
              <div className="location-details">
                <h4>{selectedPharmacy.name}</h4>
                <div className="detail-row">
                  <span className="detail-label">Address:</span>
                  <span className="detail-value">{selectedPharmacy.address}</span>
                </div>
                <div className="detail-row">
                  <span className="detail-label">Distance:</span>
                  <span className="detail-value">{selectedPharmacy.distance} km</span>
                </div>
                <div className="detail-row">
                  <span className="detail-label">Hours:</span>
                  <span className="detail-value">
                    {selectedPharmacy.openTime} - {selectedPharmacy.closeTime}
                  </span>
                </div>
                <div className="detail-row">
                  <span className="detail-label">Status:</span>
                  <span
                    className={`status-value ${selectedPharmacy.storeStatus === 'Open' ? 'open' : 'closed'}`}
                  >
                    {selectedPharmacy.storeStatus === 'Open' ? '🟢 Open' : '🔴 Closed'}
                  </span>
                </div>
                <div className="detail-row">
                  <span className="detail-label">Medicine Price:</span>
                  <span className="price-highlight">₹{selectedPharmacy.medicinePrice}</span>
                </div>
              </div>

              {/* Modal Actions */}
              <div className="modal-actions">
                <motion.button
                  className="action-btn primary"
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                >
                  📍 Get Directions
                </motion.button>
                <motion.button
                  className="action-btn secondary"
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                  onClick={() => setShowMapPreview(false)}
                >
                  Close
                </motion.button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.div>
  );
};

export default MedicineFinder;