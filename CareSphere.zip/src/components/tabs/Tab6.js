import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import './Tab6.css';

/* ============================================
   DOCTOR CONSULTANCY COMPONENT
   
   Complete telemedicine platform with:
   - Video & voice consultation options
   - Real-time doctor availability
   - Video/voice call interfaces
   - Appointment scheduling
   - Consultation notes system
   - Chat functionality
   - Medical report upload
   - Rating & review system
   - Consultation history
   - 24/7 emergency support
   - Responsive design
   - Framer Motion animations
   ============================================ */

// Sample doctor data
const SAMPLE_DOCTORS = [
  {
    id: 1,
    name: 'Dr. Rajesh Kumar',
    speciality: 'General Physician',
    experience: 15,
    rating: 4.8,
    reviews: 342,
    availability: 'Online',
    waitingTime: '5 mins',
    image: '👨‍⚕️',
    bio: 'Experienced GP with 15+ years of practice'
  },
  {
    id: 2,
    name: 'Dr. Priya Singh',
    speciality: 'Cardiologist',
    experience: 12,
    rating: 4.9,
    reviews: 521,
    availability: 'Online',
    waitingTime: '10 mins',
    image: '👩‍⚕️',
    bio: 'Specialist in cardiac care and heart health'
  },
  {
    id: 3,
    name: 'Dr. Amit Patel',
    speciality: 'Dermatologist',
    experience: 10,
    rating: 4.7,
    reviews: 278,
    availability: 'Busy',
    waitingTime: '25 mins',
    image: '👨‍⚕️',
    bio: 'Expert in skin diseases and cosmetic treatments'
  },
  {
    id: 4,
    name: 'Dr. Sneha Sharma',
    speciality: 'Pediatrician',
    experience: 11,
    rating: 4.6,
    reviews: 189,
    availability: 'Online',
    waitingTime: '8 mins',
    image: '👩‍⚕️',
    bio: 'Specialist in child health and development'
  },
  {
    id: 5,
    name: 'Dr. Neha Desai',
    speciality: 'Gynecologist',
    experience: 13,
    rating: 4.9,
    reviews: 456,
    availability: 'Online',
    waitingTime: '12 mins',
    image: '👩‍⚕️',
    bio: 'Specialist in women health and wellness'
  }
];

// Consultation history data
const SAMPLE_HISTORY = [
  {
    id: 1,
    doctor: 'Dr. Rajesh Kumar',
    date: '2024-01-10',
    type: 'Video Call',
    duration: '25 mins',
    notes: 'Common cold and fever - prescribed antibiotics'
  },
  {
    id: 2,
    doctor: 'Dr. Priya Singh',
    date: '2024-01-05',
    type: 'Voice Call',
    duration: '18 mins',
    notes: 'Blood pressure checkup - advised exercise and diet'
  }
];

const DoctorConsultancy = () => {
  // ========== STATE MANAGEMENT ==========
  const [currentStep, setCurrentStep] = useState('selection'); // selection, doctors, call, notes
  const [consultationType, setConsultationType] = useState(null); // 'video' or 'voice'
  const [selectedDoctor, setSelectedDoctor] = useState(null);
  const [showCallInterface, setShowCallInterface] = useState(false);
  const [callActive, setCallActive] = useState(false);
  const [callTimer, setCallTimer] = useState(0);
  const [isMuted, setIsMuted] = useState(false);
  const [cameraOn, setCameraOn] = useState(true);
  const [showConsultationNotes, setShowConsultationNotes] = useState(false);
  const [consultationNotes, setConsultationNotes] = useState('');
  const [showScheduleModal, setShowScheduleModal] = useState(false);
  const [scheduledDate, setScheduledDate] = useState('');
  const [scheduledTime, setScheduledTime] = useState('');
  const [showChatPanel, setShowChatPanel] = useState(false);
  const [showUploadPanel, setShowUploadPanel] = useState(false);
  const [showHistoryPanel, setShowHistoryPanel] = useState(false);
  const [showRatingModal, setShowRatingModal] = useState(false);
  const [doctorRating, setDoctorRating] = useState(0);

  // ========== CALL TIMER ==========
  useEffect(() => {
    let interval;
    if (callActive) {
      interval = setInterval(() => {
        setCallTimer(prev => prev + 1);
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [callActive]);

  // ========== HANDLERS ==========
  const handleSelectConsultationType = (type) => {
    setConsultationType(type);
    setCurrentStep('doctors');
  };

  const handleSelectDoctor = (doctor, type) => {
    setSelectedDoctor(doctor);
    if (doctor.availability === 'Online') {
      setShowCallInterface(true);
      setCallActive(true);
      setCallTimer(0);
    } else {
      setShowScheduleModal(true);
    }
  };

  const handleEndCall = () => {
    setCallActive(false);
    setShowCallInterface(false);
    setShowRatingModal(true);
    setCurrentStep('notes');
  };

  const handleScheduleAppointment = () => {
    if (scheduledDate && scheduledTime) {
      alert(`Appointment scheduled for ${scheduledDate} at ${scheduledTime}`);
      setShowScheduleModal(false);
      setCurrentStep('selection');
    }
  };

  const handleSubmitRating = () => {
    if (doctorRating > 0) {
      alert(`Thank you for rating Dr. ${selectedDoctor.name} ${doctorRating} stars!`);
      setShowRatingModal(false);
      setCurrentStep('selection');
    }
  };

  const formatCallTime = (seconds) => {
    const hrs = Math.floor(seconds / 3600);
    const mins = Math.floor((seconds % 3600) / 60);
    const secs = seconds % 60;
    return `${hrs.toString().padStart(2, '0')}:${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  // ========== ANIMATION VARIANTS ==========
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: { staggerChildren: 0.1, delayChildren: 0.2 }
    }
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: { opacity: 1, y: 0, transition: { duration: 0.5 } }
  };

  const cardVariants = {
    hidden: { opacity: 0, scale: 0.95, y: 20 },
    visible: {
      opacity: 1,
      scale: 1,
      y: 0,
      transition: { duration: 0.4 }
    },
    hover: {
      y: -8,
      boxShadow: '0 20px 40px rgba(0,0,0,0.1)',
      transition: { duration: 0.3 }
    }
  };

  return (
    <motion.div
      className="doctor-consultancy-container"
      variants={containerVariants}
      initial="hidden"
      animate="visible"
    >
      {/* ========== HEADER ========== */}
      <motion.div className="consultancy-header" variants={itemVariants}>
        <h2>
          <span className="header-icon">🏥</span>
          Doctor Consultancy
        </h2>
        <p>Connect with verified doctors anytime, anywhere</p>
      </motion.div>

      <AnimatePresence mode="wait">
        {/* ========== SELECTION STEP ========== */}
        {currentStep === 'selection' && (
          <motion.div
            className="selection-section"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            key="selection"
          >
            {/* Quick Actions */}
            <motion.div className="quick-actions" variants={itemVariants}>
              <motion.button
                className="emergency-btn"
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                onClick={() => alert('Connecting to emergency specialist...')}
              >
                🚨 24/7 Emergency Consultation
              </motion.button>
            </motion.div>

            {/* Consultation Options */}
            <h3 className="section-subtitle">Select Consultation Type</h3>
            <div className="consultation-options">
              {/* Video Consultation */}
              <motion.div
                className="consultation-card video"
                variants={cardVariants}
                whileHover="hover"
                onClick={() => handleSelectConsultationType('video')}
              >
                <div className="option-icon">📹</div>
                <h4>Video Consultation</h4>
                <p>Face-to-face consultation with a doctor via video call</p>
                <motion.button
                  className="start-btn"
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                >
                  Start Video Call
                </motion.button>
              </motion.div>

              {/* Voice Consultation */}
              <motion.div
                className="consultation-card voice"
                variants={cardVariants}
                whileHover="hover"
                onClick={() => handleSelectConsultationType('voice')}
              >
                <div className="option-icon">☎️</div>
                <h4>Voice Consultation</h4>
                <p>Quick consultation with a doctor via phone call</p>
                <motion.button
                  className="start-btn"
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                >
                  Start Voice Call
                </motion.button>
              </motion.div>
            </div>

            {/* Additional Options */}
            <div className="additional-options">
              <motion.button
                className="option-btn chat-btn"
                variants={itemVariants}
                onClick={() => setShowChatPanel(true)}
              >
                💬 Chat with Doctor
              </motion.button>
              <motion.button
                className="option-btn upload-btn"
                variants={itemVariants}
                onClick={() => setShowUploadPanel(true)}
              >
                📄 Upload Medical Reports
              </motion.button>
              <motion.button
                className="option-btn history-btn"
                variants={itemVariants}
                onClick={() => setShowHistoryPanel(true)}
              >
                📋 Consultation History
              </motion.button>
            </div>
          </motion.div>
        )}

        {/* ========== DOCTORS STEP ========== */}
        {currentStep === 'doctors' && (
          <motion.div
            className="doctors-section"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            key="doctors"
          >
            <motion.button
              className="back-btn"
              onClick={() => {
                setCurrentStep('selection');
                setConsultationType(null);
              }}
              variants={itemVariants}
            >
              ← Back
            </motion.button>

            <h3>Available {consultationType === 'video' ? 'for Video' : 'for Voice'} Consultation</h3>
            <div className="doctors-grid">
              {SAMPLE_DOCTORS.map(doctor => (
                <motion.div
                  key={doctor.id}
                  className="doctor-card"
                  variants={cardVariants}
                  whileHover="hover"
                >
                  {/* Card Header */}
                  <div className="doctor-header">
                    <div className="doctor-image">{doctor.image}</div>
                    <div className="doctor-basic-info">
                      <h4>{doctor.name}</h4>
                      <p className="speciality">{doctor.speciality}</p>
                      <span className={`availability-badge ${doctor.availability.toLowerCase()}`}>
                        {doctor.availability === 'Online' && '🟢'} {doctor.availability}
                      </span>
                    </div>
                  </div>

                  {/* Doctor Info */}
                  <div className="doctor-info">
                    <div className="info-row">
                      <span className="info-label">Experience:</span>
                      <span className="info-value">{doctor.experience} years</span>
                    </div>
                    <div className="info-row">
                      <span className="info-label">Rating:</span>
                      <span className="info-value">⭐ {doctor.rating} ({doctor.reviews})</span>
                    </div>
                    <div className="info-row">
                      <span className="info-label">Waiting:</span>
                      <span className="info-value">{doctor.waitingTime}</span>
                    </div>
                  </div>

                  {/* Actions */}
                  <div className="doctor-actions">
                    {consultationType === 'video' && (
                      <motion.button
                        className="action-btn video-btn"
                        onClick={() => handleSelectDoctor(doctor, 'video')}
                        whileHover={{ scale: 1.05 }}
                        whileTap={{ scale: 0.95 }}
                      >
                        📹 Start Video Call
                      </motion.button>
                    )}
                    {consultationType === 'voice' && (
                      <motion.button
                        className="action-btn voice-btn"
                        onClick={() => handleSelectDoctor(doctor, 'voice')}
                        whileHover={{ scale: 1.05 }}
                        whileTap={{ scale: 0.95 }}
                      >
                        ☎️ Start Voice Call
                      </motion.button>
                    )}
                    <motion.button
                      className="action-btn profile-btn"
                      onClick={() => alert(`Viewing profile of ${doctor.name}`)}
                      whileHover={{ scale: 1.05 }}
                      whileTap={{ scale: 0.95 }}
                    >
                      👁️ View Profile
                    </motion.button>
                  </div>
                </motion.div>
              ))}
            </div>
          </motion.div>
        )}

        {/* ========== VIDEO CALL INTERFACE ========== */}
        {showCallInterface && consultationType === 'video' && selectedDoctor && (
          <motion.div
            className="video-call-interface"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            key="video-call"
          >
            <div className="video-container">
              {/* Main Video Window */}
              <div className="video-main">
                <div className="video-placeholder">
                  <div className="doctor-avatar-large">{selectedDoctor.image}</div>
                  <p>Dr. {selectedDoctor.name}</p>
                  <p className="doctor-speciality">{selectedDoctor.speciality}</p>
                </div>
              </div>

              {/* Mini Video (Self) */}
              <div className="video-mini">
                <div className="self-avatar">📷</div>
                <p className="self-label">You</p>
              </div>

              {/* Call Info */}
              <div className="call-info">
                <h3>Dr. {selectedDoctor.name}</h3>
                <div className="call-timer">{formatCallTime(callTimer)}</div>
              </div>

              {/* Call Controls */}
              <div className="call-controls">
                <motion.button
                  className={`control-btn ${isMuted ? 'muted' : ''}`}
                  onClick={() => setIsMuted(!isMuted)}
                  whileHover={{ scale: 1.1 }}
                  whileTap={{ scale: 0.9 }}
                >
                  {isMuted ? '🔇' : '🎤'}
                </motion.button>
                <motion.button
                  className={`control-btn ${!cameraOn ? 'off' : ''}`}
                  onClick={() => setCameraOn(!cameraOn)}
                  whileHover={{ scale: 1.1 }}
                  whileTap={{ scale: 0.9 }}
                >
                  {cameraOn ? '📹' : '📷'}
                </motion.button>
                <motion.button
                  className="end-call-btn"
                  onClick={handleEndCall}
                  whileHover={{ scale: 1.1 }}
                  whileTap={{ scale: 0.9 }}
                >
                  ☎️ End Call
                </motion.button>
              </div>
            </div>
          </motion.div>
        )}

        {/* ========== VOICE CALL INTERFACE ========== */}
        {showCallInterface && consultationType === 'voice' && selectedDoctor && (
          <motion.div
            className="voice-call-interface"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            key="voice-call"
          >
            <div className="voice-container">
              {/* Doctor Avatar */}
              <div className="voice-avatar-section">
                <div className="voice-avatar">{selectedDoctor.image}</div>
                <h3>Dr. {selectedDoctor.name}</h3>
                <p className="voice-speciality">{selectedDoctor.speciality}</p>
              </div>

              {/* Call Timer */}
              <div className="voice-timer">{formatCallTime(callTimer)}</div>

              {/* Call Controls */}
              <div className="voice-controls">
                <motion.button
                  className={`voice-control ${isMuted ? 'muted' : ''}`}
                  onClick={() => setIsMuted(!isMuted)}
                  whileHover={{ scale: 1.15 }}
                  whileTap={{ scale: 0.9 }}
                >
                  {isMuted ? '🔇' : '🎤'}
                </motion.button>
                <motion.button
                  className="voice-end-call"
                  onClick={handleEndCall}
                  whileHover={{ scale: 1.15 }}
                  whileTap={{ scale: 0.9 }}
                >
                  ☎️
                </motion.button>
              </div>
            </div>
          </motion.div>
        )}

        {/* ========== CONSULTATION NOTES STEP ========== */}
        {currentStep === 'notes' && selectedDoctor && (
          <motion.div
            className="notes-section"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            key="notes"
          >
            <div className="consultation-summary-card">
              <h3>📋 Consultation Summary</h3>
              <div className="summary-info">
                <div className="info-row">
                  <span className="label">Doctor:</span>
                  <span className="value">Dr. {selectedDoctor.name}</span>
                </div>
                <div className="info-row">
                  <span className="label">Speciality:</span>
                  <span className="value">{selectedDoctor.speciality}</span>
                </div>
                <div className="info-row">
                  <span className="label">Duration:</span>
                  <span className="value">{formatCallTime(callTimer)}</span>
                </div>
              </div>

              <div className="notes-section-content">
                <h4>Doctor's Notes</h4>
                <textarea
                  placeholder="Diagnosis summary, medicines, and follow-up recommendations will appear here..."
                  className="notes-display"
                  readOnly
                  defaultValue={`Diagnosis Summary:
- Patient consultation completed successfully
- Initial assessment conducted

Suggested Medicines:
- Medicine 1: As prescribed
- Medicine 2: As directed

Follow-up Recommendation:
- Follow-up appointment after 1 week
- Contact if symptoms persist`}
                />
              </div>

              {/* Rating Section */}
              {showRatingModal && (
                <div className="rating-section">
                  <h4>Rate Your Consultation</h4>
                  <div className="rating-stars">
                    {[1, 2, 3, 4, 5].map(star => (
                      <motion.button
                        key={star}
                        className={`star ${doctorRating >= star ? 'active' : ''}`}
                        onClick={() => setDoctorRating(star)}
                        whileHover={{ scale: 1.2 }}
                      >
                        ⭐
                      </motion.button>
                    ))}
                  </div>
                  <motion.button
                    className="submit-rating-btn"
                    onClick={handleSubmitRating}
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                  >
                    Submit Rating
                  </motion.button>
                </div>
              )}

              {/* Action Buttons */}
              <div className="notes-actions">
                <motion.button
                  className="action-btn primary"
                  onClick={() => alert('Prescription downloaded!')}
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                >
                  📥 Download Summary
                </motion.button>
                <motion.button
                  className="action-btn secondary"
                  onClick={() => setCurrentStep('selection')}
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                >
                  Back to Home
                </motion.button>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* ========== SCHEDULE MODAL ========== */}
      <AnimatePresence>
        {showScheduleModal && selectedDoctor && (
          <motion.div
            className="modal-overlay"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={() => setShowScheduleModal(false)}
          >
            <motion.div
              className="modal-content"
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              onClick={(e) => e.stopPropagation()}
            >
              <button
                className="modal-close"
                onClick={() => setShowScheduleModal(false)}
              >
                ✕
              </button>

              <h3>📅 Schedule Appointment</h3>
              <p className="modal-subtitle">Dr. {selectedDoctor.name} is currently busy. Schedule for later.</p>

              <div className="modal-form">
                <div className="form-group">
                  <label>Select Date:</label>
                  <input
                    type="date"
                    value={scheduledDate}
                    onChange={(e) => setScheduledDate(e.target.value)}
                  />
                </div>

                <div className="form-group">
                  <label>Select Time:</label>
                  <select
                    value={scheduledTime}
                    onChange={(e) => setScheduledTime(e.target.value)}
                  >
                    <option value="">Choose a time...</option>
                    <option value="09:00">09:00 AM</option>
                    <option value="10:00">10:00 AM</option>
                    <option value="11:00">11:00 AM</option>
                    <option value="14:00">02:00 PM</option>
                    <option value="15:00">03:00 PM</option>
                    <option value="16:00">04:00 PM</option>
                    <option value="17:00">05:00 PM</option>
                  </select>
                </div>

                <div className="modal-actions">
                  <motion.button
                    className="btn primary"
                    onClick={handleScheduleAppointment}
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                  >
                    Schedule Appointment
                  </motion.button>
                  <motion.button
                    className="btn secondary"
                    onClick={() => setShowScheduleModal(false)}
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                  >
                    Cancel
                  </motion.button>
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* ========== ADDITIONAL MODALS ========== */}
      {/* Chat Panel */}
      <AnimatePresence>
        {showChatPanel && (
          <motion.div className="side-panel chat-panel">
            <button
              className="panel-close"
              onClick={() => setShowChatPanel(false)}
            >
              ✕
            </button>
            <h3>💬 Chat with Doctor</h3>
            <div className="chat-messages">
              <div className="message doctor">
                <p>Hello! How can I help you today?</p>
              </div>
              <div className="message user">
                <p>I have some health concerns...</p>
              </div>
            </div>
            <div className="chat-input">
              <input type="text" placeholder="Type your message..." />
              <button>Send</button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Upload Panel */}
      <AnimatePresence>
        {showUploadPanel && (
          <motion.div className="side-panel upload-panel">
            <button
              className="panel-close"
              onClick={() => setShowUploadPanel(false)}
            >
              ✕
            </button>
            <h3>📄 Upload Medical Reports</h3>
            <div className="upload-area">
              <p className="upload-icon">📁</p>
              <p>Drag and drop your reports here or click to browse</p>
              <input type="file" accept=".pdf,.jpg,.png" />
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* History Panel */}
      <AnimatePresence>
        {showHistoryPanel && (
          <motion.div className="side-panel history-panel">
            <button
              className="panel-close"
              onClick={() => setShowHistoryPanel(false)}
            >
              ✕
            </button>
            <h3>📋 Consultation History</h3>
            <div className="history-list">
              {SAMPLE_HISTORY.map(consultation => (
                <div key={consultation.id} className="history-item">
                  <div className="history-header">
                    <p className="doctor-name">{consultation.doctor}</p>
                    <span className="history-type">{consultation.type}</span>
                  </div>
                  <p className="history-date">{consultation.date}</p>
                  <p className="history-duration">Duration: {consultation.duration}</p>
                  <p className="history-notes">{consultation.notes}</p>
                </div>
              ))}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.div>
  );
};

export default DoctorConsultancy;