import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import './Tab4.css';

/* ============================================
   FITNESS SCORE COMPONENT
   
   Complete health assessment with:
   - Physical & Mental health questionnaires
   - Dynamic fitness score calculation
   - Health status display
   - Personalized suggestions
   - Health center booking
   - Responsive design
   - Framer Motion animations
   ============================================ */

// Physical Health Questions
const PHYSICAL_HEALTH_QUESTIONS = [
  {
    id: 1,
    question: 'How many days per week do you exercise?',
    options: [
      { text: 'Never', score: 0 },
      { text: '1-2 days', score: 25 },
      { text: '3-4 days', score: 50 },
      { text: '5-6 days', score: 75 },
      { text: 'Every day', score: 100 }
    ]
  },
  {
    id: 2,
    question: 'How many hours do you sleep daily?',
    options: [
      { text: 'Less than 5 hours', score: 0 },
      { text: '5-6 hours', score: 25 },
      { text: '6-7 hours', score: 75 },
      { text: '7-8 hours', score: 100 },
      { text: 'More than 8 hours', score: 50 }
    ]
  },
  {
    id: 3,
    question: 'How often do you eat fruits and vegetables?',
    options: [
      { text: 'Rarely', score: 0 },
      { text: 'Sometimes (2-3 times a week)', score: 30 },
      { text: 'Often (4-5 times a week)', score: 60 },
      { text: 'Daily', score: 100 }
    ]
  },
  {
    id: 4,
    question: 'Do you smoke or drink alcohol?',
    options: [
      { text: 'Yes, regularly', score: 0 },
      { text: 'Yes, occasionally', score: 30 },
      { text: 'No, never', score: 100 }
    ]
  },
  {
    id: 5,
    question: 'Do you have any chronic diseases?',
    options: [
      { text: 'Yes, multiple diseases', score: 0 },
      { text: 'Yes, one disease', score: 25 },
      { text: 'No', score: 100 }
    ]
  }
];

// Mental Health Questions
const MENTAL_HEALTH_QUESTIONS = [
  {
    id: 1,
    question: 'How often do you feel stressed?',
    options: [
      { text: 'All the time', score: 0 },
      { text: 'Very often', score: 20 },
      { text: 'Sometimes', score: 50 },
      { text: 'Rarely', score: 80 },
      { text: 'Never', score: 100 }
    ]
  },
  {
    id: 2,
    question: 'Do you feel anxious frequently?',
    options: [
      { text: 'Yes, very anxious', score: 0 },
      { text: 'Often anxious', score: 25 },
      { text: 'Sometimes anxious', score: 50 },
      { text: 'Rarely anxious', score: 75 },
      { text: 'Not anxious at all', score: 100 }
    ]
  },
  {
    id: 3,
    question: 'How well do you sleep?',
    options: [
      { text: 'Very poorly', score: 0 },
      { text: 'Poorly', score: 25 },
      { text: 'Okay', score: 50 },
      { text: 'Well', score: 75 },
      { text: 'Very well', score: 100 }
    ]
  },
  {
    id: 4,
    question: 'Do you feel motivated during the day?',
    options: [
      { text: 'Not motivated at all', score: 0 },
      { text: 'Rarely motivated', score: 30 },
      { text: 'Sometimes motivated', score: 60 },
      { text: 'Often motivated', score: 80 },
      { text: 'Always motivated', score: 100 }
    ]
  },
  {
    id: 5,
    question: 'How often do you feel mentally exhausted?',
    options: [
      { text: 'Always exhausted', score: 0 },
      { text: 'Often exhausted', score: 20 },
      { text: 'Sometimes exhausted', score: 50 },
      { text: 'Rarely exhausted', score: 80 },
      { text: 'Never exhausted', score: 100 }
    ]
  }
];

// Sample Health Centers
const HEALTH_CENTERS = [
  {
    id: 1,
    name: 'City Government Medical Center',
    address: '123 Health Street, Central Delhi',
    distance: 2.3,
    phone: '+91-11-1234-5678',
    type: 'Full Service',
    rating: 4.6,
    image: '🏥'
  },
  {
    id: 2,
    name: 'North Delhi Health Centre',
    address: '456 Wellness Avenue, North Delhi',
    distance: 3.5,
    phone: '+91-11-2345-6789',
    type: 'General & Specialized',
    rating: 4.5,
    image: '⚕️'
  },
  {
    id: 3,
    name: 'Mental Wellness Clinic',
    address: '789 Care Lane, East Delhi',
    distance: 1.8,
    phone: '+91-11-3456-7890',
    type: 'Mental Health Specialist',
    rating: 4.8,
    image: '🧠'
  },
  {
    id: 4,
    name: 'South Delhi Community Hospital',
    address: '234 Medical Park, South Delhi',
    distance: 4.1,
    phone: '+91-11-4567-8901',
    type: 'Community Center',
    rating: 4.4,
    image: '🏨'
  },
  {
    id: 5,
    name: 'Holistic Health Center',
    address: '567 Wellness Plaza, West Delhi',
    distance: 2.9,
    phone: '+91-11-5678-9012',
    type: 'Integrated Care',
    rating: 4.7,
    image: '💚'
  }
];

// Suggestions for improvement
const SUGGESTIONS = {
  physical: [
    '🏃‍♂️ Start a regular exercise routine - even 20 minutes daily helps',
    '😴 Maintain a consistent sleep schedule of 7-8 hours',
    '🥗 Eat more fruits and vegetables daily',
    '🚫 Reduce or eliminate smoking and alcohol consumption',
    '💊 Regular health checkups are essential',
    '💧 Drink at least 8 glasses of water daily',
    '🚶‍♀️ Take a 30-minute walk every day',
    '🏋️ Include strength training 2-3 times per week'
  ],
  mental: [
    '🧘‍♀️ Practice meditation or yoga for stress relief',
    '🗣️ Talk to friends, family, or a counselor about stress',
    '🛌 Maintain good sleep hygiene and routine',
    '🎯 Set realistic goals and celebrate small wins',
    '⏰ Take regular breaks from work or studies',
    '🎵 Listen to music or engage in hobbies you enjoy',
    '📱 Limit screen time, especially social media',
    '🤝 Spend quality time with loved ones'
  ]
};

const FitnessScore = () => {
  // ========== STATE MANAGEMENT ==========
  const [currentStep, setCurrentStep] = useState('selection'); // selection, questionnaire, results
  const [selectedCheckType, setSelectedCheckType] = useState(null); // 'physical' or 'mental'
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [answers, setAnswers] = useState([]);
  const [fitnessScore, setFitnessScore] = useState(null);
  const [healthStatus, setHealthStatus] = useState(null);
  const [selectedBookingType, setSelectedBookingType] = useState(null);
  const [selectedCenter, setSelectedCenter] = useState(null);

  // ========== HANDLERS ==========
  const handleSelectCheckType = (type) => {
    setSelectedCheckType(type);
    setCurrentStep('questionnaire');
    setCurrentQuestion(0);
    setAnswers([]);
  };

  const handleAnswerSelect = (score) => {
    const newAnswers = [...answers, score];
    setAnswers(newAnswers);

    const questions = selectedCheckType === 'physical' 
      ? PHYSICAL_HEALTH_QUESTIONS 
      : MENTAL_HEALTH_QUESTIONS;

    if (currentQuestion < questions.length - 1) {
      setCurrentQuestion(currentQuestion + 1);
    } else {
      // Calculate score and show results
      calculateScore(newAnswers);
      setCurrentStep('results');
    }
  };

  const calculateScore = (answersArray) => {
    const average = answersArray.reduce((a, b) => a + b, 0) / answersArray.length;
    setFitnessScore(Math.round(average));

    if (average >= 80) {
      setHealthStatus('Excellent');
    } else if (average >= 60) {
      setHealthStatus('Good');
    } else if (average >= 40) {
      setHealthStatus('Moderate');
    } else {
      setHealthStatus('Needs Improvement');
    }
  };

  const handleRetake = () => {
    setCurrentStep('selection');
    setSelectedCheckType(null);
    setCurrentQuestion(0);
    setAnswers([]);
    setFitnessScore(null);
    setHealthStatus(null);
  };

  const handleBookAppointment = (center, type) => {
    setSelectedCenter(center);
    setSelectedBookingType(type);
    alert(`Appointment booked at ${center.name} for ${type} Check!\n\nContact: ${center.phone}`);
  };

  // ========== GET CURRENT QUESTIONS ==========
  const currentQuestions = selectedCheckType === 'physical' 
    ? PHYSICAL_HEALTH_QUESTIONS 
    : MENTAL_HEALTH_QUESTIONS;

  // ========== GET RANDOM SUGGESTIONS ==========
  const getRandomSuggestions = (type) => {
    const suggestionList = type === 'physical' ? SUGGESTIONS.physical : SUGGESTIONS.mental;
    return suggestionList.sort(() => Math.random() - 0.5).slice(0, 4);
  };

  // ========== GET REPORT DATA ==========
  const getHealthReport = () => {
    const checkType = selectedCheckType === 'physical' ? 'Physical Health' : 'Mental Health';
    
    const reportData = {
      assessmentType: checkType,
      date: new Date().toLocaleDateString('en-US', { 
        weekday: 'long', 
        year: 'numeric', 
        month: 'long', 
        day: 'numeric' 
      }),
      questionsAnswered: answers.length,
      fitnessScore: fitnessScore,
      healthStatus: healthStatus,
      totalQuestions: currentQuestions.length
    };

    return reportData;
  };

  // ========== ANIMATION VARIANTS ==========
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: { staggerChildren: 0.1, delayChildren: 0.2 }
    }
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: { opacity: 1, y: 0, transition: { duration: 0.5 } }
  };

  const cardVariants = {
    hidden: { opacity: 0, scale: 0.95, y: 20 },
    visible: {
      opacity: 1,
      scale: 1,
      y: 0,
      transition: { duration: 0.4 }
    },
    hover: {
      y: -8,
      boxShadow: '0 20px 40px rgba(0,0,0,0.1)',
      transition: { duration: 0.3 }
    }
  };

  return (
    <motion.div
      className="fitness-score-container"
      variants={containerVariants}
      initial="hidden"
      animate="visible"
    >
      {/* ========== HEADER ========== */}
      <motion.div className="fitness-header" variants={itemVariants}>
        <h2>
          <span className="header-icon">💪</span>
          Fitness Score Check
        </h2>
        <p>Answer a few questions to evaluate your health and receive a personalized health score</p>
      </motion.div>

      <AnimatePresence mode="wait">
        {/* ========== SELECTION STEP ========== */}
        {currentStep === 'selection' && (
          <motion.div
            className="selection-section"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            key="selection"
          >
            <h3>Choose an Assessment Type</h3>
            <div className="selection-cards">
              {/* Physical Health Check */}
              <motion.div
                className="selection-card physical"
                variants={cardVariants}
                whileHover="hover"
                onClick={() => handleSelectCheckType('physical')}
              >
                <div className="selection-icon">🏃‍♂️</div>
                <h4>Physical Health Check</h4>
                <p>Assess your physical fitness and lifestyle habits</p>
                <button className="selection-btn">Start Assessment</button>
              </motion.div>

              {/* Mental Health Check */}
              <motion.div
                className="selection-card mental"
                variants={cardVariants}
                whileHover="hover"
                onClick={() => handleSelectCheckType('mental')}
              >
                <div className="selection-icon">🧠</div>
                <h4>Mental Health Check</h4>
                <p>Evaluate your mental wellbeing and stress levels</p>
                <button className="selection-btn">Start Assessment</button>
              </motion.div>
            </div>
          </motion.div>
        )}

        {/* ========== QUESTIONNAIRE STEP ========== */}
        {currentStep === 'questionnaire' && (
          <motion.div
            className="questionnaire-section"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            key="questionnaire"
          >
            {/* Progress Bar */}
            <div className="progress-section">
              <div className="progress-bar">
                <motion.div
                  className="progress-fill"
                  initial={{ width: 0 }}
                  animate={{ width: `${((currentQuestion + 1) / currentQuestions.length) * 100}%` }}
                  transition={{ duration: 0.5 }}
                />
              </div>
              <p className="progress-text">
                Question {currentQuestion + 1} of {currentQuestions.length}
              </p>
            </div>

            {/* Question */}
            <motion.div
              className="question-container"
              key={`question-${currentQuestion}`}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.3 }}
            >
              <h3 className="question-text">
                {currentQuestions[currentQuestion].question}
              </h3>

              {/* Options */}
              <div className="options-container">
                {currentQuestions[currentQuestion].options.map((option, index) => (
                  <motion.button
                    key={index}
                    className="option-btn"
                    onClick={() => handleAnswerSelect(option.score)}
                    whileHover={{ scale: 1.02, boxShadow: '0 8px 24px rgba(0,0,0,0.1)' }}
                    whileTap={{ scale: 0.98 }}
                  >
                    <span className="option-radio" />
                    <span className="option-text">{option.text}</span>
                  </motion.button>
                ))}
              </div>
            </motion.div>

            {/* Back Button */}
            <motion.button
              className="back-btn"
              onClick={() => {
                if (currentQuestion > 0) {
                  setCurrentQuestion(currentQuestion - 1);
                  setAnswers(answers.slice(0, -1));
                } else {
                  setCurrentStep('selection');
                  setSelectedCheckType(null);
                  setAnswers([]);
                }
              }}
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
            >
              ← Back
            </motion.button>
          </motion.div>
        )}

        {/* ========== RESULTS STEP ========== */}
        {currentStep === 'results' && (
          <motion.div
            className="results-section"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            key="results"
          >
            {/* Health Report Card */}
            <motion.div
              className="health-report-card"
              variants={cardVariants}
            >
              {/* Report Header */}
              <div className="report-header">
                <div className="report-icon">📋</div>
                <div className="report-title">
                  <h3>Health Assessment Report</h3>
                  <p className="report-date">{getHealthReport().date}</p>
                </div>
              </div>

              {/* Report Content */}
              <div className="report-content">
                {/* Assessment Type */}
                <div className="report-section">
                  <h4 className="section-title">Assessment Type</h4>
                  <div className={`section-value ${selectedCheckType}`}>
                    {selectedCheckType === 'physical' ? '🏃‍♂️' : '🧠'} {getHealthReport().assessmentType}
                  </div>
                </div>

                {/* Questions Summary */}
                <div className="report-section">
                  <h4 className="section-title">Assessment Details</h4>
                  <div className="details-grid">
                    <div className="detail-item">
                      <span className="detail-label">Questions Answered:</span>
                      <span className="detail-number">{getHealthReport().questionsAnswered}/{getHealthReport().totalQuestions}</span>
                    </div>
                    <div className="detail-item">
                      <span className="detail-label">Completion Rate:</span>
                      <span className="detail-number">100%</span>
                    </div>
                  </div>
                </div>

                {/* Score Summary */}
                <div className="report-section">
                  <h4 className="section-title">Your Fitness Score</h4>
                  <div className="score-summary">
                    <div className="score-display">
                      <span className="score-big">{getHealthReport().fitnessScore}</span>
                      <span className="score-max">/100</span>
                    </div>
                    <div className="score-interpretation">
                      <div className={`status-pill ${getHealthReport().healthStatus?.toLowerCase().replace(' ', '-')}`}>
                        {getHealthReport().healthStatus}
                      </div>
                      <p className="status-message">
                        {getHealthReport().healthStatus === 'Excellent' && '🌟 Outstanding health condition! Keep up the excellent work.'}
                        {getHealthReport().healthStatus === 'Good' && '👍 Good health! Minor improvements can help optimize your wellness.'}
                        {getHealthReport().healthStatus === 'Moderate' && '⚠️ Your health needs attention. Focus on recommended lifestyle changes.'}
                        {getHealthReport().healthStatus === 'Needs Improvement' && '❗ Significant changes are needed. Start your wellness journey today.'}
                      </p>
                    </div>
                  </div>
                </div>

                {/* Health Metrics */}
                <div className="report-section">
                  <h4 className="section-title">Health Metrics</h4>
                  <div className="metrics-container">
                    <div className="metric-item">
                      <div className="metric-icon">💪</div>
                      <div className="metric-info">
                        <span className="metric-label">Overall Fitness</span>
                        <div className="metric-bar">
                          <motion.div
                            className="metric-fill"
                            initial={{ width: 0 }}
                            animate={{ width: `${getHealthReport().fitnessScore}%` }}
                            transition={{ duration: 1, delay: 0.5 }}
                            style={{ 
                              backgroundColor: getHealthReport().fitnessScore >= 80 ? '#27ae60' : 
                                               getHealthReport().fitnessScore >= 60 ? '#3498db' :
                                               getHealthReport().fitnessScore >= 40 ? '#f39c12' : '#e74c3c'
                            }}
                          />
                        </div>
                      </div>
                    </div>

                    <div className="metric-item">
                      <div className="metric-icon">📊</div>
                      <div className="metric-info">
                        <span className="metric-label">Assessment Category</span>
                        <span className="metric-value">{getHealthReport().assessmentType}</span>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Recommendations Section */}
                <div className="report-section">
                  <h4 className="section-title">Key Recommendations</h4>
                  <div className="recommendations-list">
                    {getRandomSuggestions(selectedCheckType).map((suggestion, index) => (
                      <motion.div
                        key={index}
                        className="recommendation-item"
                        initial={{ opacity: 0, x: -20 }}
                        animate={{ opacity: 1, x: 0 }}
                        transition={{ delay: 0.6 + index * 0.1 }}
                      >
                        <span className="recommendation-check">✓</span>
                        <span className="recommendation-text">{suggestion}</span>
                      </motion.div>
                    ))}
                  </div>
                </div>

                {/* Report Footer */}
                <div className="report-footer">
                  <p className="footer-text">
                    <span className="footer-icon">ℹ️</span>
                    This report is for informational purposes only. Please consult a healthcare professional for medical advice.
                  </p>
                </div>
              </div>

              {/* Report Actions */}
              <div className="report-actions">
                <motion.button
                  className="download-btn"
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  onClick={() => alert('Report download feature coming soon!')}
                >
                  📥 Download Report
                </motion.button>
                <motion.button
                  className="share-btn"
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  onClick={() => alert('Share feature coming soon!')}
                >
                  📤 Share Report
                </motion.button>
              </div>
            </motion.div>

            {/* Fitness Score Card */}
            <motion.div
              className={`fitness-card ${healthStatus?.toLowerCase().replace(' ', '-')}`}
              variants={cardVariants}
            >
              {/* Score Display */}
              <div className="score-section">
                <motion.div
                  className="circular-progress"
                  initial={{ scale: 0 }}
                  animate={{ scale: 1 }}
                  transition={{ duration: 0.6, delay: 0.2 }}
                >
                  <svg viewBox="0 0 120 120">
                    <circle cx="60" cy="60" r="54" />
                  </svg>
                  <div className="score-text">
                    <span className="score-number">{fitnessScore}</span>
                    <span className="score-label">/100</span>
                  </div>
                </motion.div>

                <div className="status-section">
                  <h3 className={`health-status ${healthStatus?.toLowerCase().replace(' ', '-')}`}>
                    {healthStatus}
                  </h3>
                  <p className="status-description">
                    {healthStatus === 'Excellent' && 'Congratulations! You are in excellent health condition.'}
                    {healthStatus === 'Good' && 'You are doing well! Keep up the good habits.'}
                    {healthStatus === 'Moderate' && 'There is room for improvement. Make some lifestyle changes.'}
                    {healthStatus === 'Needs Improvement' && 'Your health needs immediate attention. Start making changes today.'}
                  </p>
                </div>
              </div>

              {/* Check Type Badge */}
              <div className={`check-type-badge ${selectedCheckType}`}>
                {selectedCheckType === 'physical' ? '🏃‍♂️ Physical Health' : '🧠 Mental Health'}
              </div>
            </motion.div>

            {/* Suggestions */}
            <motion.div className="suggestions-section" variants={itemVariants}>
              <h3>📋 Suggestions to Improve Your Health</h3>
              <div className="suggestions-list">
                {getRandomSuggestions(selectedCheckType).map((suggestion, index) => (
                  <motion.div
                    key={index}
                    className="suggestion-item"
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: index * 0.1 }}
                  >
                    <span className="suggestion-text">{suggestion}</span>
                  </motion.div>
                ))}
              </div>
            </motion.div>

            {/* Retake Button */}
            <motion.button
              className="retake-btn"
              onClick={handleRetake}
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
            >
              🔄 Take Another Assessment
            </motion.button>
          </motion.div>
        )}
      </AnimatePresence>

      {/* ========== BOOK HEALTH TEST SECTION ========== */}
      {currentStep === 'results' && (
        <motion.div className="book-test-section" variants={itemVariants}>
          <h3>📅 Book a Health Test</h3>
          <p>Schedule a comprehensive test at a nearby government health center</p>

          {/* Test Type Selection */}
          <div className="test-type-buttons">
            <motion.button
              className={`test-btn ${selectedBookingType === 'physical' ? 'active' : ''}`}
              onClick={() => setSelectedBookingType('physical')}
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
            >
              🏃‍♂️ Physical Health Test
            </motion.button>
            <motion.button
              className={`test-btn ${selectedBookingType === 'mental' ? 'active' : ''}`}
              onClick={() => setSelectedBookingType('mental')}
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
            >
              🧠 Mental Health Consultation
            </motion.button>
          </div>

          {/* Health Centers Grid */}
          {selectedBookingType && (
            <motion.div
              className="health-centers-grid"
              variants={containerVariants}
              initial="hidden"
              animate="visible"
            >
              {HEALTH_CENTERS.map(center => (
                <motion.div
                  key={center.id}
                  className="health-center-card"
                  variants={cardVariants}
                  whileHover="hover"
                >
                  {/* Center Header */}
                  <div className="center-header">
                    <div className="center-icon">{center.image}</div>
                    <div className="center-rating">
                      <span className="rating-stars">{'⭐'.repeat(Math.floor(center.rating))}</span>
                      <span className="rating-number">{center.rating}</span>
                    </div>
                  </div>

                  {/* Center Info */}
                  <div className="center-info">
                    <h4>{center.name}</h4>
                    <div className="info-row">
                      <span className="info-icon">📍</span>
                      <span className="info-text">{center.address}</span>
                    </div>
                    <div className="info-row">
                      <span className="info-icon">📏</span>
                      <span className="info-text">{center.distance} km away</span>
                    </div>
                    <div className="info-row">
                      <span className="info-icon">📞</span>
                      <span className="info-text">{center.phone}</span>
                    </div>
                    <div className="info-row">
                      <span className="info-icon">🏥</span>
                      <span className="info-text">{center.type}</span>
                    </div>
                  </div>

                  {/* Book Button */}
                  <motion.button
                    className="book-appointment-btn"
                    onClick={() => handleBookAppointment(center, selectedBookingType === 'physical' ? 'Physical Health Test' : 'Mental Health Consultation')}
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                  >
                    📅 Book Appointment
                  </motion.button>
                </motion.div>
              ))}
            </motion.div>
          )}
        </motion.div>
      )}
    </motion.div>
  );
};

export default FitnessScore;