import React, { useState, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import './Tab4.css';

// ─── Questions ────────────────────────────────────────────────────────────────
const PHYSICAL_HEALTH_QUESTIONS = [
  {
    id: 1,
    question: 'How many days per week do you exercise?',
    category: 'Activity',
    options: [
      { text: 'Never', score: 0 },
      { text: '1-2 days', score: 25 },
      { text: '3-4 days', score: 50 },
      { text: '5-6 days', score: 75 },
      { text: 'Every day', score: 100 }
    ]
  },
  {
    id: 2,
    question: 'How many hours do you sleep daily?',
    category: 'Sleep',
    options: [
      { text: 'Less than 5 hours', score: 0 },
      { text: '5-6 hours', score: 25 },
      { text: '6-7 hours', score: 75 },
      { text: '7-8 hours', score: 100 },
      { text: 'More than 8 hours', score: 50 }
    ]
  },
  {
    id: 3,
    question: 'How often do you eat fruits and vegetables?',
    category: 'Nutrition',
    options: [
      { text: 'Rarely', score: 0 },
      { text: 'Sometimes (2-3 times a week)', score: 30 },
      { text: 'Often (4-5 times a week)', score: 60 },
      { text: 'Daily', score: 100 }
    ]
  },
  {
    id: 4,
    question: 'Do you smoke or drink alcohol?',
    category: 'Lifestyle',
    options: [
      { text: 'Yes, regularly', score: 0 },
      { text: 'Yes, occasionally', score: 30 },
      { text: 'No, never', score: 100 }
    ]
  },
  {
    id: 5,
    question: 'Do you have any chronic diseases?',
    category: 'Medical',
    options: [
      { text: 'Yes, multiple diseases', score: 0 },
      { text: 'Yes, one disease', score: 25 },
      { text: 'No', score: 100 }
    ]
  }
];

const MENTAL_HEALTH_QUESTIONS = [
  {
    id: 1,
    question: 'How often do you feel stressed?',
    category: 'Stress',
    options: [
      { text: 'All the time', score: 0 },
      { text: 'Very often', score: 20 },
      { text: 'Sometimes', score: 50 },
      { text: 'Rarely', score: 80 },
      { text: 'Never', score: 100 }
    ]
  },
  {
    id: 2,
    question: 'Do you feel anxious frequently?',
    category: 'Anxiety',
    options: [
      { text: 'Yes, very anxious', score: 0 },
      { text: 'Often anxious', score: 25 },
      { text: 'Sometimes anxious', score: 50 },
      { text: 'Rarely anxious', score: 75 },
      { text: 'Not anxious at all', score: 100 }
    ]
  },
  {
    id: 3,
    question: 'How well do you sleep?',
    category: 'Sleep',
    options: [
      { text: 'Very poorly', score: 0 },
      { text: 'Poorly', score: 25 },
      { text: 'Okay', score: 50 },
      { text: 'Well', score: 75 },
      { text: 'Very well', score: 100 }
    ]
  },
  {
    id: 4,
    question: 'Do you feel motivated during the day?',
    category: 'Motivation',
    options: [
      { text: 'Not motivated at all', score: 0 },
      { text: 'Rarely motivated', score: 30 },
      { text: 'Sometimes motivated', score: 60 },
      { text: 'Often motivated', score: 80 },
      { text: 'Always motivated', score: 100 }
    ]
  },
  {
    id: 5,
    question: 'How often do you feel mentally exhausted?',
    category: 'Energy',
    options: [
      { text: 'Always exhausted', score: 0 },
      { text: 'Often exhausted', score: 20 },
      { text: 'Sometimes exhausted', score: 50 },
      { text: 'Rarely exhausted', score: 80 },
      { text: 'Never exhausted', score: 100 }
    ]
  }
];

const HEALTH_CENTERS = [
  { id: 1, name: 'City Government Medical Center', address: '123 Health Street, Central Delhi', distance: 2.3, phone: '+91-11-1234-5678', type: 'Full Service', rating: 4.6, image: '🏥' },
  { id: 2, name: 'North Delhi Health Centre', address: '456 Wellness Avenue, North Delhi', distance: 3.5, phone: '+91-11-2345-6789', type: 'General & Specialized', rating: 4.5, image: '⚕️' },
  { id: 3, name: 'Mental Wellness Clinic', address: '789 Care Lane, East Delhi', distance: 1.8, phone: '+91-11-3456-7890', type: 'Mental Health Specialist', rating: 4.8, image: '🧠' },
  { id: 4, name: 'South Delhi Community Hospital', address: '234 Medical Park, South Delhi', distance: 4.1, phone: '+91-11-4567-8901', type: 'Community Center', rating: 4.4, image: '🏨' },
  { id: 5, name: 'Holistic Health Center', address: '567 Wellness Plaza, West Delhi', distance: 2.9, phone: '+91-11-5678-9012', type: 'Integrated Care', rating: 4.7, image: '💚' }
];

const SUGGESTIONS = {
  physical: [
    { icon: '🏃‍♂️', text: 'Start a regular exercise routine – even 20 minutes daily helps', priority: 'High' },
    { icon: '😴', text: 'Maintain a consistent sleep schedule of 7-8 hours', priority: 'High' },
    { icon: '🥗', text: 'Eat more fruits and vegetables every day', priority: 'Medium' },
    { icon: '🚫', text: 'Reduce or eliminate smoking and alcohol consumption', priority: 'High' },
    { icon: '💊', text: 'Schedule regular health checkups with your doctor', priority: 'Medium' },
    { icon: '💧', text: 'Drink at least 8 glasses of water daily', priority: 'Medium' },
    { icon: '🚶‍♀️', text: 'Take a 30-minute walk every morning', priority: 'Low' },
    { icon: '🏋️', text: 'Include strength training 2-3 times per week', priority: 'Low' }
  ],
  mental: [
    { icon: '🧘‍♀️', text: 'Practice meditation or yoga for stress relief', priority: 'High' },
    { icon: '🗣️', text: 'Talk to friends, family, or a counselor about stress', priority: 'High' },
    { icon: '🛌', text: 'Maintain good sleep hygiene and bedtime routine', priority: 'High' },
    { icon: '🎯', text: 'Set realistic goals and celebrate small wins', priority: 'Medium' },
    { icon: '⏰', text: 'Take regular breaks during work or study sessions', priority: 'Medium' },
    { icon: '🎵', text: 'Listen to music or engage in hobbies you enjoy', priority: 'Low' },
    { icon: '📱', text: 'Limit screen time, especially on social media', priority: 'Medium' },
    { icon: '🤝', text: 'Spend quality time with loved ones each week', priority: 'Low' }
  ]
};

// ─── Status config ─────────────────────────────────────────────────────────
const STATUS_CONFIG = {
  'Excellent':         { color: '#10b981', bg: '#ecfdf5', border: '#a7f3d0', emoji: '🌟', grade: 'A+', desc: 'Outstanding health! Keep it up.' },
  'Good':              { color: '#3b82f6', bg: '#eff6ff', border: '#bfdbfe', emoji: '👍', grade: 'B+', desc: 'Doing well with minor room for improvement.' },
  'Moderate':          { color: '#f59e0b', bg: '#fffbeb', border: '#fde68a', emoji: '⚠️', grade: 'C',  desc: 'Noticeable areas need your attention.' },
  'Needs Improvement': { color: '#ef4444', bg: '#fef2f2', border: '#fecaca', emoji: '❗', grade: 'D',  desc: 'Significant changes needed — start today.' }
};

// ─── Circular SVG Score ────────────────────────────────────────────────────
const CircularScore = ({ score, color }) => {
  const radius = 52;
  const circumference = 2 * Math.PI * radius;
  const offset = circumference - (score / 100) * circumference;
  return (
    <svg width="130" height="130" viewBox="0 0 130 130">
      <circle cx="65" cy="65" r={radius} fill="none" stroke="#e5e7eb" strokeWidth="10" />
      <motion.circle
        cx="65" cy="65" r={radius}
        fill="none" stroke={color} strokeWidth="10"
        strokeLinecap="round"
        strokeDasharray={circumference}
        initial={{ strokeDashoffset: circumference }}
        animate={{ strokeDashoffset: offset }}
        transition={{ duration: 1.4, ease: 'easeOut', delay: 0.3 }}
        style={{ transform: 'rotate(-90deg)', transformOrigin: '65px 65px' }}
      />
      <text x="65" y="60" textAnchor="middle" fontSize="26" fontWeight="800" fill="#111827">{score}</text>
      <text x="65" y="80" textAnchor="middle" fontSize="12" fill="#9ca3af">/100</text>
    </svg>
  );
};

// ─── Mini bar ─────────────────────────────────────────────────────────────
const MiniBar = ({ score, color }) => (
  <div className="mini-bar-track">
    <motion.div
      className="mini-bar-fill"
      initial={{ width: 0 }}
      animate={{ width: `${score}%` }}
      transition={{ duration: 1, ease: 'easeOut', delay: 0.5 }}
      style={{ background: color }}
    />
  </div>
);

// ═══════════════════════════════════════════════════════════════════════════
// MAIN COMPONENT
// ═══════════════════════════════════════════════════════════════════════════
const FitnessScore = () => {
  const [currentStep, setCurrentStep]           = useState('selection');
  const [selectedCheckType, setSelectedCheckType] = useState(null);
  const [currentQuestion, setCurrentQuestion]   = useState(0);
  const [answers, setAnswers]                   = useState([]);
  const [answerTexts, setAnswerTexts]           = useState([]);
  const [fitnessScore, setFitnessScore]         = useState(null);
  const [healthStatus, setHealthStatus]         = useState(null);
  const [selectedBookingType, setSelectedBookingType] = useState(null);
  const cardRef = useRef(null);

  const currentQuestions = selectedCheckType === 'physical'
    ? PHYSICAL_HEALTH_QUESTIONS : MENTAL_HEALTH_QUESTIONS;

  // ── Handlers ─────────────────────────────────────────────────────────────
  const handleSelectCheckType = (type) => {
    setSelectedCheckType(type);
    setCurrentStep('questionnaire');
    setCurrentQuestion(0);
    setAnswers([]);
    setAnswerTexts([]);
  };

  const handleAnswerSelect = (score, text) => {
    const newAnswers = [...answers, score];
    const newTexts   = [...answerTexts, text];
    setAnswers(newAnswers);
    setAnswerTexts(newTexts);

    if (currentQuestion < currentQuestions.length - 1) {
      setCurrentQuestion(currentQuestion + 1);
    } else {
      calculateScore(newAnswers);
      setCurrentStep('results');
    }
  };

  const calculateScore = (arr) => {
    const avg = arr.reduce((a, b) => a + b, 0) / arr.length;
    setFitnessScore(Math.round(avg));
    if      (avg >= 80) setHealthStatus('Excellent');
    else if (avg >= 60) setHealthStatus('Good');
    else if (avg >= 40) setHealthStatus('Moderate');
    else                setHealthStatus('Needs Improvement');
  };

  const handleRetake = () => {
    setCurrentStep('selection');
    setSelectedCheckType(null);
    setCurrentQuestion(0);
    setAnswers([]);
    setAnswerTexts([]);
    setFitnessScore(null);
    setHealthStatus(null);
    setSelectedBookingType(null);
  };

  const handlePrint = () => window.print();

  // ── Derived data ──────────────────────────────────────────────────────────
  const statusCfg = STATUS_CONFIG[healthStatus] || STATUS_CONFIG['Good'];

  const getSuggestions = (type) =>
    (SUGGESTIONS[type] || []).sort(() => Math.random() - 0.5).slice(0, 4);

  const reportDate = new Date().toLocaleDateString('en-IN', {
    weekday: 'long', year: 'numeric', month: 'long', day: 'numeric'
  });
  const reportTime = new Date().toLocaleTimeString('en-IN', {
    hour: '2-digit', minute: '2-digit', hour12: true
  });

  const prioritySuggestions = getSuggestions(selectedCheckType);

  // ── Animations ────────────────────────────────────────────────────────────
  const fade = {
    hidden:  { opacity: 0, y: 20 },
    visible: { opacity: 1, y: 0, transition: { duration: 0.45 } },
    exit:    { opacity: 0, y: -20, transition: { duration: 0.3 } }
  };

  const stagger = {
    visible: { transition: { staggerChildren: 0.08 } }
  };

  // ══════════════════════════════════════════════════════════════════════════
  return (
    <div className="fs-root">

      {/* ── PAGE HEADER ── */}
      <motion.div className="fs-page-header" initial={{ opacity:0, y:-16 }} animate={{ opacity:1, y:0 }}>
        <div className="fs-page-header-left">
          <div className="fs-page-icon">💪</div>
          <div>
            <h1 className="fs-page-title">Fitness Score Check</h1>
            <p className="fs-page-sub">Answer a few questions to get your personalised health report</p>
          </div>
        </div>
      </motion.div>

      {/* ── STEPS ── */}
      <AnimatePresence mode="wait">

        {/* ── SELECTION ── */}
        {currentStep === 'selection' && (
          <motion.div key="selection" variants={fade} initial="hidden" animate="visible" exit="exit">
            <p className="fs-choose-label">Choose your assessment type</p>
            <div className="fs-selection-grid">
              {[
                { type: 'physical', icon: '🏃‍♂️', title: 'Physical Health', desc: 'Assess fitness, sleep, diet & lifestyle habits', color: '#ef4444', questions: 5 },
                { type: 'mental',   icon: '🧠', title: 'Mental Health',   desc: 'Evaluate stress, anxiety, motivation & wellbeing', color: '#8b5cf6', questions: 5 }
              ].map(item => (
                <motion.button
                  key={item.type}
                  className="fs-select-card"
                  style={{ '--accent': item.color }}
                  onClick={() => handleSelectCheckType(item.type)}
                  whileHover={{ y: -6, boxShadow: '0 20px 48px rgba(0,0,0,0.12)' }}
                  whileTap={{ scale: 0.97 }}
                >
                  <div className="fs-select-icon" style={{ background: item.color + '18' }}>{item.icon}</div>
                  <h3 className="fs-select-title">{item.title}</h3>
                  <p className="fs-select-desc">{item.desc}</p>
                  <div className="fs-select-meta">
                    <span>📋 {item.questions} Questions</span>
                    <span>⏱ ~2 mins</span>
                  </div>
                  <div className="fs-select-cta">Start Assessment →</div>
                </motion.button>
              ))}
            </div>
          </motion.div>
        )}

        {/* ── QUESTIONNAIRE ── */}
        {currentStep === 'questionnaire' && (
          <motion.div key="questionnaire" variants={fade} initial="hidden" animate="visible" exit="exit"
            className="fs-quiz-wrap">
            {/* Progress */}
            <div className="fs-progress-header">
              <div className="fs-progress-meta">
                <span className="fs-progress-type">
                  {selectedCheckType === 'physical' ? '🏃‍♂️ Physical Health' : '🧠 Mental Health'}
                </span>
                <span className="fs-progress-count">{currentQuestion + 1} / {currentQuestions.length}</span>
              </div>
              <div className="fs-progress-bar">
                <motion.div
                  className="fs-progress-fill"
                  style={{ background: selectedCheckType === 'physical' ? '#ef4444' : '#8b5cf6' }}
                  initial={{ width: 0 }}
                  animate={{ width: `${((currentQuestion + 1) / currentQuestions.length) * 100}%` }}
                  transition={{ duration: 0.4 }}
                />
              </div>
            </div>

            {/* Category badge */}
            <div className="fs-category-badge">
              {currentQuestions[currentQuestion].category}
            </div>

            {/* Question card */}
            <AnimatePresence mode="wait">
              <motion.div
                key={currentQuestion}
                className="fs-question-card"
                initial={{ opacity: 0, x: 30 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -30 }}
                transition={{ duration: 0.3 }}
              >
                <h2 className="fs-question-text">{currentQuestions[currentQuestion].question}</h2>

                <div className="fs-options-list">
                  {currentQuestions[currentQuestion].options.map((opt, i) => (
                    <motion.button
                      key={i}
                      className="fs-option"
                      onClick={() => handleAnswerSelect(opt.score, opt.text)}
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: i * 0.06 }}
                      whileHover={{ x: 6, backgroundColor: '#f0f7ff', borderColor: '#3b82f6' }}
                      whileTap={{ scale: 0.98 }}
                    >
                      <div className="fs-option-dot" />
                      <span>{opt.text}</span>
                    </motion.button>
                  ))}
                </div>
              </motion.div>
            </AnimatePresence>

            {/* Back */}
            <button className="fs-back-btn" onClick={() => {
              if (currentQuestion > 0) {
                setCurrentQuestion(q => q - 1);
                setAnswers(a => a.slice(0, -1));
                setAnswerTexts(t => t.slice(0, -1));
              } else {
                handleRetake();
              }
            }}>
              ← Back
            </button>
          </motion.div>
        )}

        {/* ── RESULTS ── */}
        {currentStep === 'results' && (
          <motion.div key="results" variants={fade} initial="hidden" animate="visible" exit="exit">
            <motion.div variants={stagger} initial="hidden" animate="visible" className="fs-results-wrap">

              {/* ════════════════════════════════════
                  HEALTH REPORT CARD
              ════════════════════════════════════ */}
              <motion.div
                ref={cardRef}
                className="fs-report-card"
                variants={fade}
                style={{ '--status-color': statusCfg.color, '--status-bg': statusCfg.bg, '--status-border': statusCfg.border }}
              >
                {/* Card header band */}
                <div className="fs-card-band" style={{ background: `linear-gradient(135deg, ${statusCfg.color}22, ${statusCfg.color}08)`, borderColor: statusCfg.border }}>
                  <div className="fs-card-band-left">
                    <div className="fs-card-logo">🏥</div>
                    <div>
                      <div className="fs-card-org">CareSphere Health</div>
                      <div className="fs-card-org-sub">Official Health Assessment Report</div>
                    </div>
                  </div>
                  <div className="fs-card-band-right">
                    <div className="fs-card-id">#{Math.random().toString(36).substr(2,8).toUpperCase()}</div>
                    <div className="fs-card-date">{reportDate}</div>
                    <div className="fs-card-time">{reportTime}</div>
                  </div>
                </div>

                {/* Main card body */}
                <div className="fs-card-body">

                  {/* ── Score + Status ── */}
                  <div className="fs-card-score-row">
                    <motion.div
                      className="fs-card-score-wrap"
                      initial={{ scale: 0, rotate: -10 }}
                      animate={{ scale: 1, rotate: 0 }}
                      transition={{ type: 'spring', stiffness: 200, damping: 16, delay: 0.2 }}
                    >
                      <CircularScore score={fitnessScore} color={statusCfg.color} />
                    </motion.div>

                    <div className="fs-card-status-wrap">
                      <motion.div
                        className="fs-grade-badge"
                        style={{ background: statusCfg.color }}
                        initial={{ scale: 0 }}
                        animate={{ scale: 1 }}
                        transition={{ delay: 0.5, type: 'spring', stiffness: 260 }}
                      >
                        {statusCfg.grade}
                      </motion.div>

                      <motion.div
                        className="fs-status-emoji"
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        transition={{ delay: 0.6 }}
                      >
                        {statusCfg.emoji}
                      </motion.div>

                      <h2 className="fs-status-label" style={{ color: statusCfg.color }}>
                        {healthStatus}
                      </h2>
                      <p className="fs-status-desc">{statusCfg.desc}</p>

                      <div className="fs-check-pill" style={{ background: statusCfg.bg, border: `1px solid ${statusCfg.border}`, color: statusCfg.color }}>
                        {selectedCheckType === 'physical' ? '🏃‍♂️ Physical Health' : '🧠 Mental Health'} Assessment
                      </div>
                    </div>
                  </div>

                  {/* ── Divider ── */}
                  <div className="fs-divider" />

                  {/* ── Q&A Breakdown ── */}
                  <div className="fs-section">
                    <h3 className="fs-section-title">📋 Assessment Breakdown</h3>
                    <div className="fs-qa-grid">
                      {currentQuestions.map((q, i) => {
                        const s = answers[i] ?? 0;
                        const cfg = s >= 80 ? STATUS_CONFIG['Excellent']
                                  : s >= 60 ? STATUS_CONFIG['Good']
                                  : s >= 40 ? STATUS_CONFIG['Moderate']
                                  : STATUS_CONFIG['Needs Improvement'];
                        return (
                          <motion.div
                            key={i}
                            className="fs-qa-item"
                            initial={{ opacity: 0, x: -16 }}
                            animate={{ opacity: 1, x: 0 }}
                            transition={{ delay: 0.1 + i * 0.07 }}
                          >
                            <div className="fs-qa-header">
                              <span className="fs-qa-category">{q.category}</span>
                              <span className="fs-qa-score-chip" style={{ background: cfg.bg, color: cfg.color, border: `1px solid ${cfg.border}` }}>
                                {cfg.emoji} {s}/100
                              </span>
                            </div>
                            <p className="fs-qa-question">Q{i+1}. {q.question}</p>
                            <p className="fs-qa-answer">→ {answerTexts[i]}</p>
                            <MiniBar score={s} color={cfg.color} />
                          </motion.div>
                        );
                      })}
                    </div>
                  </div>

                  {/* ── Divider ── */}
                  <div className="fs-divider" />

                  {/* ── Health Metrics Overview ── */}
                  <div className="fs-section">
                    <h3 className="fs-section-title">📊 Health Metrics Overview</h3>
                    <div className="fs-metrics-row">
                      {[
                        { label: 'Overall Score', value: `${fitnessScore}%`, icon: '💯' },
                        { label: 'Questions',     value: `${answers.length}/${currentQuestions.length}`, icon: '✅' },
                        { label: 'Assessment',    value: selectedCheckType === 'physical' ? 'Physical' : 'Mental', icon: selectedCheckType === 'physical' ? '🏃‍♂️' : '🧠' },
                        { label: 'Grade',         value: statusCfg.grade, icon: '🎖️' }
                      ].map((m, i) => (
                        <motion.div
                          key={i}
                          className="fs-metric-tile"
                          initial={{ opacity: 0, y: 12 }}
                          animate={{ opacity: 1, y: 0 }}
                          transition={{ delay: 0.2 + i * 0.07 }}
                        >
                          <div className="fs-metric-icon">{m.icon}</div>
                          <div className="fs-metric-value" style={{ color: statusCfg.color }}>{m.value}</div>
                          <div className="fs-metric-label">{m.label}</div>
                        </motion.div>
                      ))}
                    </div>

                    {/* Overall bar */}
                    <div className="fs-overall-bar-wrap">
                      <div className="fs-overall-bar-header">
                        <span>Overall Health Score</span>
                        <span style={{ color: statusCfg.color, fontWeight: 700 }}>{fitnessScore}/100</span>
                      </div>
                      <div className="fs-overall-bar-track">
                        <motion.div
                          className="fs-overall-bar-fill"
                          initial={{ width: 0 }}
                          animate={{ width: `${fitnessScore}%` }}
                          transition={{ duration: 1.2, ease: 'easeOut', delay: 0.4 }}
                          style={{ background: `linear-gradient(90deg, ${statusCfg.color}aa, ${statusCfg.color})` }}
                        />
                        <motion.div
                          className="fs-overall-bar-dot"
                          initial={{ left: 0 }}
                          animate={{ left: `${fitnessScore}%` }}
                          transition={{ duration: 1.2, ease: 'easeOut', delay: 0.4 }}
                          style={{ background: statusCfg.color }}
                        />
                      </div>
                      <div className="fs-bar-labels">
                        <span>Poor</span><span>Moderate</span><span>Good</span><span>Excellent</span>
                      </div>
                    </div>
                  </div>

                  {/* ── Divider ── */}
                  <div className="fs-divider" />

                  {/* ── Recommendations ── */}
                  <div className="fs-section">
                    <h3 className="fs-section-title">💡 Personalised Recommendations</h3>
                    <div className="fs-rec-grid">
                      {prioritySuggestions.map((s, i) => (
                        <motion.div
                          key={i}
                          className={`fs-rec-item priority-${s.priority.toLowerCase()}`}
                          initial={{ opacity: 0, y: 10 }}
                          animate={{ opacity: 1, y: 0 }}
                          transition={{ delay: 0.3 + i * 0.08 }}
                        >
                          <div className="fs-rec-icon">{s.icon}</div>
                          <div className="fs-rec-content">
                            <p className="fs-rec-text">{s.text}</p>
                            <span className={`fs-priority-tag priority-${s.priority.toLowerCase()}`}>{s.priority} Priority</span>
                          </div>
                        </motion.div>
                      ))}
                    </div>
                  </div>

                  {/* ── Disclaimer ── */}
                  <div className="fs-card-disclaimer">
                    <span>⚠️</span>
                    <span>This report is for informational purposes only and does not constitute medical advice. Please consult a qualified healthcare professional for diagnosis and treatment.</span>
                  </div>
                </div>

                {/* Card footer */}
                <div className="fs-card-footer">
                  <span>CareSphere Health Platform</span>
                  <span className="fs-footer-dot" />
                  <span>{reportDate}</span>
                  <span className="fs-footer-dot" />
                  <span>Assessment ID: #{Math.random().toString(36).substr(2,6).toUpperCase()}</span>
                </div>
              </motion.div>

              {/* ── CARD ACTIONS ── */}
              <motion.div className="fs-card-actions" variants={fade}>
                <motion.button
                  className="fs-action-btn primary"
                  onClick={handlePrint}
                  whileHover={{ scale: 1.03, y: -2 }}
                  whileTap={{ scale: 0.97 }}
                >
                  🖨️ Print Report
                </motion.button>
                <motion.button
                  className="fs-action-btn secondary"
                  onClick={() => {
                    const text = `My CareSphere Health Report\nScore: ${fitnessScore}/100\nStatus: ${healthStatus}\nType: ${selectedCheckType === 'physical' ? 'Physical' : 'Mental'} Health\nDate: ${reportDate}`;
                    navigator.share ? navigator.share({ title: 'My Health Report', text }) : alert('Share not supported on this device.');
                  }}
                  whileHover={{ scale: 1.03, y: -2 }}
                  whileTap={{ scale: 0.97 }}
                >
                  📤 Share
                </motion.button>
                <motion.button
                  className="fs-action-btn ghost"
                  onClick={handleRetake}
                  whileHover={{ scale: 1.03, y: -2 }}
                  whileTap={{ scale: 0.97 }}
                >
                  🔄 Retake
                </motion.button>
              </motion.div>

              {/* ── BOOK A TEST ── */}
              <motion.div className="fs-book-section" variants={fade}>
                <div className="fs-book-header">
                  <h3>📅 Book a Health Test</h3>
                  <p>Schedule a comprehensive checkup at a nearby government health centre</p>
                </div>
                <div className="fs-book-type-row">
                  {['physical', 'mental'].map(type => (
                    <motion.button
                      key={type}
                      className={`fs-book-type-btn ${selectedBookingType === type ? 'active' : ''}`}
                      onClick={() => setSelectedBookingType(type)}
                      whileHover={{ scale: 1.03 }}
                      whileTap={{ scale: 0.97 }}
                    >
                      {type === 'physical' ? '🏃‍♂️ Physical Health Test' : '🧠 Mental Health Consultation'}
                    </motion.button>
                  ))}
                </div>

                <AnimatePresence>
                  {selectedBookingType && (
                    <motion.div
                      className="fs-centers-grid"
                      initial={{ opacity: 0, y: 12 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0 }}
                    >
                      {HEALTH_CENTERS.map((c, i) => (
                        <motion.div
                          key={c.id}
                          className="fs-center-card"
                          initial={{ opacity: 0, y: 16 }}
                          animate={{ opacity: 1, y: 0 }}
                          transition={{ delay: i * 0.07 }}
                          whileHover={{ y: -5, boxShadow: '0 16px 40px rgba(0,0,0,0.12)' }}
                        >
                          <div className="fs-center-top">
                            <div className="fs-center-icon">{c.image}</div>
                            <div className="fs-center-rating">⭐ {c.rating}</div>
                          </div>
                          <h4 className="fs-center-name">{c.name}</h4>
                          <div className="fs-center-info">
                            <span>📍 {c.address}</span>
                            <span>📏 {c.distance} km away</span>
                            <span>📞 {c.phone}</span>
                            <span>🏷️ {c.type}</span>
                          </div>
                          <motion.button
                            className="fs-book-btn"
                            onClick={() => alert(`Appointment booked at ${c.name}!\n\nContact: ${c.phone}`)}
                            whileHover={{ scale: 1.04 }}
                            whileTap={{ scale: 0.96 }}
                          >
                            📅 Book Appointment
                          </motion.button>
                        </motion.div>
                      ))}
                    </motion.div>
                  )}
                </AnimatePresence>
              </motion.div>

            </motion.div>
          </motion.div>
        )}

      </AnimatePresence>
    </div>
  );
};

export default FitnessScore;