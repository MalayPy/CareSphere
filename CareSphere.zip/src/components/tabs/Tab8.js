import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import './Tab8.css';

/* ============================================
   EMERGENCY ASSISTANCE COMPONENT
   
   Complete emergency system with:
   - SOS button for immediate help
   - Nearby hospitals
   - Emergency contacts
   - Ambulance request
   - Medical information
   - Live location
   - Emergency tips
   - Fast response design
   - Framer Motion animations
   ============================================ */

// Sample hospital data
const SAMPLE_HOSPITALS = [
  {
    id: 1,
    name: 'Apollo Hospital',
    address: '123 Medical Avenue, Central Delhi',
    distance: 2.3,
    phone: '+91-11-4069-6000',
    status: 'Emergency Available',
    image: '🏥',
    rating: 4.8
  },
  {
    id: 2,
    name: 'Max Healthcare',
    address: '456 Health Street, Delhi',
    distance: 3.5,
    phone: '+91-11-4166-6666',
    status: 'Open',
    image: '🏥',
    rating: 4.7
  },
  {
    id: 3,
    name: 'Fortis Hospital',
    address: '789 Care Lane, Delhi',
    distance: 1.8,
    phone: '+91-11-4247-8000',
    status: 'Emergency Available',
    image: '🏥',
    rating: 4.9
  },
  {
    id: 4,
    name: 'AIIMS Delhi',
    address: '567 Government Road, Delhi',
    distance: 4.2,
    phone: '+91-11-2658-8500',
    status: 'Open',
    image: '🏥',
    rating: 4.6
  }
];

// Sample emergency contacts
const DEFAULT_CONTACTS = [
  {
    id: 1,
    name: 'Rajesh Kumar',
    relationship: 'Father',
    phone: '+91-98765-43210'
  },
  {
    id: 2,
    name: 'Priya Singh',
    relationship: 'Mother',
    phone: '+91-98765-43211'
  },
  {
    id: 3,
    name: 'Amit Sharma',
    relationship: 'Brother',
    phone: '+91-98765-43212'
  }
];

// Emergency tips data
const EMERGENCY_TIPS = [
  {
    id: 1,
    title: 'CPR Instructions',
    description: 'Check responsiveness. Call 911. Place heel of hand on chest center. Push hard and fast at least 2 inches deep.',
    icon: '💓'
  },
  {
    id: 2,
    title: 'First Aid Basics',
    description: 'Clean the wound with water. Apply pressure with clean cloth. Elevate the injured area if possible.',
    icon: '🩹'
  },
  {
    id: 3,
    title: 'Heart Attack Signs',
    description: 'Chest pain, shortness of breath, nausea. Call emergency immediately. Chew aspirin if available.',
    icon: '❤️'
  },
  {
    id: 4,
    title: 'Emergency Breathing',
    description: 'Tilt head back, lift chin. Clear airway. Pinch nose and give rescue breaths if trained.',
    icon: '🫁'
  }
];

const Emergency = () => {
  // ========== STATE MANAGEMENT ==========
  const [sosActive, setSosActive] = useState(false);
  const [emergencyContacts, setEmergencyContacts] = useState(DEFAULT_CONTACTS);
  const [showAddContact, setShowAddContact] = useState(false);
  const [newContact, setNewContact] = useState({ name: '', relationship: '', phone: '' });
  const [ambulanceRequested, setAmbulanceRequested] = useState(false);
  const [ambulanceStatus, setAmbulanceStatus] = useState('Searching');
  const [arrivalTime, setArrivalTime] = useState(8);
  const [showMedicalInfo, setShowMedicalInfo] = useState(false);
  const [medicalInfo, setMedicalInfo] = useState({
    bloodGroup: 'O+',
    allergies: 'Penicillin, Sulfa drugs',
    conditions: 'Diabetes Type 2, Hypertension',
    medications: 'Metformin 500mg (Twice daily), Amlodipine 5mg (Once daily)'
  });
  const [editMedicalInfo, setEditMedicalInfo] = useState(false);
  const [showTips, setShowTips] = useState(false);
  const [notifiedContacts, setNotifiedContacts] = useState([]);

  // ========== SOS HANDLER ==========
  const handleSOS = () => {
    setSosActive(true);
    
    // Notify emergency contacts
    setNotifiedContacts(emergencyContacts.map(c => c.id));
    
    // Auto-select nearest hospital
    alert(`🚨 EMERGENCY ALERT ACTIVATED!\n\nCalling nearest hospital: ${SAMPLE_HOSPITALS[2].name}\nLocation shared with emergency services.\n\nEmergency contacts notified!`);
    
    // Simulate ambulance request
    setTimeout(() => {
      setAmbulanceRequested(true);
      setAmbulanceStatus('On the way');
      setArrivalTime(8);
    }, 1000);
  };

  // ========== AMBULANCE TIMER ==========
  useEffect(() => {
    let interval;
    if (ambulanceRequested && arrivalTime > 0) {
      interval = setInterval(() => {
        setArrivalTime(prev => Math.max(0, prev - 1));
      }, 60000); // Decrease every minute
    }
    return () => clearInterval(interval);
  }, [ambulanceRequested, arrivalTime]);

  // ========== CONTACT HANDLERS ==========
  const handleAddContact = () => {
    if (newContact.name && newContact.phone) {
      const contact = {
        id: emergencyContacts.length + 1,
        ...newContact
      };
      setEmergencyContacts([...emergencyContacts, contact]);
      setNewContact({ name: '', relationship: '', phone: '' });
      setShowAddContact(false);
    }
  };

  const handleDeleteContact = (id) => {
    setEmergencyContacts(emergencyContacts.filter(c => c.id !== id));
  };

  const handleNotifyContact = (id) => {
    alert(`Emergency alert sent to ${emergencyContacts.find(c => c.id === id)?.name}!`);
  };

  const handleSaveMedicalInfo = (field, value) => {
    setMedicalInfo({ ...medicalInfo, [field]: value });
  };

  // ========== ANIMATION VARIANTS ==========
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: { staggerChildren: 0.1, delayChildren: 0.2 }
    }
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: { opacity: 1, y: 0, transition: { duration: 0.5 } }
  };

  const cardVariants = {
    hidden: { opacity: 0, scale: 0.95, y: 20 },
    visible: {
      opacity: 1,
      scale: 1,
      y: 0,
      transition: { duration: 0.4 }
    },
    hover: {
      y: -4,
      boxShadow: '0 12px 24px rgba(0,0,0,0.1)',
      transition: { duration: 0.3 }
    }
  };

  const sosVariants = {
    hidden: { scale: 0 },
    visible: {
      scale: 1,
      transition: { type: 'spring', stiffness: 100, damping: 20 }
    },
    pulse: {
      scale: [1, 1.05, 1],
      boxShadow: [
        '0 0 0 0 rgba(255, 0, 0, 0.7)',
        '0 0 0 20px rgba(255, 0, 0, 0)',
        '0 0 0 0 rgba(255, 0, 0, 0)'
      ],
      transition: { repeat: Infinity, duration: 1.5 }
    }
  };

  return (
    <motion.div
      className="emergency-container"
      variants={containerVariants}
      initial="hidden"
      animate="visible"
    >
      {/* ========== HEADER ========== */}
      <motion.div className="emergency-header" variants={itemVariants}>
        <h2>
          <span className="header-icon">🚨</span>
          Emergency Assistance
        </h2>
        <p>Get immediate medical help and alert your emergency contacts</p>
      </motion.div>

      {/* ========== SOS BUTTON ========== */}
      <motion.div className="sos-section" variants={itemVariants}>
        <motion.button
          className={`sos-button ${sosActive ? 'active' : ''}`}
          onClick={handleSOS}
          variants={sosVariants}
          initial="hidden"
          animate={sosActive ? ['visible', 'pulse'] : 'visible'}
          whileHover={{ scale: 1.08 }}
          whileTap={{ scale: 0.95 }}
        >
          <span className="sos-text">SOS</span>
          <span className="sos-subtext">Tap for Emergency</span>
        </motion.button>
        {sosActive && (
          <motion.div
            className="sos-active-badge"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
          >
            <span className="pulse-dot"></span>
            Emergency Services Active
          </motion.div>
        )}
      </motion.div>

      {/* ========== AMBULANCE STATUS ========== */}
      <AnimatePresence>
        {ambulanceRequested && (
          <motion.div
            className="ambulance-card"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            variants={itemVariants}
          >
            <div className="ambulance-header">
              <span className="ambulance-icon">🚑</span>
              <h3>Ambulance Status</h3>
            </div>

            <div className="ambulance-info">
              <div className="status-row">
                <span className="status-label">Status:</span>
                <span className={`status-value ${ambulanceStatus.toLowerCase().replace(' ', '-')}`}>
                  {ambulanceStatus}
                </span>
              </div>
              <div className="status-row">
                <span className="status-label">Arrival Time:</span>
                <span className="status-value">{arrivalTime} minutes</span>
              </div>
              <div className="status-row">
                <span className="status-label">Driver:</span>
                <span className="status-value">Ramesh Kumar</span>
              </div>
              <div className="status-row">
                <span className="status-label">Vehicle:</span>
                <span className="status-value">DL-01-AB-1234</span>
              </div>
            </div>

            <div className="progress-bar">
              <motion.div
                className="progress-fill"
                initial={{ width: 0 }}
                animate={{ width: `${((8 - arrivalTime) / 8) * 100}%` }}
                transition={{ duration: 0.5 }}
              />
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* ========== NEAREST HOSPITALS ========== */}
      <motion.div className="hospitals-section" variants={itemVariants}>
        <h3 className="section-title">📍 Nearby Hospitals</h3>
        <div className="hospitals-grid">
          {SAMPLE_HOSPITALS.map(hospital => (
            <motion.div
              key={hospital.id}
              className="hospital-card"
              variants={cardVariants}
              whileHover="hover"
            >
              <div className="hospital-header">
                <span className="hospital-icon">{hospital.image}</span>
                <div className="hospital-title">
                  <h4>{hospital.name}</h4>
                  <p className="hospital-address">{hospital.address}</p>
                </div>
              </div>

              <div className="hospital-details">
                <div className="detail-row">
                  <span className="detail-icon">📏</span>
                  <span className="detail-text">{hospital.distance} km away</span>
                </div>
                <div className="detail-row">
                  <span className="detail-icon">📞</span>
                  <span className="detail-text">{hospital.phone}</span>
                </div>
                <div className="detail-row">
                  <span className="detail-icon">⭐</span>
                  <span className="detail-text">{hospital.rating} rating</span>
                </div>
                <div className="detail-row">
                  <span className={`status-badge ${hospital.status.toLowerCase().replace(/\s+/g, '-')}`}>
                    {hospital.status}
                  </span>
                </div>
              </div>

              <div className="hospital-actions">
                <motion.button
                  className="action-btn call"
                  onClick={() => alert(`Calling ${hospital.name}...`)}
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                >
                  📞 Call Hospital
                </motion.button>
                <motion.button
                  className="action-btn location"
                  onClick={() => alert(`Opening location for ${hospital.name}...`)}
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                >
                  📍 View Location
                </motion.button>
              </div>
            </motion.div>
          ))}
        </div>
      </motion.div>

      {/* ========== AMBULANCE REQUEST ========== */}
      {!ambulanceRequested && (
        <motion.div className="ambulance-request-section" variants={itemVariants}>
          <motion.button
            className="ambulance-request-btn"
            onClick={() => {
              setAmbulanceRequested(true);
              setAmbulanceStatus('Searching');
              alert('Ambulance request sent! Driver will arrive in approximately 8 minutes.');
            }}
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
          >
            🚑 Request Ambulance
          </motion.button>
        </motion.div>
      )}

      {/* ========== MEDICAL INFORMATION ========== */}
      <motion.div className="medical-info-section" variants={itemVariants}>
        <div className="medical-header">
          <h3 className="section-title">💊 Medical Information</h3>
          <motion.button
            className="edit-btn"
            onClick={() => setEditMedicalInfo(!editMedicalInfo)}
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
          >
            {editMedicalInfo ? '✓ Done' : '✏️ Edit'}
          </motion.button>
        </div>

        <div className="medical-card">
          <div className="medical-row">
            <span className="medical-label">Blood Group:</span>
            {editMedicalInfo ? (
              <input
                type="text"
                value={medicalInfo.bloodGroup}
                onChange={(e) => handleSaveMedicalInfo('bloodGroup', e.target.value)}
                className="medical-input"
              />
            ) : (
              <span className="medical-value">{medicalInfo.bloodGroup}</span>
            )}
          </div>

          <div className="medical-row">
            <span className="medical-label">Allergies:</span>
            {editMedicalInfo ? (
              <input
                type="text"
                value={medicalInfo.allergies}
                onChange={(e) => handleSaveMedicalInfo('allergies', e.target.value)}
                className="medical-input"
              />
            ) : (
              <span className="medical-value">{medicalInfo.allergies}</span>
            )}
          </div>

          <div className="medical-row">
            <span className="medical-label">Conditions:</span>
            {editMedicalInfo ? (
              <input
                type="text"
                value={medicalInfo.conditions}
                onChange={(e) => handleSaveMedicalInfo('conditions', e.target.value)}
                className="medical-input"
              />
            ) : (
              <span className="medical-value">{medicalInfo.conditions}</span>
            )}
          </div>

          <div className="medical-row">
            <span className="medical-label">Medications:</span>
            {editMedicalInfo ? (
              <input
                type="text"
                value={medicalInfo.medications}
                onChange={(e) => handleSaveMedicalInfo('medications', e.target.value)}
                className="medical-input"
              />
            ) : (
              <span className="medical-value">{medicalInfo.medications}</span>
            )}
          </div>
        </div>
      </motion.div>

      {/* ========== EMERGENCY CONTACTS ========== */}
      <motion.div className="contacts-section" variants={itemVariants}>
        <div className="contacts-header">
          <h3 className="section-title">👥 Emergency Contacts</h3>
          <motion.button
            className="add-contact-btn"
            onClick={() => setShowAddContact(!showAddContact)}
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
          >
            + Add Contact
          </motion.button>
        </div>

        <AnimatePresence>
          {showAddContact && (
            <motion.div
              className="add-contact-form"
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              exit={{ opacity: 0, height: 0 }}
            >
              <input
                type="text"
                placeholder="Name"
                value={newContact.name}
                onChange={(e) => setNewContact({ ...newContact, name: e.target.value })}
                className="form-input"
              />
              <input
                type="text"
                placeholder="Relationship (e.g., Father, Mother)"
                value={newContact.relationship}
                onChange={(e) => setNewContact({ ...newContact, relationship: e.target.value })}
                className="form-input"
              />
              <input
                type="tel"
                placeholder="Phone Number"
                value={newContact.phone}
                onChange={(e) => setNewContact({ ...newContact, phone: e.target.value })}
                className="form-input"
              />
              <div className="form-actions">
                <motion.button
                  className="btn-primary"
                  onClick={handleAddContact}
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                >
                  Save Contact
                </motion.button>
                <motion.button
                  className="btn-secondary"
                  onClick={() => setShowAddContact(false)}
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                >
                  Cancel
                </motion.button>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        <div className="contacts-grid">
          {emergencyContacts.map(contact => (
            <motion.div
              key={contact.id}
              className="contact-card"
              variants={cardVariants}
              whileHover="hover"
            >
              <div className="contact-info">
                <h4>{contact.name}</h4>
                <p className="contact-relationship">{contact.relationship}</p>
                <p className="contact-phone">{contact.phone}</p>
              </div>

              <div className="contact-actions">
                <motion.button
                  className="notify-btn"
                  onClick={() => handleNotifyContact(contact.id)}
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                >
                  📢 Notify
                </motion.button>
                <motion.button
                  className="delete-btn"
                  onClick={() => handleDeleteContact(contact.id)}
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                >
                  🗑️
                </motion.button>
              </div>
            </motion.div>
          ))}
        </div>
      </motion.div>

      {/* ========== EMERGENCY TIPS ========== */}
      <motion.div className="tips-section" variants={itemVariants}>
        <div className="tips-header">
          <h3 className="section-title">💡 Emergency Tips</h3>
          <motion.button
            className="tips-toggle-btn"
            onClick={() => setShowTips(!showTips)}
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
          >
            {showTips ? '▼ Hide' : '▶ Show'}
          </motion.button>
        </div>

        <AnimatePresence>
          {showTips && (
            <motion.div
              className="tips-grid"
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              exit={{ opacity: 0, height: 0 }}
            >
              {EMERGENCY_TIPS.map((tip, idx) => (
                <motion.div
                  key={tip.id}
                  className="tip-card"
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: idx * 0.1 }}
                >
                  <div className="tip-icon">{tip.icon}</div>
                  <h4>{tip.title}</h4>
                  <p>{tip.description}</p>
                </motion.div>
              ))}
            </motion.div>
          )}
        </AnimatePresence>
      </motion.div>

      {/* ========== LOCATION CARD ========== */}
      <motion.div className="location-section" variants={itemVariants}>
        <h3 className="section-title">📍 Your Location</h3>
        <div className="location-card">
          <div className="location-map">
            <span className="map-icon">🗺️</span>
          </div>
          <div className="location-info">
            <p className="location-address">Central Delhi, India</p>
            <p className="location-coords">Latitude: 28.6139° | Longitude: 77.2090°</p>
            <motion.button
              className="share-location-btn"
              onClick={() => alert('Location shared with emergency services!')}
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
            >
              📤 Share Location
            </motion.button>
          </div>
        </div>
      </motion.div>
    </motion.div>
  );
};

export default Emergency;