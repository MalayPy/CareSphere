import React, { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import "./Tab7.css";

const schemesData = [
  {
    id: 1,
    name: "Ayushman Bharat",
    description:
      "A national health protection scheme providing free treatment coverage for economically vulnerable families.",
    benefits: [
      "Free hospitalization",
      "Coverage up to ₹5 lakh",
      "Cashless treatment"
    ],
    eligibility: "Low income families",
    documents: ["Aadhaar Card", "Ration Card"],
    type: "Insurance",
    target: "Low-income families",
    state: "All",
    website: "https://pmjay.gov.in",
    process: [
      "Check eligibility",
      "Visit empanelled hospital",
      "Show ID proof",
      "Receive treatment"
    ]
  },
  {
    id: 2,
    name: "PM Jan Arogya Yojana",
    description: "Government health insurance program.",
    benefits: ["Hospital coverage", "Cashless services"],
    eligibility: "Economically weaker families",
    documents: ["Aadhaar", "Income Certificate"],
    type: "Insurance",
    target: "Low-income families",
    state: "All",
    website: "https://pmjay.gov.in",
    process: ["Check eligibility", "Register", "Visit hospital"]
  },
  {
    id: 3,
    name: "Janani Suraksha Yojana",
    description: "Financial support for pregnant women.",
    benefits: ["Cash support", "Free delivery services"],
    eligibility: "Pregnant women",
    documents: ["Aadhaar", "Pregnancy card"],
    type: "Maternity Support",
    target: "Women",
    state: "All",
    website: "https://nhm.gov.in",
    process: ["Register pregnancy", "Visit hospital"]
  },
  {
    id: 4,
    name: "Rashtriya Bal Swasthya Karyakram",
    description: "Health screening program for children.",
    benefits: ["Free health checkups"],
    eligibility: "Children under 18",
    documents: ["Birth certificate"],
    type: "Child Healthcare",
    target: "Children",
    state: "All",
    website: "https://nhm.gov.in",
    process: ["School screening", "Hospital referral"]
  },
  {
    id: 5,
    name: "National Health Mission",
    description: "Program to improve healthcare systems.",
    benefits: ["Free treatment programs"],
    eligibility: "All citizens",
    documents: ["Basic ID"],
    type: "Public Health Program",
    target: "All",
    state: "All",
    website: "https://nhm.gov.in",
    process: ["Visit public hospital"]
  },
  {
    id: 6,
    name: "Pradhan Mantri Matru Vandana Yojana",
    description: "Financial assistance for pregnant women.",
    benefits: ["Cash benefit", "Nutrition support"],
    eligibility: "Pregnant and lactating mothers",
    documents: ["Aadhaar"],
    type: "Maternity Support",
    target: "Women",
    state: "All",
    website: "https://wcd.nic.in",
    process: ["Register pregnancy", "Submit documents"]
  }
];

function Tab7() {

  const [schemes] = useState(schemesData);
  const [search, setSearch] = useState("");
  const [selectedScheme, setSelectedScheme] = useState(null);
  const [bookmarks, setBookmarks] = useState([]);
  const [eligibleSchemes, setEligibleSchemes] = useState([]);
  const [showEligibility, setShowEligibility] = useState(false);

  const [form, setForm] = useState({
    age: "",
    income: "",
    gender: "",
    state: ""
  });

  const [notifications, setNotifications] = useState({
    newSchemes: false,
    reminders: false
  });

  useEffect(() => {
    const saved = JSON.parse(localStorage.getItem("bookmarks")) || [];
    setBookmarks(saved);

    const notif = JSON.parse(localStorage.getItem("notifications"));
    if (notif) setNotifications(notif);
  }, []);

  const toggleBookmark = (scheme) => {
    let updated;

    if (bookmarks.find((b) => b.id === scheme.id)) {
      updated = bookmarks.filter((b) => b.id !== scheme.id);
    } else {
      updated = [...bookmarks, scheme];
    }

    setBookmarks(updated);
    localStorage.setItem("bookmarks", JSON.stringify(updated));
  };

  const handleEligibility = () => {

    const age = parseInt(form.age);
    const income = parseInt(form.income);
    const gender = form.gender;

    const result = schemes.filter((s) => {
      if (s.name === "Ayushman Bharat" && income < 500000) return true;
      if (s.name === "Janani Suraksha Yojana" && gender === "female") return true;
      if (s.name === "Rashtriya Bal Swasthya Karyakram" && age < 18) return true;
      return false;
    });

    setEligibleSchemes(result);
  };

  const filteredSchemes = schemes.filter((s) =>
    s.name.toLowerCase().includes(search.toLowerCase())
  );

  const toggleNotification = (type) => {
    const updated = { ...notifications, [type]: !notifications[type] };
    setNotifications(updated);
    localStorage.setItem("notifications", JSON.stringify(updated));
  };

  return (
    <div className="tab7-container">

      <div className="header">
        <h1>🏥 Government Health Schemes</h1>
        <p>Explore government healthcare schemes and apply easily.</p>
      </div>

      <div className="search-bar">
        <input
          type="text"
          placeholder="Search schemes..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
        />
      </div>

      <div className="scheme-grid">
        {filteredSchemes.map((scheme) => (

          <motion.div
            whileHover={{ scale: 1.05 }}
            className="scheme-card"
            key={scheme.id}
          >

            <h3>{scheme.name}</h3>
            <p>{scheme.description}</p>

            <ul>
              {scheme.benefits.map((b, i) => (
                <li key={i}>✔ {b}</li>
              ))}
            </ul>

            <div className="buttons">

              <button onClick={() => setSelectedScheme(scheme)}>
                View Details
              </button>

              <button onClick={() => window.open(scheme.website, "_blank")}>
                Apply Now
              </button>

              <button onClick={() => toggleBookmark(scheme)}>
                {bookmarks.find((b) => b.id === scheme.id)
                  ? "★ Saved"
                  : "☆ Bookmark"}
              </button>

            </div>

          </motion.div>
        ))}
      </div>

      <AnimatePresence>
        {selectedScheme && (
          <motion.div
            className="modal-overlay"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
          >

            <motion.div
              className="modal"
              initial={{ scale: 0.8 }}
              animate={{ scale: 1 }}
            >

              <h2>{selectedScheme.name}</h2>
              <p>{selectedScheme.description}</p>

              <h4>Benefits</h4>
              <ul>
                {selectedScheme.benefits.map((b, i) => (
                  <li key={i}>{b}</li>
                ))}
              </ul>

              <h4>Eligibility</h4>
              <p>{selectedScheme.eligibility}</p>

              <h4>Documents</h4>
              <ul>
                {selectedScheme.documents.map((d, i) => (
                  <li key={i}>{d}</li>
                ))}
              </ul>

              <button onClick={() => setSelectedScheme(null)}>Close</button>

            </motion.div>

          </motion.div>
        )}
      </AnimatePresence>

      {!showEligibility && (
        <div className="eligibility-toggle">
          <button onClick={() => setShowEligibility(true)}>
            Check Your Eligibility
          </button>
        </div>
      )}

      {showEligibility && (
        <div className="eligibility-checker">

          <div className="eligibility-header">

            <button
              className="back-btn"
              onClick={() => setShowEligibility(false)}
            >
              ← Back
            </button>

            <h2>Check Your Eligibility</h2>

          </div>

          <input
            placeholder="Age"
            onChange={(e) => setForm({ ...form, age: e.target.value })}
          />

          <input
            placeholder="Income"
            onChange={(e) => setForm({ ...form, income: e.target.value })}
          />

          <select
            onChange={(e) => setForm({ ...form, gender: e.target.value })}
          >
            <option value="">Gender</option>
            <option value="male">Male</option>
            <option value="female">Female</option>
          </select>

          <button onClick={handleEligibility}>
            Check Eligibility
          </button>

          <div className="eligible-results">
            {eligibleSchemes.map((s) => (
              <div key={s.id} className="eligible-card">
                {s.name}
              </div>
            ))}
          </div>

        </div>
      )}

      <div className="bookmark-section">
        <h2>Saved Schemes</h2>
        {bookmarks.map((b) => (
          <div key={b.id}>{b.name}</div>
        ))}
      </div>

      <div className="notification-panel">

        <h2>Notifications</h2>

        <label>
          <input
            type="checkbox"
            checked={notifications.newSchemes}
            onChange={() => toggleNotification("newSchemes")}
          />
          New Government Schemes
        </label>

        <label>
          <input
            type="checkbox"
            checked={notifications.reminders}
            onChange={() => toggleNotification("reminders")}
          />
          Scheme Deadline Reminders
        </label>

      </div>

    </div>
  );
}

export default Tab7;