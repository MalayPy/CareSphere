import React from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import './Sidebar.css';

const Sidebar = ({ activeTab, onTabChange, sidebarOpen, onToggleSidebar, userEmail, onLogout, tabMapping }) => {

  const icons = ["🩺","🧑‍⚕️","💊","💪","📝","⚕️","💲","🚨"];
  const descriptions = [
    "Symptom checker and guidance",
    "Find Nearest Doctors",
    "Search,Find,Heal",
    "Track Your health",
    "Protect your Prescription",
    "communicate with doctor",
    "Government schemes",
    "Save Your Life"
  ];

  const menuItems = Object.entries(tabMapping).map(([key, value], index) => ({
    id: key,
    icon: icons[index] || "📁",
    label: value.name,
    description: descriptions[index] || "Tab description"
  }));

  return (
    <>
      <motion.aside
        className={`sidebar ${sidebarOpen ? 'open' : 'closed'}`}
        animate={{ width: sidebarOpen ? 280 : 68 }}
        transition={{ duration: 0.28, ease: 'easeInOut' }}
      >
        {/* Header: Logo + Hamburger */}
        <div className="sidebar-header">
          <AnimatePresence>
            {sidebarOpen && (
              <motion.div
                className="sidebar-logo"
                initial={{ opacity: 0, x: -10 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -10 }}
                transition={{ duration: 0.18 }}
              >
                <span className="logo-icon">🏥</span>
                <div>
                  <h3>CareSphere</h3>
                  <p>Hub</p>
                </div>
              </motion.div>
            )}
          </AnimatePresence>

          <button
            className="hamburger-btn"
            onClick={onToggleSidebar}
            title={sidebarOpen ? 'Collapse sidebar' : 'Expand sidebar'}
          >
            <span className="ham-line" />
            <span className="ham-line" />
            <span className="ham-line" />
          </button>
        </div>

        {/* Navigation */}
        <nav className="sidebar-nav">
          <div className="nav-items">
            {menuItems.map((item) => (
              <motion.button
                key={item.id}
                className={`nav-item ${activeTab === item.id ? 'active' : ''}`}
                onClick={() => onTabChange(item.id)}
                whileHover={{ x: sidebarOpen ? 3 : 0, scale: sidebarOpen ? 1 : 1.1 }}
                whileTap={{ scale: 0.97 }}
                title={!sidebarOpen ? item.label : ''}
              >
                <span className="nav-icon">{item.icon}</span>

                <AnimatePresence>
                  {sidebarOpen && (
                    <motion.div
                      className="nav-text"
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                      exit={{ opacity: 0 }}
                      transition={{ duration: 0.15 }}
                    >
                      <span className="nav-label-text">{item.label}</span>
                      <span className="nav-desc">{item.description}</span>
                    </motion.div>
                  )}
                </AnimatePresence>

                {activeTab === item.id && (
                  <motion.div
                    className="active-indicator"
                    layoutId="active-tab"
                    transition={{ type: 'spring', stiffness: 380, damping: 30 }}
                  />
                )}
              </motion.button>
            ))}
          </div>
        </nav>

        {/* Footer */}
        <div className="sidebar-footer">
          <AnimatePresence>
            {sidebarOpen ? (
              <motion.div
                key="footer-open"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                transition={{ duration: 0.15 }}
              >
                <div className="user-card">
                  <div className="user-avatar">{userEmail.charAt(0).toUpperCase()}</div>
                  <div className="user-details">
                    <p className="user-name">Account</p>
                    <p className="user-email-text">{userEmail}</p>
                  </div>
                </div>
                <motion.button
                  className="logout-btn"
                  onClick={onLogout}
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                >
                  🚪 Logout
                </motion.button>
              </motion.div>
            ) : (
              <motion.div
                key="footer-closed"
                className="sidebar-footer-collapsed"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
              >
                <div className="user-avatar-small">{userEmail.charAt(0).toUpperCase()}</div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </motion.aside>

      {/* Mobile overlay */}
      <AnimatePresence>
        {sidebarOpen && (
          <motion.div
            className="sidebar-overlay"
            onClick={onToggleSidebar}
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
          />
        )}
      </AnimatePresence>
    </>
  );
};

export default Sidebar;