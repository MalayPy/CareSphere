import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import './Dashboard.css';
import Sidebar from '../components/Sidebar';
import Tab1 from '../components/tabs/Tab1';
import Tab2 from '../components/tabs/Tab2';
import Tab3 from '../components/tabs/Tab3';
import Tab4 from '../components/tabs/Tab4';
import Tab5 from '../components/tabs/Tab5';
import Tab6 from '../components/tabs/Tab6';
import Tab7 from '../components/tabs/Tab7';
import Tab8 from '../components/tabs/Tab8';




/* ============================================
   DASHBOARD - Main Interface
   ============================================ */

const Dashboard = ({ userEmail, onLogout }) => {
  const [activeTab, setActiveTab] = useState('tab1');
  const [sidebarOpen, setSidebarOpen] = useState(true);

  // === CUSTOMIZE: Tab names and mapping ===
  const tabMapping = {
    'tab1': { name: 'Disease Triage', component: Tab1 },
    'tab2': { name: 'Doctor Finder', component: Tab2 },
    'tab3': { name: 'Medicine Finder', component: Tab3 },
    'tab4': { name: 'Fitness Score', component: Tab4 },
    'tab5': { name: 'Digital Prescription', component: Tab5 },
    'tab6': { name: 'Doctor Consultancy', component: Tab6 },
    'tab7': { name: 'Government Schems', component: Tab7 },
    'tab8': { name: 'Emergency', component: Tab8 },
  };

  const renderContent = () => {
    const tab = tabMapping[activeTab];
    const Component = tab.component;
    return <Component />;
  };

  const contentVariants = {
    hidden: { opacity: 0, x: 20 },
    visible: { 
      opacity: 1, 
      x: 0,
      transition: { duration: 0.5, ease: 'easeOut' }
    },
    exit: { 
      opacity: 0, 
      x: -20,
      transition: { duration: 0.3, ease: 'easeIn' }
    }
  };

  return (
    <div className="dashboard">
      {/* Sidebar Navigation */}
      <Sidebar 
        activeTab={activeTab}
        onTabChange={setActiveTab}
        sidebarOpen={sidebarOpen}
        onToggleSidebar={() => setSidebarOpen(!sidebarOpen)}
        userEmail={userEmail}
        onLogout={onLogout}
        tabMapping={tabMapping}
      />

      {/* Main Content Area */}
      <div className={`dashboard-main ${sidebarOpen ? 'sidebar-open' : 'sidebar-closed'}`}>
        <header className="dashboard-header">
          <div className="header-left">
            <button 
              className="menu-toggle"
              onClick={() => setSidebarOpen(!sidebarOpen)}
              title="Toggle Sidebar"
            >
              ☰
            </button>
            <h1 className="page-title">
              {tabMapping[activeTab].name}
            </h1>
          </div>
          <div className="header-right">
            <div className="user-info">
              <span className="user-email">{userEmail}</span>
            </div>
          </div>
        </header>

        {/* Animated Content */}
        <div className="dashboard-content">
          <AnimatePresence mode="wait">
            <motion.div
              key={activeTab}
              variants={contentVariants}
              initial="hidden"
              animate="visible"
              exit="exit"
              className="content-wrapper"
            >
              {renderContent()}
            </motion.div>
          </AnimatePresence>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
