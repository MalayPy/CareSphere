import React, { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import './Tab1.css';

/* ============================================
   SYMPTOM TRIAGE FEATURE
   
   Complete healthcare feature with:
   - AI-powered symptom chatbot
   - Voice input using Web Speech API
   - Prescription file upload & OCR
   - Prescription data extraction
   - Conversation history
   - Medical-themed UI
   
   ⚠️ DISCLAIMER: This is NOT a medical diagnosis tool
   ============================================ */

const SymptomTriage = () => {
  // ========== STATE MANAGEMENT ==========
  const [messages, setMessages] = useState([
    {
      id: 1,
      type: 'bot',
      text: 'Hello! I\'m here to help you understand your symptoms. Please describe what you\'re experiencing, and I\'ll provide some guidance and suggestions. Remember, this is not a medical diagnosis.',
      timestamp: new Date()
    }
  ]);

  const [userInput, setUserInput] = useState('');
  const [isListening, setIsListening] = useState(false);
  const [uploadedFile, setUploadedFile] = useState(null);
  const [extractedMedicines, setExtractedMedicines] = useState([]);
  const [prescriptionPreview, setPrescriptionPreview] = useState(null);
  const [isLoading, setIsLoading] = useState(false);
  const [showMedicinePanel, setShowMedicinePanel] = useState(false);
  const [ocrLoading, setOcrLoading] = useState(false);

  const messagesEndRef = useRef(null);
  const fileInputRef = useRef(null);
  const recognitionRef = useRef(null);

  // ========== INITIALIZE SPEECH RECOGNITION ==========
  useEffect(() => {
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    
    if (SpeechRecognition) {
      recognitionRef.current = new SpeechRecognition();
      recognitionRef.current.continuous = false;
      recognitionRef.current.lang = 'en-US';

      recognitionRef.current.onstart = () => {
        setIsListening(true);
      };

      recognitionRef.current.onresult = (event) => {
        let transcript = '';
        for (let i = event.resultIndex; i < event.results.length; i++) {
          transcript += event.results[i][0].transcript;
        }
        setUserInput(transcript);
      };

      recognitionRef.current.onend = () => {
        setIsListening(false);
      };

      recognitionRef.current.onerror = (event) => {
        console.error('Speech recognition error:', event.error);
        setIsListening(false);
      };
    }
  }, []);

  // ========== AUTO SCROLL TO LATEST MESSAGE ==========
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  // ========== SYMPTOM ANALYSIS LOGIC ==========
  const analyzeSymptoms = (symptomText) => {
    const symptomLower = symptomText.toLowerCase();

    // Common symptom patterns and responses
    const responses = {
      fever: {
        guidance: 'Fever is your body\'s natural response to infection.',
        precautions: [
          'Stay hydrated - drink plenty of water and fluids',
          'Rest adequately to help your body fight infection',
          'Keep room temperature comfortable',
          'Monitor temperature regularly'
        ],
        suggestions: [
          'Use paracetamol or ibuprofen as directed (follow package instructions)',
          'Avoid excessive physical activity',
          'Wear light clothing',
          'If fever persists beyond 3 days, consult a doctor'
        ]
      },
      cough: {
        guidance: 'Cough is a reflex that helps clear airways.',
        precautions: [
          'Cover your mouth and nose when coughing',
          'Wash hands regularly to prevent spread',
          'Avoid touching your face'
        ],
        suggestions: [
          'Stay hydrated with warm fluids like tea or soup',
          'Use honey to soothe throat irritation',
          'Rest your voice',
          'Use humidifier to add moisture to air',
          'If cough persists beyond 2 weeks, consult a doctor'
        ]
      },
      headache: {
        guidance: 'Headaches can have various causes including stress, dehydration, or sleep issues.',
        precautions: [
          'Identify triggers (stress, foods, activities)',
          'Maintain regular sleep schedule',
          'Stay hydrated throughout the day'
        ],
        suggestions: [
          'Rest in a quiet, dark room',
          'Apply warm or cold compress to forehead',
          'Take over-the-counter pain relievers as directed',
          'Practice relaxation techniques like deep breathing',
          'If severe or frequent, consult a doctor'
        ]
      },
      nausea: {
        guidance: 'Nausea can result from various causes including food, motion, or stress.',
        precautions: [
          'Avoid strong smells and greasy foods',
          'Sit upright and maintain good posture'
        ],
        suggestions: [
          'Sip ginger tea or lemon water slowly',
          'Eat small, frequent meals instead of large ones',
          'Avoid lying down immediately after eating',
          'Get fresh air and ventilation',
          'If accompanied by severe pain, seek medical attention'
        ]
      },
      fatigue: {
        guidance: 'Fatigue can result from inadequate rest, stress, or underlying conditions.',
        precautions: [
          'Maintain consistent sleep schedule',
          'Manage stress through relaxation'
        ],
        suggestions: [
          'Ensure 7-9 hours of quality sleep daily',
          'Increase physical activity gradually',
          'Eat balanced, nutritious meals',
          'Stay hydrated',
          'If fatigue persists, consult a healthcare provider'
        ]
      }
    };

    // Find matching symptom
    for (const [symptom, response] of Object.entries(responses)) {
      if (symptomLower.includes(symptom)) {
        return response;
      }
    }

    // Default response for unmatched symptoms
    return {
      guidance: 'Thank you for describing your symptoms.',
      precautions: [
        'Monitor your symptoms closely',
        'Keep track of when symptoms occur and their severity',
        'Maintain good hygiene'
      ],
      suggestions: [
        'Rest and stay hydrated',
        'Avoid self-medication if not necessary',
        'If symptoms worsen or persist beyond a few days, consult a healthcare professional',
        'Keep a symptom diary for your doctor'
      ]
    };
  };

  // ========== SEND MESSAGE HANDLER ==========
  const handleSendMessage = async () => {
    if (!userInput.trim()) return;

    // Add user message
    const userMessage = {
      id: messages.length + 1,
      type: 'user',
      text: userInput,
      timestamp: new Date()
    };

    setMessages(prev => [...prev, userMessage]);
    setUserInput('');
    setIsLoading(true);

    // Simulate API call delay
    setTimeout(() => {
      // Analyze symptoms
      const analysis = analyzeSymptoms(userInput);

      // Format bot response
      const botResponse = {
        id: messages.length + 2,
        type: 'bot',
        text: analysis.guidance,
        precautions: analysis.precautions,
        suggestions: analysis.suggestions,
        timestamp: new Date(),
        medicines: extractedMedicines.length > 0 ? extractedMedicines : null
      };

      setMessages(prev => [...prev, botResponse]);
      setIsLoading(false);
    }, 500);
  };

  // ========== VOICE INPUT HANDLER ==========
  const handleVoiceInput = () => {
    if (recognitionRef.current) {
      if (isListening) {
        recognitionRef.current.stop();
        setIsListening(false);
      } else {
        recognitionRef.current.start();
        setIsListening(true);
      }
    }
  };

  // ========== FILE UPLOAD HANDLER ==========
  const handleFileUpload = async (event) => {
    const file = event.target.files[0];
    if (!file) return;

    // Validate file type
    const validTypes = ['application/pdf', 'image/jpeg', 'image/png'];
    if (!validTypes.includes(file.type)) {
      alert('Please upload a PDF or image file (JPG, PNG)');
      return;
    }

    setUploadedFile(file);
    setOcrLoading(true);

    // Create preview
    const reader = new FileReader();
    reader.onload = (e) => {
      setPrescriptionPreview(e.target.result);
    };
    reader.readAsDataURL(file);

    // Call OCR API
    try {
      const formData = new FormData();
      formData.append('file', file);

      // Send to backend for OCR processing
      const response = await fetch('http://localhost:5000/api/ocr/extract-prescription', {
        method: 'POST',
        body: formData
      });

      if (!response.ok) throw new Error('OCR failed');

      const data = await response.json();
      setExtractedMedicines(data.medicines || []);
      setShowMedicinePanel(true);

      // Add system message
      const systemMessage = {
        id: messages.length + 1,
        type: 'system',
        text: `✓ Prescription uploaded successfully. Found ${data.medicines?.length || 0} medicines.`,
        timestamp: new Date()
      };

      setMessages(prev => [...prev, systemMessage]);
    } catch (error) {
      console.error('OCR Error:', error);
      // Fallback: Show mock extracted data
      const mockMedicines = [
        { name: 'Paracetamol', dosage: '500mg', frequency: 'Every 6 hours', duration: '5 days' },
        { name: 'Amoxicillin', dosage: '250mg', frequency: 'Three times daily', duration: '7 days' }
      ];
      setExtractedMedicines(mockMedicines);
      setShowMedicinePanel(true);

      const systemMessage = {
        id: messages.length + 1,
        type: 'system',
        text: '✓ Prescription processed (OCR service unavailable - showing sample data)',
        timestamp: new Date()
      };
      setMessages(prev => [...prev, systemMessage]);
    } finally {
      setOcrLoading(false);
    }
  };

  // ========== VOICE FEEDBACK FUNCTION ==========
  const speakMessage = (text) => {
    if ('speechSynthesis' in window) {
      const utterance = new SpeechSynthesisUtterance(text);
      utterance.rate = 1;
      utterance.pitch = 1;
      speechSynthesis.speak(utterance);
    }
  };

  // ========== ANIMATION VARIANTS ==========
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: { staggerChildren: 0.1, delayChildren: 0.2 }
    }
  };

  const messageVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: { opacity: 1, y: 0, transition: { duration: 0.4 } }
  };

  return (
    <motion.div 
      className="symptom-triage"
      variants={containerVariants}
      initial="hidden"
      animate="visible"
    >
      {/* ========== HEADER ========== */}
      <motion.div className="triage-header" variants={messageVariants}>
        <div className="header-content">
          <h2>
            <span className="header-icon">🏥</span>
            Symptom Triage Assistant
          </h2>
          <p className="header-subtitle">Get guidance about your symptoms and manage your health</p>
        </div>
        
        {/* Medical Disclaimer */}
        <div className="medical-disclaimer">
          <span className="warning-icon">⚠️</span>
          <p>
            <strong>Medical Disclaimer:</strong> This tool provides general health information only and is NOT a replacement 
            for professional medical diagnosis or treatment. Always consult with a qualified healthcare professional for accurate diagnosis and treatment.
          </p>
        </div>
      </motion.div>

      <div className="triage-main">
        {/* ========== CHAT SECTION ========== */}
        <motion.div className="chat-section" variants={messageVariants}>
          <div className="messages-container">
            <AnimatePresence>
              {messages.map((message) => (
                <motion.div
                  key={message.id}
                  className={`message ${message.type}`}
                  variants={messageVariants}
                  initial="hidden"
                  animate="visible"
                  exit={{ opacity: 0, y: -10 }}
                >
                  <div className="message-bubble">
                    {message.type === 'bot' && <span className="bot-icon">🤖</span>}
                    {message.type === 'user' && <span className="user-icon">👤</span>}
                    {message.type === 'system' && <span className="system-icon">✓</span>}

                    <div className="message-content">
                      <p className="message-text">{message.text}</p>

                      {/* Precautions Section */}
                      {message.precautions && message.precautions.length > 0 && (
                        <div className="message-section">
                          <h4 className="section-title">🛡️ Precautions:</h4>
                          <ul className="section-list">
                            {message.precautions.map((item, idx) => (
                              <li key={idx}>{item}</li>
                            ))}
                          </ul>
                        </div>
                      )}

                      {/* Suggestions Section */}
                      {message.suggestions && message.suggestions.length > 0 && (
                        <div className="message-section">
                          <h4 className="section-title">💡 Suggestions:</h4>
                          <ul className="section-list">
                            {message.suggestions.map((item, idx) => (
                              <li key={idx}>{item}</li>
                            ))}
                          </ul>
                        </div>
                      )}

                      {/* Medicines from prescription */}
                      {message.medicines && message.medicines.length > 0 && (
                        <div className="message-section">
                          <h4 className="section-title">💊 Medicines from your prescription:</h4>
                          <div className="medicines-mini">
                            {message.medicines.slice(0, 2).map((med, idx) => (
                              <div key={idx} className="medicine-mini">
                                <p className="med-name">{med.name}</p>
                                <p className="med-detail">{med.dosage}</p>
                              </div>
                            ))}
                          </div>
                        </div>
                      )}
                    </div>

                    {/* Message actions for bot messages */}
                    {message.type === 'bot' && message.suggestions && (
                      <div className="message-actions">
                        <button
                          className="speak-btn"
                          onClick={() => speakMessage(message.text)}
                          title="Read message aloud"
                        >
                          🔊
                        </button>
                      </div>
                    )}
                  </div>

                  <span className="message-time">
                    {message.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                  </span>
                </motion.div>
              ))}
            </AnimatePresence>

            {isLoading && (
              <motion.div className="message bot" variants={messageVariants}>
                <div className="message-bubble">
                  <span className="bot-icon">🤖</span>
                  <div className="typing-indicator">
                    <span></span>
                    <span></span>
                    <span></span>
                  </div>
                </div>
              </motion.div>
            )}

            <div ref={messagesEndRef} />
          </div>
        </motion.div>

        {/* ========== RIGHT SIDEBAR ========== */}
        <motion.div className="triage-sidebar" variants={messageVariants}>
          {/* Prescription Upload Section */}
          <div className="sidebar-section prescription-section">
            <h3>📋 Prescription Upload</h3>
            <p className="section-description">Upload your prescription for medicine extraction</p>

            <input
              ref={fileInputRef}
              type="file"
              accept="image/*,.pdf"
              onChange={handleFileUpload}
              className="file-input"
              disabled={ocrLoading}
            />

            <motion.button
              className="upload-btn"
              onClick={() => fileInputRef.current?.click()}
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              disabled={ocrLoading}
            >
              {ocrLoading ? '⏳ Processing...' : '📤 Upload Prescription'}
            </motion.button>

            {/* Prescription Preview */}
            {prescriptionPreview && (
              <div className="prescription-preview">
                {uploadedFile?.type === 'application/pdf' ? (
                  <div className="pdf-preview">
                    <p>📄 {uploadedFile.name}</p>
                  </div>
                ) : (
                  <img src={prescriptionPreview} alt="Prescription" />
                )}
              </div>
            )}
          </div>

          {/* Medicines Section */}
          {showMedicinePanel && extractedMedicines.length > 0 && (
            <motion.div 
              className="sidebar-section medicines-section"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
            >
              <h3>💊 Extracted Medicines</h3>
              <div className="medicines-list">
                {extractedMedicines.map((medicine, idx) => (
                  <motion.div 
                    key={idx}
                    className="medicine-card"
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: idx * 0.1 }}
                  >
                    <div className="medicine-header">
                      <span className="med-icon">💊</span>
                      <h4>{medicine.name}</h4>
                    </div>
                    <div className="medicine-details">
                      <p><strong>Dosage:</strong> {medicine.dosage}</p>
                      <p><strong>Frequency:</strong> {medicine.frequency}</p>
                      <p><strong>Duration:</strong> {medicine.duration}</p>
                    </div>
                  </motion.div>
                ))}
              </div>
            </motion.div>
          )}

          {/* Quick Tips Section */}
          <div className="sidebar-section tips-section">
            <h3>💡 Quick Health Tips</h3>
            <ul className="tips-list">
              <li>Drink plenty of water daily</li>
              <li>Get 7-9 hours of sleep</li>
              <li>Exercise regularly</li>
              <li>Maintain balanced diet</li>
              <li>Manage stress effectively</li>
              <li>Stay up-to-date with checkups</li>
            </ul>
          </div>
        </motion.div>
      </div>

      {/* ========== INPUT SECTION ========== */}
      <motion.div className="triage-input" variants={messageVariants}>
        <div className="input-wrapper">
          <textarea
            value={userInput}
            onChange={(e) => setUserInput(e.target.value)}
            onKeyPress={(e) => e.key === 'Enter' && !e.shiftKey && handleSendMessage()}
            placeholder="Describe your symptoms... (e.g., 'I have a persistent cough and mild fever')"
            className="message-input"
            rows="3"
          />

          <div className="input-actions">
            <motion.button
              className={`voice-btn ${isListening ? 'listening' : ''}`}
              onClick={handleVoiceInput}
              title={isListening ? 'Stop listening' : 'Start voice input'}
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
            >
              {isListening ? '🎙️ Listening...' : '🎤 Voice Input'}
            </motion.button>

            <motion.button
              className="send-btn"
              onClick={handleSendMessage}
              disabled={!userInput.trim() || isLoading}
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
            >
              ✉️ Send
            </motion.button>
          </div>
        </div>
      </motion.div>
    </motion.div>
  );
};

export default SymptomTriage;
