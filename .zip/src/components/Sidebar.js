import React from 'react';
import { motion } from 'framer-motion';
import './Sidebar.css';

/* ============================================
   SIDEBAR - Left Navigation
   === CUSTOMIZE: Tab names and icons ===
   ============================================ */

const Sidebar = ({ activeTab, onTabChange, sidebarOpen, onToggleSidebar, userEmail, onLogout, tabMapping }) => {
  // === CUSTOMIZE: Tab icons and labels ===
 
const icons = ["🩺","🧑‍⚕️","💊","💪","📝","⚕️","💲","🚨"];

const descriptions = [
  "Symptom checker and guidance",
  "Find Nearest Doctors",
  "Search,Find,Heal",
  "Track Your health",
  "Protect your Prescription",
  "communicate with doctor",
  "Government schemes",
  "Save Your Life"
];

const menuItems = Object.entries(tabMapping).map(([key, value], index) => ({
  id: key,
  icon: icons[index] || "📁",
  label: value.name,
  description: descriptions[index] || "Tab description"
}));

  const containerVariants = {
    hidden: { x: -300 },
    visible: {
      x: 0,
      transition: { duration: 0.3, ease: 'easeOut' }
    },
    exit: { x: -300, transition: { duration: 0.2 } }
  };

  const itemVariants = {
    hidden: { opacity: 0, x: -20 },
    visible: { opacity: 1, x: 0, transition: { duration: 0.3 } }
  };

  return (
    <>
      {/* Sidebar */}
      <motion.aside
        className={`sidebar ${sidebarOpen ? 'open' : 'closed'}`}
        variants={containerVariants}
        initial="hidden"
        animate="visible"
        exit="exit"
      >
        {/* Logo Area */}
        <motion.div className="sidebar-header" variants={itemVariants}>
          <div className="sidebar-logo">
            <span className="logo-icon">🏥</span>
            <div>
              <h3>CareSphere</h3>
              <p>Hub</p>
            </div>
          </div>
          <button 
            className="close-btn"
            onClick={onToggleSidebar}
            title="Close Sidebar"
          >
            ✕
          </button>
        </motion.div>

        {/* Navigation */}
        <nav className="sidebar-nav">
          <motion.div className="nav-section" variants={containerVariants} initial="hidden" animate="visible">
            <motion.p className="nav-label" variants={itemVariants}>
              Tabs
            </motion.p>
            <motion.div className="nav-items">
              {menuItems.map((item, index) => (
                <motion.button
                  key={item.id}
                  className={`nav-item ${activeTab === item.id ? 'active' : ''}`}
                  onClick={() => onTabChange(item.id)}
                  variants={itemVariants}
                  transition={{ delay: index * 0.05 }}
                  whileHover={{ x: 4 }}
                  whileTap={{ x: 2 }}
                >
                  <span className="nav-icon">{item.icon}</span>
                  <div className="nav-text">
                    <span className="nav-label-text">{item.label}</span>
                    <span className="nav-desc">{item.description}</span>
                  </div>
                  {activeTab === item.id && (
                    <motion.div
                      className="active-indicator"
                      layoutId="active-tab"
                      transition={{ type: 'spring', stiffness: 380, damping: 30 }}
                    />
                  )}
                </motion.button>
              ))}
            </motion.div>
          </motion.div>
        </nav>

        {/* Footer */}
        <motion.div className="sidebar-footer" variants={itemVariants}>
          <div className="user-card">
            <div className="user-avatar">
              {userEmail.charAt(0).toUpperCase()}
            </div>
            <div className="user-details">
              <p className="user-name">Account</p>
              <p className="user-email">{userEmail}</p>
            </div>
          </div>

          <motion.button
            className="logout-btn"
            onClick={onLogout}
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
          >
            🚪 Logout
          </motion.button>
        </motion.div>
      </motion.aside>

      {/* Overlay */}
      {sidebarOpen && (
        <motion.div
          className="sidebar-overlay"
          onClick={onToggleSidebar}
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
        />
      )}
    </>
  );
};

export default Sidebar;
